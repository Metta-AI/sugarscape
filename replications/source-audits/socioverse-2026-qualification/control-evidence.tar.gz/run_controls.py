"""Execute ten declared rule controls through the unchanged author's public runner."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

import yaml

source = Path('/Users/relh/Code/workspace/sugarscape-socioverse-reference')
root = Path(__file__).resolve().parent
revision = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
assert revision == 'b3b93e474cd20271bbc3ecbb908d587801e3311f'
assert subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain']) == b''
sys.path.insert(0, str(source))
from tasks.market.sugarscape.model import run

original = source / 'tasks/market/sugarscape/config.yaml'
config = yaml.safe_load(original.read_text())
assert config['population']['n_citizens'] == 200 and config['dynamics']['steps'] == 100
(root / 'protocol.json').write_text(json.dumps({'revision': revision, 'seeds': list(range(10)), 'seed_status': 'Declared reconstruction; historical seed list not recovered.', 'mode': 'rule', 'source_config_sha256': hashlib.sha256(original.read_bytes()).hexdigest(), 'changes': ['seed only'], 'scope': 'Ten native rule control executions; no LLM or paper-result replication claim.'}, indent=2) + '\n')
with (root / 'completed.jsonl').open('x') as ledger:
    for seed in range(10):
        cfg = dict(config, seed=seed)
        path = root / f'seed-{seed}.yaml'
        path.write_text(yaml.safe_dump(cfg))
        started = time.monotonic()
        result = run(mode='rule', config=str(path))
        data = json.dumps(result, indent=2).encode() + b'\n'
        (root / f'seed-{seed}.json').write_bytes(data)
        ledger.write(json.dumps({'seed': seed, 'seconds': time.monotonic()-started, 'sha256': hashlib.sha256(data).hexdigest(), 'metrics': result['metrics']}) + '\n')
        ledger.flush()
