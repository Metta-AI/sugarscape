#include "World.h"
#include "IndependentStrategy.h"
#include "ReadDependentStrategy.h"
#include "WriteStrategy.h"
#include "Growback.h"
#include "AgentMove.h"
#include "AgentMetabolism.h"
#include "AgentDeath.h"
#include "GarbageCollection.h"
#include <iostream>
int main(){
 World world(50); world.init("world.log"); world.sync();
 IndependentStrategy independent(&world); ReadDependentStrategy read(&world); WriteStrategy write(&world);
 Growback grow(&world,&independent); AgentMove move(&world,&write);
 AgentMetabolism metabolism(&world,&independent); AgentDeath death(&world,&read); GarbageCollection garbage(&world,&independent);
 world.addRule(&grow);world.addRule(&move);world.addRule(&metabolism);world.addRule(&death);world.addRule(&garbage);
 std::cout << "cycle,population" << std::endl;
 std::cout << "0," << world.getAgentCount() << std::endl;
 for(int i=1;i<=1000;++i){world.incStep();world.applyRules();std::cout << i << "," << world.getAgentCount() << std::endl;}
}
