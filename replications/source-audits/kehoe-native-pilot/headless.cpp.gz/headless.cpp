#include "World.h"
#include <iostream>
int main(){ World world(50); world.init("world.log"); world.sync(); std::cout << "initial_population," << world.getAgentCount() << std::endl; return 0; }
