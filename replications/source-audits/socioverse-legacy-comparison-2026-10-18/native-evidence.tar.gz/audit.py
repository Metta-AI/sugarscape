"""Audit all native legacy states using independent metrics and conservation bounds."""
import gzip
import hashlib
import json
import math
from pathlib import Path
import statistics

root = Path(__file__).resolve().parent
records = [json.loads(x) for x in (root/'completed.jsonl').read_text().splitlines()]
assert [r['seed'] for r in records] == list(range(10))
observations = 0
transitions = 0
max_gini_error = 0.0
finals = []
for record in records:
    raw = (root/f"seed-{record['seed']}.json.gz").read_bytes()
    assert hashlib.sha256(raw).hexdigest() == record['sha256']
    data = json.loads(gzip.decompress(raw))
    capacities = data['capacities']; assert len(capacities) == 2500
    assert sum(capacities) == 3638
    assert data['initial_comparison'] == record['initial_comparison']
    assert record['initial_comparison']['capacity_differences'] == 134
    assert record['initial_comparison']['native_total_capacity'] == 3772
    assert [f['step'] for f in data['frames']] == list(range(101))
    previous = {}
    for frame in data['frames']:
        rows = frame['agents']; by_id = {r[0]: r for r in rows}
        assert len(by_id) == len(rows) == len({tuple(r[1:3]) for r in rows})
        assert all(0 <= v < 50 for r in rows for v in r[1:3])
        assert all(1 <= r[3] <= 6 and 1 <= r[4] <= 4 and r[5] > 0 for r in rows)
        assert all(0 <= sugar <= cap for sugar,cap in zip(frame['cell_sugar'],capacities,strict=True))
        wealth = [r[5] for r in rows]; n = len(wealth); total = sum(wealth)
        gini = sum(abs(a-b) for a in wealth for b in wealth)/(2*n*total)
        metrics = frame['metrics']; assert metrics['alive'] == n
        assert math.isclose(metrics['mean_sugar'],total/n,rel_tol=0,abs_tol=1e-12)
        error = abs(gini-metrics['gini']); assert error < 1e-12
        max_gini_error = max(error,max_gini_error)
        if frame['step'] == 0:
            assert n == 200 and all(5 <= x <= 25 for x in wealth)
        else:
            assert set(by_id) <= set(previous)
            for aid,row in by_id.items():
                old = previous[aid]; assert row[3:5] == old[3:5]
                dx = min((row[1]-old[1])%50,(old[1]-row[1])%50)
                dy = min((row[2]-old[2])%50,(old[2]-row[2])%50)
                assert dx*dy == 0 and dx+dy <= row[3]
                harvest = row[5]-old[5]+row[4]
                assert 0 <= harvest <= capacities[row[1]*50+row[2]]
                transitions += 1
            for aid in set(previous)-set(by_id):
                assert previous[aid][5] <= previous[aid][4]
        observations += n; previous = by_id
    assert data['frames'][-1]['metrics'] == record['final']
    finals.append(record['final'])
old = Path('/Users/relh/Code/workspace/sugarscape-replication-evidence/socioverse-source-qualification-001')
native = [json.loads(line)['metrics'] for line in (old/'completed.jsonl').read_text().splitlines()]
report = {'runs':10,'snapshots':1010,'cell_observations':2525000,'live_agent_observations':observations,
          'survivor_transitions_checked':transitions,'max_pairwise_gini_error':max_gini_error,
          'capacity_cell_differences':134,'legacy_capacity':3638,'refactored_capacity':3772,
          'legacy_mean_final_population':statistics.mean(x['alive'] for x in finals),
          'refactored_mean_final_population':statistics.mean(x['alive_final'] for x in native),
          'scope':'Full legacy executions; independent metrics, movement and harvest bounds. Different realized initial states and scheduling; not causal attribution, full transition replay or paper replication.',
          'completed_study':False}
(root/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
