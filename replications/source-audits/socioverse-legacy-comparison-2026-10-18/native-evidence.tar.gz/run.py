"""Execute unchanged legacy Mesa controls and preserve observable state."""
import gzip
import hashlib
import importlib.metadata
import importlib.util
import json
from pathlib import Path
import random
import subprocess
import sys

source = Path('/Users/relh/Code/workspace/sugarscape-socioverse-reference')
root = Path(__file__).resolve().parent
assert subprocess.check_output(['git','-C',str(source),'status','--porcelain']) == b''
assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip() == 'b3b93e474cd20271bbc3ecbb908d587801e3311f'
spec = importlib.util.spec_from_file_location('legacy_sugarscape', source/'tasks/market/sugarscape/legacy/sugarscape_simple.py')
legacy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)
sys.path.insert(0,str(source))
from tasks.market.sugarscape.model import build, load_config

(root/'environment.json').write_text(json.dumps({'python':sys.version,'packages':{d.metadata['Name']:d.version for d in importlib.metadata.distributions()}},indent=2)+'\n')
(root/'protocol.json').write_text(json.dumps({'seeds':list(range(10)),'steps':100,'agents':200,'global_random_seed':'same declared seed as Mesa model; both are used by legacy source','historical_seeds':False,'scope':'Unchanged legacy and refactored default configurations. Same seed label does not mean same realized initial state; differences are not attributed to a single cause.'},indent=2)+'\n')


def snapshot(model, step):
    citizens = model.citizens
    wealth = [a.sugar for a in citizens]
    return {'step':step,'agents':[[a.unique_id,*a.pos,a.vision,a.metabolism,a.sugar] for a in citizens],
            'cell_sugar':[p.sugar for p in model.patches],
            'metrics':{'alive':len(citizens),'mean_sugar':sum(wealth)/len(wealth),'gini':legacy.gini(wealth)}}


with (root/'completed.jsonl').open('x') as ledger:
    for seed in range(10):
        random.seed(seed)
        model = legacy.Sugarscape(seed=seed)
        cfg = load_config(); cfg['seed'] = seed
        native, _ = build(cfg)
        capacities = [p.capacity for p in model.patches]
        native_capacities = native.capacity.reshape(-1).tolist()
        frames = [snapshot(model,0)]
        initial_comparison = {'capacity_differences':sum(a!=b for a,b in zip(capacities,native_capacities,strict=True)),
                              'legacy_total_capacity':sum(capacities),'native_total_capacity':sum(native_capacities),
                              'legacy_initial_sugar':sum(p.sugar for p in model.patches),'native_initial_sugar':int(native.sugar.sum())}
        for step in range(1,101):
            model.step()
            frames.append(snapshot(model,step))
        payload = {'seed':seed,'capacities':capacities,'initial_comparison':initial_comparison,'frames':frames}
        data = gzip.compress((json.dumps(payload)+'\n').encode(),mtime=0)
        (root/f'seed-{seed}.json.gz').write_bytes(data)
        result = {'seed':seed,'sha256':hashlib.sha256(data).hexdigest(),'initial_comparison':initial_comparison,'final':frames[-1]['metrics']}
        ledger.write(json.dumps(result)+'\n');ledger.flush()
        print(json.dumps(result),flush=True)
