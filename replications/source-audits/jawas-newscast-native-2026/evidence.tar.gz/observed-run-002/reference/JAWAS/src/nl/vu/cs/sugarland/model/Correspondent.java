package nl.vu.cs.sugarland.model;

import java.util.*;
import nl.vu.cs.sugarland.util.RandomMethods;

/**
 * This class represents a correspondent as defined in the newscast communication protocol.
 *
 * @author Tudor Toma
 * @author Nico Vink
 * @since version 2.0
 * @version 2.0
 */
class Correspondent
{
    public Hashtable cache; // the cache to hold the news items
    private static int cacheSize = 20; // the size of the cache
    private SugarAgent myAgent; // the agent this correspondent "belongs" to
    private String myAgentID; // the id of the agent that this correspondent "belongs" to





    /**
     * Creates a new Correspondent belonging to the supplied agent.
     * @param myAgent the agent this correspondent will belong to
     */
    public Correspondent(SugarAgent myAgent)
    {
        cache = new Hashtable(cacheSize);
        this.myAgent = myAgent;
        myAgentID = "" + myAgent.getID();
    }



    /**
     * This method is specified by the newscast protocol. It updates the agent's cache with the
     * messages in the correspondent's cache.
     */
    public void newsUpdate()
    {
        Enumeration e = cache.keys();
        Object key;
        NewsElement news;

        myAgent.newsCache.clear();
        while (e.hasMoreElements())
        {
            key = e.nextElement();
            news = (NewsElement) cache.get(key);
            if (news.agent != null && !news.agent.isAlive()) news.agent = null;
            myAgent.newsCache.put(key, cache.get(key));
        }
    }



    /**
     * This method is specified by the newscast protocol. It gets the latest news from the agent and puts
     * it in the correspondent's cache.
     */
    public void getNews()
    {
        if (myAgent.personalNews.info.getCoordinates() != null) //this is at first iteration or birth
          {
              // if the cache is not full yet, or if it's full but we can replace our old personal news
            if (cache.size() < cacheSize || cache.containsKey(myAgentID))
                cache.put(myAgentID, myAgent.personalNews);
            // otherwise, first remove the oldest element in the cache.
            else
            {
                cache.remove(oldest(cache));
                cache.put(myAgentID, myAgent.personalNews);
            }
        }
    }



    // finds the key of the oldest element in the given cache
    // if multiple candidates, pick a random one, returns null if cache is empty
    public static long singleChoices, wrongSingleChoices;

    private Object oldest(Hashtable h)
    {
        Enumeration e = h.keys();
        Object key = null;
        NewsElement oldestSoFar = null;
        Random rand = nl.vu.cs.sugarland.util.ReplicationRandom.create();
        ArrayList alternatives = new ArrayList();

        while (e.hasMoreElements())
        {
            key = e.nextElement();
            // if older than temporary result, replace temporary result and clear the alternatives
              if ((oldestSoFar == null) ||
                  (oldestSoFar.datatimestamp > ((NewsElement) h.get(key)).datatimestamp))
              {
                   oldestSoFar = (NewsElement) h.get(key);
                   alternatives.clear();
                   alternatives.add(key);
              }
              // if equally old, add to alternatives
              else if (oldestSoFar.datatimestamp == ((NewsElement) h.get(key)).datatimestamp)
                  alternatives.add(key);
        }
        if (alternatives.size() == 0) return null;
        else if (alternatives.size() == 1) { singleChoices++; if (!key.equals(alternatives.get(0))) wrongSingleChoices++; return key; }
        else return alternatives.get(rand.nextInt(alternatives.size() - 1));
    }



    /**
     * Creates a new cache for this correspondent (and the supplied correspondent) by taking the
     * <code>cacheSize</code> newest elements from both correspondent's caches. If elements are
     * equally old the selection will be random.
     * @param peer the correspondent that we want to merge caches with
     */
    public void mergeCaches(Correspondent peer)
    {
        Enumeration e;
        Object key;

        cache = generateNewCache(cache, peer.cache);
        peer.cache = new Hashtable(cacheSize);
        e = cache.keys();
        while (e.hasMoreElements())
        {
            key = e.nextElement();
            peer.cache.put(key, cache.get(key));
        }
    }



    //this is used to generate new cache for both the parties involved in the communication
    private Hashtable generateNewCache(Hashtable h1, Hashtable h2)
    {
        Hashtable result = new Hashtable(cacheSize);
        Object key, oldest;
        RandomMethods rand = new RandomMethods();
        NewsElement temp1, temp2;

        // first put all elements from h1 in result,
        Enumeration e = h1.keys();
        while (e.hasMoreElements())
        {
            key = e.nextElement();
            result.put(key, h1.get(key));
        }

        // then add the elements from h2; if result is full and a newer element is to be added, replace the
        // oldest element in result
        e = h2.keys();
        while (e.hasMoreElements())
        {
            key = e.nextElement();
            // if there is no news element from this agent in result ....
            if (!result.containsKey(key))
            {
                temp1 = (NewsElement) h2.get(key);
                // and the cache is not full yet, add the element,
                if (result.size() < cacheSize) result.put(key, temp1);
                // but if the cache is full, check to see if there is an older element in result......
                else if (result.size() == cacheSize)
                {
                    oldest = oldest(result);
                    temp1 = (NewsElement) result.get(oldest);
                    temp2 = (NewsElement) h2.get(key);
                    // if the news element from h2 is newer than the oldest in result, replace oldest
                    if (temp1.datatimestamp < temp2.datatimestamp ||
                    // if both are equally old, replace with 50% probability
                        (temp1.datatimestamp == temp2.datatimestamp && rand.getBoolean()))
                    {
                        result.remove(oldest);
                        result.put(key, temp2);
                    }
                }
            }
            else
            // if there is a news element in result from the same agent, keep the newest one
            {
                temp1 = (NewsElement) h2.get(key);
                if (temp1.datatimestamp > ((NewsElement) result.get(key)).datatimestamp)
                    result.put(key, temp1);
            }
        }
        return result;
    }
}