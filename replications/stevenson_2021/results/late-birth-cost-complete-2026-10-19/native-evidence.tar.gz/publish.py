import csv,hashlib,json,math,shutil,statistics,subprocess,tarfile
from pathlib import Path
from scipy.stats import t
root=Path(__file__).resolve().parent
repo=Path('/Users/relh/Code/workspace/sugarscape-stevenson/replications/stevenson_2021')
python='/Users/relh/Code/workspace/sugarscape-replications/.venv/bin/python'
assert json.loads((root/'terminal.json').read_text())=={'exit_code':0,'completed_seeds':100}
audit=root/'full-audit'
subprocess.run([python,str(root/'analyze.py'),str(root),str(audit)],check=True)
rows=list(csv.DictReader((audit/'seed-means.csv').open()))
summary=json.loads((audit/'summary.json').read_text())
assert len(rows)==200
errors=[]
for record in summary['summary']:
 metric=record['metric']; early=[float(r[metric]) for r in rows if int(r['end'])==100000];late=[float(r[metric]) for r in rows if int(r['end'])==150000]
 values={'early':early,'late':late,'paired_late_minus_early':[b-a for a,b in zip(early,late)]}[record['window']]
 mean=math.fsum(values)/100;sd=statistics.stdev(values);half=float(t.ppf(.975,99))*sd/10
 for actual,expected in zip([mean,sd,mean-half,mean+half],[record['mean'],record['sd'],*record['ci95']]):
  assert abs(actual-expected)<1e-9;errors.append(abs(actual-expected))
(root/'independent-statistics.json').write_text(json.dumps(dict(verified_quantities=len(errors),maximum_absolute_error=max(errors),tolerance=1e-9),indent=2)+'\n')
result=repo/'results/late-birth-cost-complete-2026-10-19';result.mkdir()
for source in [audit/'summary.json',audit/'seed-means.csv',root/'independent-statistics.json',root/'protocol.json',root/'terminal.json',root/'completed.jsonl']:
 shutil.copyfile(source,result/source.name)
files=[p for p in root.rglob('*') if p.is_file()]
archive=result/'native-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(archive) as tar:
 for member in tar:
  assert tar.extractfile(member).read()==(root/member.name).read_bytes()
receipt=dict(bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),member_count=len(files),all_member_bytes_verified=True,member_sha256={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)})
(result/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Published full result',result,flush=True)
