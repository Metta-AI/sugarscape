import hashlib
import json
import shutil
import subprocess
import time
from pathlib import Path

root = Path('/Users/relh/Code/workspace')
out = Path(__file__).resolve().parent
protocol = json.loads((out/'protocol.json').read_text())
for name, expected in protocol['input_sha256'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == expected
assert shutil.disk_usage(out).free > 2*1024**3
(out/'independent').mkdir()
java = '/opt/homebrew/opt/openjdk@11/bin/java'
classpath = str(out) + ':' + str(root/'sugarscape-replication-tools/NetLogo 6.1.1/app/*')
native = [java, '-Xmx1g', '-Djava.awt.headless=true', '-cp', classpath, 'Replay',
          str(root/'sugarscape-nofreelunch-reference/data/sugarscape/Sugarscape trade.nlogo'),
          str(out/'parameters.csv'), '0','64',str(out/'native')]
commands = [('native',native)]
for seed in protocol['fresh_seeds']:
    commands.append((f'independent-{seed}',[str(root/'sugarscape-replications/.venv/bin/python'),
        str(root/'sugarscape-carrella/replications/carrella_2021/model.py'),
        str(out/'independent-parameters'/f'{seed}.json'), str(out/'independent'/f'row-{seed}.csv')]))
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
with (out/'completed.jsonl').open('x') as ledger:
    for name, command in commands:
        assert shutil.disk_usage(out).free > 2*1024**3
        started=time.monotonic()
        with (out/f'{name}.log').open('x') as log:
            result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=False)
        receipt={'name':name,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-started}
        ledger.write(json.dumps(receipt)+'\n');ledger.flush()
        print(json.dumps(receipt),flush=True)
        assert result.returncode==0
        assert sum(p.stat().st_size for p in out.rglob('*') if p.is_file()) < protocol['maximum_outputs_bytes']
(out/'complete.json').write_text(json.dumps({'native_runs':64,'independent_runs':64,'exit_code':0})+'\n')
