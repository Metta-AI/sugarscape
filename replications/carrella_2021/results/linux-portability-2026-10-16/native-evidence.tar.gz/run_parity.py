import concurrent.futures
import hashlib
import json
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parent
for name, digest in json.loads((root / "checksums.json").read_text()).items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest
indices = json.loads((root / "handoff.json").read_text())["parity_inputs"]


def replay(index):
    command = [
        "/root/sugarscape/venv/bin/python",
        str(root / "run_independent.py"),
        str(root / "params_sugarscape.csv"),
        str(root / "sugarscape.csv"),
        str(index),
        str(index + 1),
        str(root / f"parity-{index}"),
    ]
    with (root / f"parity-{index}.log").open("x") as log:
        subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
    return index


with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
    completed = list(pool.map(replay, indices))
(root / "parity-complete.json").write_text(json.dumps({"completed": completed}) + "\n")
