#!/bin/sh
set -u
cd /root/sugarscape/carrella-handoff-001
timeout --signal=TERM --kill-after=30s 3600 /root/sugarscape/venv/bin/python run_parity.py > parity-launcher.log 2>&1
code=$?
printf '{"exit_code":%s}\n' "$code" > parity-terminal.json
tar -czf /root/sugarscape/carrella-parity-evidence-001.tar.gz -C /root/sugarscape carrella-handoff-001
curl --max-time 20 --noproxy '*' -fsS -X POST -H 'Metadata-Flavor: givemeanode' http://169.254.42.1/v1/stop
exit "$code"
