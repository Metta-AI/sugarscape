from pathlib import Path
import subprocess,json,os,time
root=Path(__file__).parent
inputs=root.parent/'carrella-independent-estimator-inputs-complete-001'
env=dict(os.environ,R_LIBS_USER='/Users/relh/Code/workspace/sugarscape-replication-tools/R-library')
for size in [1250,5000]:
 cmd=['/opt/homebrew/bin/gtimeout','--signal=TERM','--kill-after=30','14400','/opt/homebrew/bin/Rscript','-e','options(warn=1); source('+json.dumps(str(root/'run_estimator.R'))+')',str(inputs),'rfboot',str(size),'0',str(root/f'rfboot-{size}')]
 (root/f'command-{size}.json').write_text(json.dumps(cmd,indent=2)+'\n')
 start=time.monotonic()
 with (root/f'run-{size}.log').open('x') as log:
  result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 (root/f'exit-{size}.json').write_text(json.dumps({'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start})+'\n')
 assert result.returncode==0
 for name,arguments in [('audit_independent_folds.R',[str(inputs),str(root/f'rfboot-{size}'),str(root/f'audit-{size}-folds')]),('analyze_estimator.R',[str(root/f'rfboot-{size}'),str(root/f'audit-{size}-predictions')])]:
  with (root/f'{name}-{size}.log').open('x') as log:subprocess.run(['/opt/homebrew/bin/Rscript',str(root/name),*arguments],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 print(f'Bootstrap forest {size} completed and audited',flush=True)
