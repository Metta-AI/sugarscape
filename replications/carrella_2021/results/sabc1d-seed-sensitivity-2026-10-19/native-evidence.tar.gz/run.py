import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
source=Path('/Users/relh/Code/workspace/sugarscape-nofreelunch-reference')
primary=Path('/Users/relh/Code/workspace/sugarscape-carrella/replications/carrella_2021/results/sabc1d-1250-2026-10-15')
protocol=dict(seeds=list(range(1,11)),method='sabc_1d',size=1250,cv_seed=0,seconds_per_seed=600,scope='Exploratory estimator-randomness sensitivity on fixed author data and original folds. Retain all ten seeds. Does not identify historical RNG state or replace primary scores.',source_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [source/'setup.R',source/'data/sugarscape/sugarscape.csv',source/'data/sugarscape/params_sugarscape.csv',root/'run_estimator.R',root/'analyze_estimator.R',root/'audit_inputs.R']})
assert subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True)==''
(root/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
env=dict(os.environ,R_LIBS_USER='/Users/relh/Code/workspace/sugarscape-replication-tools/R-library')
for seed in protocol['seeds']:
 for filename,digest in protocol['hashes'].items(): assert hashlib.sha256(Path(filename).read_bytes()).hexdigest()==digest
 run=root/f'seed-{seed:02d}'
 command=['/opt/homebrew/bin/gtimeout','--signal=TERM','--kill-after=30','600','/opt/homebrew/bin/Rscript','--vanilla',str(root/'run_estimator.R'),str(source),'sabc_1d','1250',str(seed),str(run)]
 started=time.time()
 with (root/f'seed-{seed:02d}.log').open('w') as log: result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
 (root/f'seed-{seed:02d}-exit.json').write_text(json.dumps(dict(command=command,exit_code=result.returncode,elapsed_seconds=time.time()-started),indent=2)+'\n')
 assert result.returncode==0
 subprocess.run(['/opt/homebrew/bin/Rscript','--vanilla',str(root/'audit_inputs.R'),str(primary),str(run),str(root/f'seed-{seed:02d}-input-audit.json')],env=env,check=True)
 subprocess.run(['/opt/homebrew/bin/Rscript','--vanilla',str(root/'analyze_estimator.R'),str(run),str(root/f'seed-{seed:02d}-prediction-audit')],env=env,check=True)
 print('Audited seed',seed,flush=True)
(root/'terminal.json').write_text(json.dumps(dict(completed_seeds=protocol['seeds'],exit_code=0))+'\n')
