import csv,hashlib,json,statistics,tarfile
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/Users/relh/Code/workspace/sugarscape-carrella/replications/carrella_2021')
protocol=json.loads((root/'protocol.json').read_text())
terminal=json.loads((root/'terminal.json').read_text())
assert terminal['completed_seeds']==protocol['seeds'] and terminal['exit_code']==0
published=json.loads((repo/'published_table8.json').read_text())
column=published['columns'].index('Semi-automatic ABC 1D')
targets={row[1]:float(row[column]) for row in published['rows'] if row[0]=='Sugarscape ABM 1,250'}
primary={row['parameter']:float(row['performance']) for row in csv.DictReader((repo/'results/sabc1d-1250-2026-10-15/metrics.csv').open())}
rows=[]
package_bytes=(root/'seed-01/packages.csv').read_bytes()
for seed in protocol['seeds']:
 run=root/f'seed-{seed:02d}'
 assert (run/'packages.csv').read_bytes()==package_bytes
 assert json.loads((root/f'seed-{seed:02d}-exit.json').read_text())['exit_code']==0
 assert json.loads((root/f'seed-{seed:02d}-input-audit.json').read_text())['exact_input_cells']==943750
 metrics=list(csv.DictReader((run/'metrics.csv').open()))
 assert len(metrics)==5
 for metric in metrics:
  assert metric['method']=='sabc_1d' and int(metric['size'])==1250 and int(metric['seed'])==seed
  rows.append(dict(seed=seed,parameter=metric['parameter'],performance=float(metric['performance'])))
primary_packages={r['Package']:r['Version'] for r in csv.DictReader((repo/'results/sabc1d-1250-2026-10-15/packages.csv').open())}
current_packages={r['Package']:r['Version'] for r in csv.DictReader((root/'seed-01/packages.csv').open())}
relevant=['abc','abctools','R.utils','dplyr','purrr','tidyr','readr']
assert all(primary_packages[k]==current_packages[k] for k in relevant)
summary=[]
for parameter,target in targets.items():
 values=[row['performance'] for row in rows if row['parameter']==parameter]
 assert len(values)==10
 summary.append(dict(parameter=parameter,published=target,primary_seed_zero=primary[parameter],seed_count=len(values),mean=statistics.mean(values),sample_sd=statistics.stdev(values),minimum=min(values),maximum=max(values),published_within_observed_range=min(values)<=target<=max(values)))
out=repo/'results/sabc1d-seed-sensitivity-2026-10-19'
out.mkdir(exist_ok=False)
report=dict(matched_primary_package_versions={k:current_packages[k] for k in relevant},seeds=protocol['seeds'],summary=summary,validated_predictions=62500,verified_input_cells=9437500,scope='Ten estimator seeds on fixed author data and partitions. Observed ranges are not confidence intervals. No historical-RNG identification, statistical-equivalence claim, new primary matches or paper completion.')
(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
with (out/'scores.csv').open('w') as output:
 writer=csv.DictWriter(output,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
files=[p for p in root.rglob('*') if p.is_file()]
archive=out/'native-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(files): tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(archive) as tar:
 for member in tar:
  assert tar.extractfile(member).read()==(root/member.name).read_bytes()
(out/'archive-receipt.json').write_text(json.dumps(dict(bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=len(files),all_members_byte_checked=True,source_hashes={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}),indent=2)+'\n')
(out/'protocol.json').write_bytes((root/'protocol.json').read_bytes())
print(json.dumps(report,indent=2))
