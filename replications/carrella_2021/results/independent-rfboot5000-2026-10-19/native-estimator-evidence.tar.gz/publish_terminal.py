import csv
import hashlib
import json
import math
import shutil
import tarfile
from pathlib import Path

base = Path(__file__).resolve().parent
repo = Path('/Users/relh/Code/workspace/sugarscape-carrella/replications/carrella_2021')
run = base / 'rfboot-5000'
root = repo / 'results/independent-rfboot5000-2026-10-19'
root.mkdir(exist_ok=False)
metrics = list(csv.DictReader((run / 'metrics.csv').open()))
predictions = list(csv.DictReader((base / 'terminal-prediction-audit/predictions.csv').open()))
assert len(predictions) == 25000 and len(metrics) == 5
checks = []
for recorded in metrics:
    values = [r for r in predictions if r['parameter'] == recorded['parameter']]
    errors = []
    for fold in range(1, 6):
        rows = [r for r in values if int(r['fold']) == fold]
        assert len(rows) == 1000
        errors.append(math.sqrt(math.fsum((float(r['prediction']) - float(r['truth'])) ** 2 for r in rows) / len(rows)))
    rmse = math.fsum(errors) / 5
    coverage = sum(float(r['low']) <= float(r['truth']) <= float(r['high']) for r in values) / len(values)
    width = math.fsum(float(r['high']) - float(r['low']) for r in values) / len(values)
    performance = 1 - rmse / float(recorded['baseline_rmse'])
    actual = dict(rmse=rmse, coverage=coverage, interval_width=width, performance=performance)
    for name, value in actual.items():
        assert abs(value - float(recorded[name])) < 1e-10, (name, value, recorded[name])
    checks.append(dict(parameter=recorded['parameter'], predictions=len(values), **actual))
(root / 'python-metric-audit.json').write_text(json.dumps(dict(predictions=25000, tolerance=1e-10, parameters=checks), indent=2) + '\n')
for source, target in [
    (run / 'metrics.csv', 'metrics.csv'),
    (run / 'session.txt', 'session.txt'),
    (run / 'packages.csv', 'packages.csv'),
    (base / 'protocol.json', 'protocol.json'),
    (base / 'terminal-fold-audit/audit.json', 'fold-input-audit.json'),
    (base / 'terminal-prediction-audit/validated_metrics.csv', 'validated-metrics.csv'),
]:
    shutil.copyfile(source, root / target)
files = {str(p.relative_to(base)): p for directory in [run, base / 'terminal-fold-audit', base / 'terminal-prediction-audit'] for p in directory.iterdir() if p.is_file()}
for name in ['protocol.json', 'command.json', 'resume_estimator.R', 'run.log', 'publish_terminal.py']:
    files[name] = base / name
for name in ['audit_independent_folds.R', 'analyze_estimator.R']:
    files['auditors/' + name] = repo / name
archive = root / 'native-estimator-evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for name, path in sorted(files.items()):
        tar.add(path, arcname=name, recursive=False)
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(files)
    for member in tar:
        assert tar.extractfile(member).read() == files[member.name].read_bytes()
receipt = dict(bytes=archive.stat().st_size, sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), files=len(files), all_member_bytes_match_retained_outputs=True, limitation='No terminal launcher exit receipt available; complete folds, original inputs and metrics audited directly. No process-exit claim inferred.', member_sha256={name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in sorted(files.items())})
(root / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
manifest = repo / 'ESTIMATOR_COMPARISON_INPUTS.json'
contents = json.loads(manifest.read_text())
entry = str(root.relative_to(repo))
assert entry not in contents['independent_results']
contents['independent_results'].append(entry)
manifest.write_text(json.dumps(contents, indent=2) + '\n')
print(json.dumps(checks, indent=2))
