"""Compare a completed graphical-source control with the retained benchmark observer."""
import argparse
import csv
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('run', type=Path)
parser.add_argument('reference', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
protocol = json.loads((args.run / 'protocol.json').read_text())
assert (args.run / 'compiler.txt').read_text().strip() == '8.4.3'
assert (args.run / 'project/exit-code.txt').read_text().strip() == '0'
for name, digest in protocol['source_sha256'].items():
    assert hashlib.sha256((args.run / 'project' / name).read_bytes()).hexdigest() == digest
rows = []
for name in ['popSize.csv','agents-49.csv','agents-50.csv','cells-49.csv','cells-50.csv']:
    actual = (args.run / 'project' / name).read_bytes()
    expected = (args.reference / name).read_bytes()
    with (args.run / 'project' / name).open() as stream:
        count = len(list(csv.DictReader(stream)))
    rows.append({'file':name,'rows':count,'actual_sha256':hashlib.sha256(actual).hexdigest(),'reference_sha256':hashlib.sha256(expected).hexdigest(),'byte_identical':actual == expected})
report = {'files':rows,'all_outputs_byte_identical':all(r['byte_identical'] for r in rows),'source_hashes_verified':len(protocol['source_sha256']),'scope':'Graphical sequential model sources with existing observation entry point and fixed500-agent seed42 no-rebirth configuration. Not an actual GUI run or proof of historical screenshot configuration.','auditor_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
with args.output.open('x') as stream:
    json.dump(report,stream,indent=2)
    stream.write('\n')
print(json.dumps(report,indent=2))
