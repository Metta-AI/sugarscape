#!/bin/bash
set -euo pipefail
root=/root/sugarscape/thaler-observation-001
mkdir -p "$root"
cd "$root"
exec > >(tee -a workflow.log) 2>&1
trap 'rc=$?; printf "%s\n" "$rc" > workflow-exit.txt; tar -czf /root/sugarscape/thaler-observation-001.partial.tar.gz --exclude=".stack-work" .; mv /root/sugarscape/thaler-observation-001.partial.tar.gz /root/sugarscape/thaler-observation-001.tar.gz; exit "$rc"' EXIT
[ "$(df -Pk /root | awk 'NR==2 {print $4}')" -ge 5242880 ]
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq haskell-stack git curl ca-certificates gcc make libgmp-dev libtinfo5 freeglut3-dev python3
mkdir -p /root/.stack
cp stack-global-config.yaml /root/.stack/config.yaml
uname -a > versions.txt
stack --version >> versions.txt
lscpu --json > hardware.json
bash simulate.sh
