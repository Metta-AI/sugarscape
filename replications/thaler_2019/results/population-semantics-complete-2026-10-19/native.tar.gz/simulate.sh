#!/bin/bash
set -euo pipefail
cd /root/sugarscape/thaler-observation-001/prepared/criterion/sugarscape-tarray
stack build --jobs 1 > /root/sugarscape/thaler-observation-001/build.log 2>&1
stack exec -- ghc --numeric-version > /root/sugarscape/thaler-observation-001/compiler.txt
binary="$(stack path --local-install-root)/bin/sugarscape-tarray"
sha256sum "$binary" > /root/sugarscape/thaler-observation-001/binary.sha256
for repetition in 1 2; do
  timeout 600 "$binary" 500 False +RTS -N1 -RTS > /root/sugarscape/thaler-observation-001/normal-$repetition.csv 2> /root/sugarscape/thaler-observation-001/normal-$repetition.stderr
  timeout 600 "$binary" 2500 True +RTS -N1 -RTS > /root/sugarscape/thaler-observation-001/rebirth-$repetition.csv 2> /root/sugarscape/thaler-observation-001/rebirth-$repetition.stderr
done
printf '0\n' > /root/sugarscape/thaler-observation-001/exit-code.txt
