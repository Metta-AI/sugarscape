set -eu
cd /work
trap 'rc=$?; printf "%s\n" "$rc" > exit-code.txt' EXIT
cd project
timeout 900 stack build --jobs 1 > /work/build.log 2>&1
stack exec -- ghc --numeric-version > /work/compiler.txt
test "$(cat /work/compiler.txt)" = '8.4.3'
stack path --local-install-root > /work/install-root.txt
binary="$(cat /work/install-root.txt)/bin/sugarscape-seq"
sha256sum "$binary" > /work/binary-sha256.txt
timeout 240 "$binary" > /work/native.stdout 2> /work/native.stderr
