from pathlib import Path
import concurrent.futures,json,subprocess,os,time,shutil,tarfile,hashlib,urllib.request
root=Path(__file__).resolve().parent
assert shutil.disk_usage(root).free>=8*1024**3
engine=root/'engine';python=root/'venv/bin/python'
for name in ['blueprints-selfishness.zip','blueprints-heterogeneous.zip']:
 urllib.request.urlretrieve('https://raw.githubusercontent.com/digital-terraria-lab/datasets/0b50404c2529aa0ab08ce14c7f7abfe30fab837e/'+name,root/name)
subprocess.run(['git','-c','alias.clone-lean=clone --filter=blob:none','clone-lean','--no-checkout','https://github.com/digital-terraria-lab/sugarscape.git',str(engine)],check=True,timeout=300)
subprocess.run(['git','checkout','b9ca671ab7591c7b3606f2d76c33eda344d626d1'],cwd=engine,check=True,timeout=300)
subprocess.run(['/root/sugarscape/pike-venv/bin/python','-m','venv',str(root/'venv')],check=True,timeout=120)
subprocess.run([str(python),'-m','pip','install','pydantic==2.12.3'],check=True,timeout=180)
subprocess.run([str(python),'-c','import sys,pydantic; assert sys.version_info[:3]==(3,11,14); assert pydantic.__version__=="2.12.3"'],check=True)
seed=158402133555746433
conditions=[('selfishness',f'{factor}-benthamHalfLookaheadBinary{seed}.config') for factor in ['0.0','0.5','1.0']]+[('heterogeneous',f'{count}-benthamHalfLookaheadBinary-egoisticHalfLookaheadBinary{seed}.config') for count in [1,50,99]]
(root/'runs').mkdir()
manifest={'conditions':conditions,'workers':4,'seconds':7200,'frozen_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ['run_supplement.py','source-sha256.json','SUPPLEMENT_PROTOCOL.md']}}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
started=time.monotonic()
def execute(condition):
 experiment,entry=condition
 target=root/'runs'/entry.removesuffix('.config')
 command=[str(python),str(root/'run_supplement.py'),str(engine),str(root/('blueprints-'+experiment+'.zip')),experiment,entry,str(target)]
 with (root/(entry+'.log')).open('x') as log:
  result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=7200-(time.monotonic()-started))
 receipt={'experiment':experiment,'entry':entry,'command':command,'exit_code':result.returncode}
 (root/(entry+'.exit.json')).write_text(json.dumps(receipt)+'\n')
 assert result.returncode==0,receipt
 return receipt
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 with (root/'completed.jsonl').open('x') as ledger:
  for result in pool.map(execute,conditions): ledger.write(json.dumps(result)+'\n');ledger.flush()
(root/'terminal.json').write_text(json.dumps({'exit_code':0,'completed_runs':6,'elapsed_seconds':time.monotonic()-started})+'\n')
archive=root.parent/'blueprints-supplement-evidence-001.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for path in root.iterdir():
  if path.name not in ['engine','venv','blueprints-selfishness.zip','blueprints-heterogeneous.zip']:t.add(path,arcname=path.name)
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}),flush=True)
