"""Retry only terminal original inputs, retaining all prior failed evidence."""
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

from pydantic import BaseModel


class FailedAttempt(BaseModel):
    index: int
    seed: int
    command: list[str]
    exit_code: int
    elapsed_seconds: float


root = Path(__file__).resolve().parent
workspace = root.parent.parent
suite = workspace / 'sugarscape-blueprints/replications/blueprints_2024'
python = workspace / 'sugarscape-replications/.venv/bin/python'
archive = root.parent / 'papers/blueprints-homogeneous.zip'
engine = workspace / 'sugarscape-dtl-blueprints-reference'
failed = [FailedAttempt.model_validate(x) for x in json.loads((root / 'failed-attempts.json').read_text())]
assert len(failed) == len({x.index for x in failed}) == 21
assert all(x.exit_code == 124 for x in failed)
assert shutil.disk_usage(root).free > 3 * 1024**3
pins = {name: hashlib.sha256((suite / name).read_bytes()).hexdigest() for name in ['run.py', 'run_batch.py', 'audit_batch.py']}
(root / 'start.json').write_text(json.dumps({'unix': time.time(), 'workers': 2, 'per_input_seconds': 7200, 'group_seconds': 21600, 'indices': [x.index for x in failed], 'source_pins': pins, 'scope': 'Exact original timed-out inputs; operational time limit and host change only.'}, indent=2) + '\n')


def run_input(attempt):
    assert all(hashlib.sha256((suite / name).read_bytes()).hexdigest() == digest for name, digest in pins.items())
    assert shutil.disk_usage(root).free > 2 * 1024**3
    name = f'input-{attempt.index:03d}'
    command = ['/opt/homebrew/bin/gtimeout', '--signal=TERM', '--kill-after=30', '7200', str(python), str(suite / 'run_batch.py'), str(engine), str(archive), 'benthamHalfLookaheadBinary', str(root / name), '--start', str(attempt.index), '--stop', str(attempt.index + 1)]
    started = time.monotonic()
    with (root / (name + '.log')).open('xb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    record = {'index': attempt.index, 'seed': attempt.seed, 'command': command, 'exit_code': result.returncode, 'elapsed_seconds': time.monotonic() - started}
    if result.returncode == 0:
        ledger = (root / name / 'completed.jsonl').read_bytes()
        records = [json.loads(line) for line in ledger.splitlines()]
        assert len(records) == 1 and records[0]['seed'] == attempt.seed
        audit = [str(python), str(suite / 'audit_batch.py'), str(archive), str(root / name), str(root / 'audits' / name)]
        with (root / (name + '-audit.log')).open('xb') as log:
            subprocess.run(audit, stdout=log, stderr=subprocess.STDOUT, check=True)
        record['completed_ledger_sha256'] = hashlib.sha256(ledger).hexdigest()
        record['audit_sha256'] = hashlib.sha256((root / 'audits' / name / 'audit.json').read_bytes()).hexdigest()
    return record


with (root / 'attempts.jsonl').open('x') as ledger, ThreadPoolExecutor(max_workers=2) as pool:
    futures = [pool.submit(run_input, attempt) for attempt in failed]
    for future in as_completed(futures):
        record = future.result()
        ledger.write(json.dumps(record) + '\n')
        ledger.flush()
        print(json.dumps({k: record[k] for k in ['index', 'exit_code', 'elapsed_seconds']}), flush=True)
(root / 'terminal.json').write_text(json.dumps({'unix': time.time(), 'attempted': len(failed)}) + '\n')
