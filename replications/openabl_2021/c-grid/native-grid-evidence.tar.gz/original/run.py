import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
workspace = root.parent.parent
compiler = root.parent / 'openabl-build-001/OpenABL'
assets = workspace / 'sugarscape-openabl-reference/asset'
validators = workspace / 'sugarscape-openabl/replications/openabl_2021'
protocol = json.loads((root / 'protocol.json').read_text())
for name in ['initialize.py', 'replay.py']:
    shutil.copy2(validators / name, root / name)
env = os.environ.copy()
env['OMP_NUM_THREADS'] = '1'
with (root / 'completed.jsonl').open('x') as ledger:
    for size in protocol['requested_cells']:
        assert shutil.disk_usage(root).free > 1024**3
        out = root / str(size)
        out.mkdir()
        commands = [
            [str(compiler), '-i', str(root / 'observed.abl'), '-o', str(out / 'generated'), '-b', 'c', '-A', str(assets), '-P', f'num_agents={size}', '-P', 'num_timesteps=100'],
            ['/opt/homebrew/bin/gcc-16', '-O2', '-std=c99', 'main.c', 'libabl.c', '-lm', '-fopenmp', '-o', 'main'],
            [str(out / 'generated/main')],
            [sys.executable, str(root / 'initialize.py'), str(out / 'initial.json'), str(out / 'initialization-audit.json'), '--requested-cells', str(size)],
            [sys.executable, str(root / 'replay.py'), str(out / 'initial.json'), str(out / 'final.json'), str(out / 'replay-audit.json'), '--steps', '100', '--buffer', 'stale'],
        ]
        (out / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        for i, command in enumerate(commands):
            started = time.monotonic()
            with (out / f'stage-{i}.log').open('x') as log:
                result = subprocess.run(command, cwd=out / 'generated' if i == 1 else out, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=14400 if i == 4 else 3600)
            (out / f'stage-{i}-exit.json').write_text(json.dumps({'exit_code': result.returncode, 'elapsed_seconds': time.monotonic() - started}) + '\n')
            result.check_returncode()
        record = {'requested_cells': size, 'initialization': json.loads((out / 'initialization-audit.json').read_text()), 'replay': json.loads((out / 'replay-audit.json').read_text()), 'sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*.json')}}
        ledger.write(json.dumps(record) + '\n')
        ledger.flush()
        print(f'Validated {size}', flush=True)
