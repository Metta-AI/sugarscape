#include "libabl.h"

typedef struct {
    float2 pos;
    float2 target_pos;
    int agent_id;
    int state;
    int sugar_level;
    int metabolism;
    int env_sugar_level;
    int max_env_sugar_level;
} Agent;
static const type_info Agent_info[] = {
    { TYPE_FLOAT2, offsetof(Agent, pos), "pos", true },
    { TYPE_FLOAT2, offsetof(Agent, target_pos), "target_pos", false },
    { TYPE_INT, offsetof(Agent, agent_id), "agent_id", false },
    { TYPE_INT, offsetof(Agent, state), "state", false },
    { TYPE_INT, offsetof(Agent, sugar_level), "sugar_level", false },
    { TYPE_INT, offsetof(Agent, metabolism), "metabolism", false },
    { TYPE_INT, offsetof(Agent, env_sugar_level), "env_sugar_level", false },
    { TYPE_INT, offsetof(Agent, max_env_sugar_level), "max_env_sugar_level", false },
    { TYPE_END, sizeof(Agent), NULL }
};

struct agent_struct {
    dyn_array agents_Agent;
    dyn_array agents_Agent_dbuf;
};
struct agent_struct agents;
static const agent_info agents_info[] = {
    { Agent_info, offsetof(struct agent_struct, agents_Agent), "Agent" },
    { NULL, 0, NULL }
};

double PI = 3.14159;
int AGENT_STATE_UNOCCUPIED = 0;
int AGENT_STATE_OCCUPIED = 1;
int AGENT_STATE_MOVEMENT_REQUESTED = 2;
int AGENT_STATE_MOVEMENT_UNRESOLVED = 3;
int SUGAR_GROWBACK_RATE = 1;
int min_start_sugar_level = 1;
int max_start_sugar_level = 10;
double radius = 1.5;
int num_timesteps = 100;
double occupiedFrac = 0.1;
int num_agents = 500;
int grid_width = 22;
float2 sugar_center1 = {5.5, 5.5};
float2 sugar_center2 = {16.5, 16.5};
int global_max_env_sugar_level = 50;
double sugar_variance = 12.1;
float2 random_1(float2 min, float2 max) {
    return float2_create(random_float(min.x, max.x), random_float(min.y, max.y));
}
float3 random_2(float3 min, float3 max) {
    return float3_create(random_float(min.x, max.x), random_float(min.y, max.y), random_float(min.z, max.z));
}
double random_3(double max) {
    return random_float(0, max);
}
float2 random_4(float2 max) {
    return random_1(float2_fill(0), max);
}
float3 random_5(float3 max) {
    return random_2(float3_fill(0), max);
}
int randomInt_1(int max) {
    return random_int(0, max);
}
double clamp(double pos, double min, double max) {
    return ((pos < min) ? min : ((pos > max) ? max : pos));
}
float2 clamp_1(float2 pos, float2 min, float2 max) {
    return float2_create(((pos.x < min.x) ? min.x : ((pos.x > max.x) ? max.x : pos.x)), ((pos.y < min.y) ? min.y : ((pos.y > max.y) ? max.y : pos.y)));
}
float3 clamp_2(float3 pos, float3 min, float3 max) {
    return float3_create(((pos.x < min.x) ? min.x : ((pos.x > max.x) ? max.x : pos.x)), ((pos.y < min.y) ? min.y : ((pos.y > max.y) ? max.y : pos.y)), ((pos.z < min.z) ? min.z : ((pos.z > max.z) ? max.z : pos.z)));
}
double clamp_3(double pos, double max) {
    return clamp(pos, 0, max);
}
float2 clamp_4(float2 pos, float2 max) {
    return clamp_1(pos, float2_fill(0), max);
}
float3 clamp_5(float3 pos, float3 max) {
    return clamp_2(pos, float3_fill(0), max);
}
double wraparound(double pos, double max) {
    return ((pos < 0) ? (max + pos) : ((pos >= max) ? (pos - max) : pos));
}
float2 wraparound_1(float2 pos, float2 max) {
    return float2_create(((pos.x < 0) ? (max.x + pos.x) : ((pos.x >= max.x) ? (pos.x - max.x) : pos.x)), ((pos.y < 0) ? (max.y + pos.y) : ((pos.y >= max.y) ? (pos.y - max.y) : pos.y)));
}
float3 wraparound_2(float3 pos, float3 max) {
    return float3_create(((pos.x < 0) ? (max.x + pos.x) : ((pos.x >= max.x) ? (pos.x - max.x) : pos.x)), ((pos.y < 0) ? (max.y + pos.y) : ((pos.y >= max.y) ? (pos.y - max.y) : pos.y)), ((pos.z < 0) ? (max.z + pos.z) : ((pos.z >= max.z) ? (pos.z - max.z) : pos.z)));
}
bool is_inside(float2 pos, float2 max) {
    return ((((pos.x >= 0) && (pos.y >= 0)) && (pos.x <= max.x)) && (pos.y <= max.y));
}
void metabolise_and_growback(Agent* in, Agent* out) {
    int new_env_sugar_level = in->env_sugar_level;
    if ((in->state == AGENT_STATE_OCCUPIED)) {
        int new_sugar_level = ((in->sugar_level + in->env_sugar_level) - in->metabolism);
        new_env_sugar_level = 0;
        if ((new_sugar_level <= 0)) {
            out->state = AGENT_STATE_UNOCCUPIED;
            out->agent_id = (-1);
            out->sugar_level = 0;
            out->metabolism = 0;
        } else {
            out->state = AGENT_STATE_MOVEMENT_UNRESOLVED;
            out->sugar_level = new_sugar_level;
        }
    }
    new_env_sugar_level += SUGAR_GROWBACK_RATE;
    if ((new_env_sugar_level > in->max_env_sugar_level)) {
        new_env_sugar_level = in->max_env_sugar_level;
    }
    out->env_sugar_level = new_env_sugar_level;
}
void movement_request(Agent* in, Agent* out) {
    if ((in->state == AGENT_STATE_MOVEMENT_UNRESOLVED)) {
        int best_sugar_level = (-1);
        float2 best_pos = float2_fill(0);
        for (size_t _var1 = 0; _var1 < agents.agents_Agent.len; _var1++) {
            Agent* nx = DYN_ARRAY_GET(&agents.agents_Agent, Agent, _var1);
            if (dist_float2(nx->pos, in->pos) > radius) continue;
            {
                if (float2_equals(nx->pos, in->pos)) continue;
                if (((nx->state == AGENT_STATE_UNOCCUPIED) && (nx->env_sugar_level > best_sugar_level))) {
                    best_sugar_level = nx->env_sugar_level;
                    best_pos = nx->pos;
                }
            }
        }
        if ((best_sugar_level > in->env_sugar_level)) {
            out->state = AGENT_STATE_MOVEMENT_REQUESTED;
            out->target_pos = best_pos;
        } else {
            out->state = AGENT_STATE_OCCUPIED;
        }
    }
}
void movement_response(Agent* in, Agent* out) {
    if ((in->state == AGENT_STATE_UNOCCUPIED)) {
        int best_priority = (-1);
        int best_agent_id = (-1);
        int best_sugar_level = (-1);
        int best_metabolism = (-1);
        for (size_t _var3 = 0; _var3 < agents.agents_Agent.len; _var3++) {
            Agent* nx = DYN_ARRAY_GET(&agents.agents_Agent, Agent, _var3);
            if (dist_float2(nx->pos, in->pos) > radius) continue;
            {
                if (((nx->state == AGENT_STATE_MOVEMENT_REQUESTED) && float2_equals(nx->target_pos, in->pos))) {
                    int message_priority = 0;
                    if ((message_priority > best_priority)) {
                        best_priority = message_priority;
                        best_agent_id = nx->agent_id;
                        best_sugar_level = nx->sugar_level;
                        best_metabolism = nx->metabolism;
                    }
                }
            }
        }
        if ((best_agent_id >= 0)) {
            out->state = AGENT_STATE_OCCUPIED;
            out->agent_id = best_agent_id;
            out->sugar_level = best_sugar_level;
            out->metabolism = best_metabolism;
        }
    }
}
void movement_transaction(Agent* in, Agent* out) {
    if ((in->state == AGENT_STATE_MOVEMENT_REQUESTED)) {
        bool moved = false;
        for (size_t _var5 = 0; _var5 < agents.agents_Agent.len; _var5++) {
            Agent* nx = DYN_ARRAY_GET(&agents.agents_Agent, Agent, _var5);
            if (dist_float2(nx->pos, in->pos) > radius) continue;
            {
                if (((nx->state == AGENT_STATE_OCCUPIED) && (nx->agent_id == in->agent_id))) {
                    moved = true;
                    out->state = AGENT_STATE_UNOCCUPIED;
                    out->agent_id = (-1);
                    out->sugar_level = 0;
                    out->metabolism = 0;
                }
            }
        }
        if ((!moved)) {
            out->state = AGENT_STATE_OCCUPIED;
        }
    }
}
int calc_max_env_sugar_level(int x, int y) {
    int gmax = global_max_env_sugar_level;
    float2 pos = float2_create(x, y);
    int max = 0;
    double d1 = dist_float2(pos, sugar_center1);
    max += ((float) gmax * exp((((-d1) * d1) / (2.0 * sugar_variance))));
    double d2 = dist_float2(pos, sugar_center2);
    max += ((float) gmax * exp((((-d2) * d2) / (2.0 * sugar_variance))));
    return max;
}
int main() {
    int id = 0;
    for (int x = 0, _var6 = grid_width; x < _var6; ++x) {
        for (int y = 0, _var7 = grid_width; y < _var7; ++y) {
            bool occupied = (random_3(1.0) < occupiedFrac);
            int max_env_sugar_level = calc_max_env_sugar_level(x, y);
            *DYN_ARRAY_PLACE(&agents.agents_Agent, Agent) = (Agent) {
                .pos = float2_create(((float) x + 0.5), ((float) y + 0.5)),
                .target_pos = float2_fill(0),
                .agent_id = id,
                .state = (occupied ? AGENT_STATE_OCCUPIED : AGENT_STATE_UNOCCUPIED),
                .sugar_level = (occupied ? random_int(min_start_sugar_level, max_start_sugar_level) : 0),
                .metabolism = (occupied ? 1 : 0),
                .env_sugar_level = random_int(0, max_env_sugar_level),
                .max_env_sugar_level = max_env_sugar_level,
            };
            id += 1;
        }
    }
    save(&agents, agents_info, "initial.json", SAVE_JSON);
    for (int _var8 = 0; _var8 < num_timesteps; _var8++) {
        dyn_array tmp;
        if (!agents.agents_Agent_dbuf.values) {
            agents.agents_Agent_dbuf = DYN_ARRAY_COPY_FIXED(Agent, &agents.agents_Agent);
        }
        #pragma omp parallel for
        for (size_t _var9 = 0; _var9 < agents.agents_Agent.len; _var9++) {
            Agent *_var10 = DYN_ARRAY_GET(&agents.agents_Agent, Agent, _var9);
            Agent *_var11 = DYN_ARRAY_GET(&agents.agents_Agent_dbuf, Agent, _var9);
            metabolise_and_growback(_var10, _var11);
        }
        tmp = agents.agents_Agent;
        agents.agents_Agent = agents.agents_Agent_dbuf;
        agents.agents_Agent_dbuf = tmp;
        if (!agents.agents_Agent_dbuf.values) {
            agents.agents_Agent_dbuf = DYN_ARRAY_COPY_FIXED(Agent, &agents.agents_Agent);
        }
        #pragma omp parallel for
        for (size_t _var12 = 0; _var12 < agents.agents_Agent.len; _var12++) {
            Agent *_var13 = DYN_ARRAY_GET(&agents.agents_Agent, Agent, _var12);
            Agent *_var14 = DYN_ARRAY_GET(&agents.agents_Agent_dbuf, Agent, _var12);
            movement_request(_var13, _var14);
        }
        tmp = agents.agents_Agent;
        agents.agents_Agent = agents.agents_Agent_dbuf;
        agents.agents_Agent_dbuf = tmp;
        if (!agents.agents_Agent_dbuf.values) {
            agents.agents_Agent_dbuf = DYN_ARRAY_COPY_FIXED(Agent, &agents.agents_Agent);
        }
        #pragma omp parallel for
        for (size_t _var15 = 0; _var15 < agents.agents_Agent.len; _var15++) {
            Agent *_var16 = DYN_ARRAY_GET(&agents.agents_Agent, Agent, _var15);
            Agent *_var17 = DYN_ARRAY_GET(&agents.agents_Agent_dbuf, Agent, _var15);
            movement_response(_var16, _var17);
        }
        tmp = agents.agents_Agent;
        agents.agents_Agent = agents.agents_Agent_dbuf;
        agents.agents_Agent_dbuf = tmp;
        if (!agents.agents_Agent_dbuf.values) {
            agents.agents_Agent_dbuf = DYN_ARRAY_COPY_FIXED(Agent, &agents.agents_Agent);
        }
        #pragma omp parallel for
        for (size_t _var18 = 0; _var18 < agents.agents_Agent.len; _var18++) {
            Agent *_var19 = DYN_ARRAY_GET(&agents.agents_Agent, Agent, _var18);
            Agent *_var20 = DYN_ARRAY_GET(&agents.agents_Agent_dbuf, Agent, _var18);
            movement_transaction(_var19, _var20);
        }
        tmp = agents.agents_Agent;
        agents.agents_Agent = agents.agents_Agent_dbuf;
        agents.agents_Agent_dbuf = tmp;
    }
    save(&agents, agents_info, "final.json", SAVE_JSON);
    return 0;
}
