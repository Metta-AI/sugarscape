import it.isislab.dmason.experimentals.systemmanagement.utils.activemq.ActiveMQStarter;
import it.isislab.dmason.experimentals.tools.batch.data.EntryParam;
import it.isislab.dmason.experimentals.tools.batch.data.GeneralParam;
import it.isislab.dmason.sim.engine.DistributedState;
import it.isislab.dmason.sim.field.DistributedField2D;
import it.isislab.dmason.util.connection.ConnectionType;
import java.util.ArrayList;
import sim.display.Console;

public class LocalTestSim {
    private static boolean graphicsOn = false;
    private static int rows = 1; // number of rows
    private static int columns = 2; // number of columns
    private static int lengths = 1; // number of lengths
    private static int AOI = 10; // max distance
    private static int NUM_AGENTS=20000; //number of agents
    private static int WIDTH = 63; // field width
    private static int HEIGHT = 63; // field height
    private static int LENGTH = 0; // field length
    private static String ip="127.0.0.1"; //ip of activemq
    private static String port="61616"; //port of activemq
    private static String topicPrefix="SIM-NAME"; //unique string to identify topics for this simulation 
    private static int MODE = DistributedField2D.UNIFORM_PARTITIONING_MODE;
    public static void main(String[] args) throws InterruptedException {
        ActiveMQStarter starter = new ActiveMQStarter();
        starter.startActivemq();
        System.setProperty("org.apache.activemq.SERIALIZABLE_PACKAGES", "*");
        class worker extends Thread {
            private Sim sim;
            public worker(Sim sim) {
                this.sim = sim;
                sim.random.setSeed(0L);
                sim.start();
                Observer.snapshot(sim, "initial");
            }
            public void run() {
                if (graphicsOn) {
                    while (true) sim.schedule.step(sim);
                } else {
                    sim.run();
                }
                Observer.snapshot(sim, "final");
            }
        }
        ArrayList<worker> myWorker = new ArrayList<worker>();
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                for (int z = 0; z < lengths; z++) {
                    GeneralParam genParam = new GeneralParam(
                        WIDTH, HEIGHT, LENGTH, AOI,
                        rows, columns, lengths, NUM_AGENTS, MODE, ConnectionType.pureActiveMQ, /* is3D */ false
                    ); 
                    genParam.setI(i);
                    genParam.setJ(j);
                    genParam.setZ(z);
                    genParam.setIp(ip);
                    genParam.setPort(port);
                    ArrayList<EntryParam<String, Object>> simParams=new ArrayList<EntryParam<String, Object>>();
                    if (graphicsOn && i == 0 && j == 0 && z == 0) {
                        SimWithUI sim = new SimWithUI(genParam,simParams,topicPrefix);
                        ((Console) sim.createController()).pressPause();
                    } else {
                        Sim sim = new Sim(genParam,simParams,topicPrefix); 
                        worker a = new worker(sim);
                        myWorker.add(a);
                    }
                }
            }
        }
            for (worker w : myWorker) {
                w.start();
            }
            for (worker w : myWorker) w.join();
            System.exit(0);
        }
    }
    