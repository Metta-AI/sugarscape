import sim.engine.*;
import sim.util.*;
import java.util.List;

import it.isislab.dmason.exception.DMasonException; 
import it.isislab.dmason.experimentals.tools.batch.data.EntryParam;
import it.isislab.dmason.experimentals.tools.batch.data.GeneralParam;
import it.isislab.dmason.sim.engine.DistributedMultiSchedule;
import it.isislab.dmason.sim.engine.DistributedState;
import it.isislab.dmason.sim.engine.RemotePositionedAgent;
import it.isislab.dmason.sim.field.DistributedField;
import it.isislab.dmason.sim.field.DistributedField2D;
import it.isislab.dmason.sim.field.continuous.DContinuousGrid2D;
import it.isislab.dmason.sim.field.continuous.DContinuousGrid2DFactory;

public class Sim extends DistributedState<Double2D> {
    public static double PI = 3.14159;
    public static int AGENT_STATE_UNOCCUPIED = 0;
    public static int AGENT_STATE_OCCUPIED = 1;
    public static int AGENT_STATE_MOVEMENT_REQUESTED = 2;
    public static int AGENT_STATE_MOVEMENT_UNRESOLVED = 3;
    public static int SUGAR_GROWBACK_RATE = 1;
    public static int min_start_sugar_level = 1;
    public static int max_start_sugar_level = 10;
    public static double radius = 1.5;
    public static int num_timesteps = 100;
    public static double occupiedFrac = 0.1;
    public static int num_agents = 4000;
    public static int grid_width = 63;
    public static Double2D sugar_center1 = new Double2D(15.75, 15.75);
    public static Double2D sugar_center2 = new Double2D(47.25, 47.25);
    public static int global_max_env_sugar_level = 50;
    public static double sugar_variance = 99.225;
    DContinuousGrid2D env;
    String topicPrefix;
    int MODE;
    public double gridWidth;
    public double gridHeight;
    public double gridLength;
    
    public Sim(GeneralParam params,String prefix) {
        super(params, new DistributedMultiSchedule<Double2D>(), prefix, params.getConnectionType());
        this.MODE = params.getMode();
        this.topicPrefix = prefix;
        gridWidth = params.getWidth();
        gridHeight = params.getHeight();
        gridLength = params.getLenght();
        
    }
    
    public Sim(GeneralParam params,List<EntryParam<String, Object>> simParams,String prefix) {
        super(params, new DistributedMultiSchedule<Double2D>(),prefix,params.getConnectionType());
        this.MODE = params.getMode();
        this.topicPrefix = prefix;
        gridWidth = params.getWidth();
        gridHeight = params.getHeight();
        gridLength = params.getLenght();
        for (EntryParam<String, Object> entryParam : simParams) {
            try { 
            this.getClass().getDeclaredField(entryParam.getParamName()).set(this, entryParam.getParamValue());
        } catch (IllegalArgumentException e) {e.printStackTrace();}
        catch (SecurityException e) {e.printStackTrace();}
        catch (IllegalAccessException e) {e.printStackTrace();}
        catch (NoSuchFieldException e) {e.printStackTrace();}
        }
        for (EntryParam<String, Object> entryParam : simParams) {
            try {
            System.out.println(this.getClass().getDeclaredField(entryParam.getParamName()).get(this));
        } catch (IllegalArgumentException e) {e.printStackTrace();}
        catch (SecurityException e) {e.printStackTrace();}
        catch (IllegalAccessException e) {e.printStackTrace();} 
        catch (NoSuchFieldException e) {e.printStackTrace();}}
        
    }
    
    public void start() {
        super.start();
        try { 
            env = DContinuousGrid2DFactory.createDContinuous2D(
                8.0, gridWidth, gridHeight, this,
                super.AOI, TYPE.pos_i, TYPE.pos_j,
                super.rows, super.columns, MODE, "env", topicPrefix, true
            );
            init_connection();
        } catch (DMasonException e) { e.printStackTrace();}
        
        
        int id = 0;
        for (int x = 0, _var0 = Sim.grid_width; x < _var0; ++x) {
            for (int y = 0, _var1 = Sim.grid_width; y < _var1; ++y) {
                boolean occupied = (this.random(1.0) < Sim.occupiedFrac);
                int max_env_sugar_level = this.calc_max_env_sugar_level(x, y);
                Agent _var2 = new Agent(this, new Double2D(((float) x + 0.5), ((float) y + 0.5)), new Double2D(0, 0), id, (occupied ? Sim.AGENT_STATE_OCCUPIED : Sim.AGENT_STATE_UNOCCUPIED), (occupied ? Util.randomInt(this.random, Sim.min_start_sugar_level, Sim.max_start_sugar_level) : 0), (occupied ? 1 : 0), Util.randomInt(this.random, 0, max_env_sugar_level), max_env_sugar_level);
                Double2D _var3 = _var2.getInState().pos;
                if (_var3.x >= env.own_x && _var3.x < env.own_x + env.my_width && _var3.y >= env.own_y && _var3.y < env.own_y + env.my_height) {
                    _var2.setPos(_var3);
                    this.env.setObjectLocation(_var2, _var3);
                    this.schedule.scheduleOnce(_var2);
                }
                ;
                id += 1;
            }
        }
    }
    
    public void run() {
        int t = Sim.num_timesteps * 4;
        for (int i = 0; i != t; i++) {
            System.out.println(i);
            if (!this.schedule.step(this)) break;
        }
    }
    
    
    public Double2D random(Double2D min, Double2D max) {
        return new Double2D(Util.random(this.random, min.x, max.x), Util.random(this.random, min.y, max.y));
    }
    
    public Double3D random(Double3D min, Double3D max) {
        return new Double3D(Util.random(this.random, min.x, max.x), Util.random(this.random, min.y, max.y), Util.random(this.random, min.z, max.z));
    }
    
    public double random(double max) {
        return Util.random(this.random, 0, max);
    }
    
    public Double2D random(Double2D max) {
        return this.random(new Double2D(0, 0), max);
    }
    
    public Double3D random(Double3D max) {
        return this.random(new Double3D(0, 0, 0), max);
    }
    
    public int randomInt(int max) {
        return Util.randomInt(this.random, 0, max);
    }
    
    public double clamp(double pos, double min, double max) {
        return ((pos < min) ? min : ((pos > max) ? max : pos));
    }
    
    public Double2D clamp(Double2D pos, Double2D min, Double2D max) {
        return new Double2D(((pos.x < min.x) ? min.x : ((pos.x > max.x) ? max.x : pos.x)), ((pos.y < min.y) ? min.y : ((pos.y > max.y) ? max.y : pos.y)));
    }
    
    public Double3D clamp(Double3D pos, Double3D min, Double3D max) {
        return new Double3D(((pos.x < min.x) ? min.x : ((pos.x > max.x) ? max.x : pos.x)), ((pos.y < min.y) ? min.y : ((pos.y > max.y) ? max.y : pos.y)), ((pos.z < min.z) ? min.z : ((pos.z > max.z) ? max.z : pos.z)));
    }
    
    public double clamp(double pos, double max) {
        return this.clamp(pos, 0, max);
    }
    
    public Double2D clamp(Double2D pos, Double2D max) {
        return this.clamp(pos, new Double2D(0, 0), max);
    }
    
    public Double3D clamp(Double3D pos, Double3D max) {
        return this.clamp(pos, new Double3D(0, 0, 0), max);
    }
    
    public double wraparound(double pos, double max) {
        return ((pos < 0) ? (max + pos) : ((pos >= max) ? (pos - max) : pos));
    }
    
    public Double2D wraparound(Double2D pos, Double2D max) {
        return new Double2D(((pos.x < 0) ? (max.x + pos.x) : ((pos.x >= max.x) ? (pos.x - max.x) : pos.x)), ((pos.y < 0) ? (max.y + pos.y) : ((pos.y >= max.y) ? (pos.y - max.y) : pos.y)));
    }
    
    public Double3D wraparound(Double3D pos, Double3D max) {
        return new Double3D(((pos.x < 0) ? (max.x + pos.x) : ((pos.x >= max.x) ? (pos.x - max.x) : pos.x)), ((pos.y < 0) ? (max.y + pos.y) : ((pos.y >= max.y) ? (pos.y - max.y) : pos.y)), ((pos.z < 0) ? (max.z + pos.z) : ((pos.z >= max.z) ? (pos.z - max.z) : pos.z)));
    }
    
    public boolean is_inside(Double2D pos, Double2D max) {
        return ((((pos.x >= 0) && (pos.y >= 0)) && (pos.x <= max.x)) && (pos.y <= max.y));
    }
    
    public int getColor(Agent _cell) {
        Agent.State cell = _cell.getInState();
        double frac = java.lang.Math.min(1.0, ((float) cell.env_sugar_level / (float) Sim.global_max_env_sugar_level));
        int c = (int) (255.0 * (1.0 - frac));
        int rgb = (16711935 | (c << 8));
        if ((cell.state == Sim.AGENT_STATE_UNOCCUPIED)) {
            return rgb;
        }
        return ((cell.state == Sim.AGENT_STATE_OCCUPIED) ? 0 : 16711680);
    }
    
    public int calc_max_env_sugar_level(int x, int y) {
        int gmax = Sim.global_max_env_sugar_level;
        Double2D pos = new Double2D(x, y);
        int max = 0;
        double d1 = pos.distance(Sim.sugar_center1);
        max += ((float) gmax * java.lang.Math.exp((((-d1) * d1) / (2.0 * Sim.sugar_variance))));
        double d2 = pos.distance(Sim.sugar_center2);
        max += ((float) gmax * java.lang.Math.exp((((-d2) * d2) / (2.0 * Sim.sugar_variance))));
        return max;
    }
    public DistributedField<Double2D> getField() {
        return env;
        }
    public void addToField(RemotePositionedAgent<Double2D> rm, Double2D loc) {
        env.setObjectLocation(rm, loc);
        }
    public SimState getState() {
        return this;
        }
    public static void main(String[] args) {
        doLoop(Sim.class, args);
        System.exit(0);
    }
    public static int getColor(Object obj) {
        return 0;
    }
    public static int getSize(Object obj) {
        return 1;
    }
}