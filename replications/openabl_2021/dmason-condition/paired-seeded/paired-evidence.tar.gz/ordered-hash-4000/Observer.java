import sim.util.Bag;
import java.util.Locale;
public class Observer {
    static void snapshot(Sim sim, String stage) {
        Bag objects = sim.env.getAllObjects();
        int owned = 0;
        for (int i = 0; i < objects.numObjs; i++) {
            Agent agent = (Agent) objects.objs[i];
            Agent.State a = agent.getInState();
            if (a.pos.x >= sim.env.own_x && a.pos.x < sim.env.own_x + sim.env.my_width &&
                a.pos.y >= sim.env.own_y && a.pos.y < sim.env.own_y + sim.env.my_height) {
                System.out.printf(Locale.ROOT, "OBS,%s,%s,%.17g,%.17g,%.17g,%.17g,%d,%d,%d,%d,%d,%d%n",
                    sim.TYPE, stage, a.pos.x, a.pos.y, a.target_pos.x, a.target_pos.y,
                    a.agent_id, a.state, a.sugar_level, a.metabolism, a.env_sugar_level, a.max_env_sugar_level);
                owned++;
            }
        }
        System.out.printf("SNAP,%s,%s,%d,%d%n", sim.TYPE, stage, owned, sim.schedule.getSteps());
    }
}
