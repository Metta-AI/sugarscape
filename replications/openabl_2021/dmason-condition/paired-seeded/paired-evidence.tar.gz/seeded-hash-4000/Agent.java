import java.io.Serializable;
import sim.engine.*;
import sim.util.*;
import it.isislab.dmason.exception.DMasonException;
import it.isislab.dmason.sim.engine.DistributedState;

public class Agent extends RemoteAgent {
    public class State implements Serializable {
        Double2D pos;
        Double2D target_pos;
        int agent_id;
        int state;
        int sugar_level;
        int metabolism;
        int env_sugar_level;
        int max_env_sugar_level;
        State(Double2D pos, Double2D target_pos, int agent_id, int state, int sugar_level, int metabolism, int env_sugar_level, int max_env_sugar_level) {
            this.pos = pos;
            this.target_pos = target_pos;
            this.agent_id = agent_id;
            this.state = state;
            this.sugar_level = sugar_level;
            this.metabolism = metabolism;
            this.env_sugar_level = env_sugar_level;
            this.max_env_sugar_level = max_env_sugar_level;
        }
    }
    State state0;
    State state1;
    int currentState = 0;
    int currentStep = 0;
    public Agent() { }
    public Agent(DistributedState<Double2D> sm, Double2D pos, Double2D target_pos, int agent_id, int state, int sugar_level, int metabolism, int env_sugar_level, int max_env_sugar_level) {
        super(sm);
        state0 = new State(pos, target_pos, agent_id, state, sugar_level, metabolism, env_sugar_level, max_env_sugar_level);
        state1 = new State(pos, target_pos, agent_id, state, sugar_level, metabolism, env_sugar_level, max_env_sugar_level);
    }
    public State getState(int n) {
        return n == 0 ? state0 : state1;
    }
    public State getInState() {
        return currentState == 0 ? state0 : state1;
    }
    State getOutState() {
        return currentState == 0 ? state1 : state0;
    }
    void prepareOutState() {
        State outState = getOutState();
        State inState = getInState();
        outState.pos = inState.pos;
        outState.target_pos = inState.target_pos;
        outState.agent_id = inState.agent_id;
        outState.state = inState.state;
        outState.sugar_level = inState.sugar_level;
        outState.metabolism = inState.metabolism;
        outState.env_sugar_level = inState.env_sugar_level;
        outState.max_env_sugar_level = inState.max_env_sugar_level;
    }
    void swapStates() {
        currentState ^= 1;
    }
    public void step(SimState state) {
        switch (currentStep) {
            case 0:
                _metabolise_and_growback(state);
                break;
            case 1:
                _movement_request(state);
                break;
            case 2:
                _movement_response(state);
                break;
            case 3:
                _movement_transaction(state);
                break;
        }
        currentStep++;
        if (currentStep == 4) {
            currentStep = 0;
        }
    }
    
    public void _metabolise_and_growback(SimState state) {
        Sim _sim = (Sim) state;
        State in = getInState();
        State out = getOutState();
        in.pos = _sim.env.getObjectLocation(this);
        prepareOutState();
        int new_env_sugar_level = in.env_sugar_level;
        if ((in.state == Sim.AGENT_STATE_OCCUPIED)) {
            int new_sugar_level = ((in.sugar_level + in.env_sugar_level) - in.metabolism);
            new_env_sugar_level = 0;
            if ((new_sugar_level <= 0)) {
                out.state = Sim.AGENT_STATE_UNOCCUPIED;
                out.agent_id = (-1);
                out.sugar_level = 0;
                out.metabolism = 0;
            } else {
                out.state = Sim.AGENT_STATE_MOVEMENT_UNRESOLVED;
                out.sugar_level = new_sugar_level;
            }
        }
        new_env_sugar_level += Sim.SUGAR_GROWBACK_RATE;
        if ((new_env_sugar_level > in.max_env_sugar_level)) {
            new_env_sugar_level = in.max_env_sugar_level;
        }
        out.env_sugar_level = new_env_sugar_level;
        try {
            this.setPos(out.pos);
            _sim.env.setDistributedObjectLocation(out.pos, this, _sim);
            swapStates();
        } catch (DMasonException e) { e.printStackTrace(); }
    }
    
    public void _movement_request(SimState state) {
        Sim _sim = (Sim) state;
        State in = getInState();
        State out = getOutState();
        in.pos = _sim.env.getObjectLocation(this);
        prepareOutState();
        if ((in.state == Sim.AGENT_STATE_MOVEMENT_UNRESOLVED)) {
            int best_sugar_level = (-1);
            Double2D best_pos = new Double2D(0, 0);
            Bag _bag = _sim.env.getNeighborsExactlyWithinDistance(in.pos, Sim.radius);
            for (int _var0 = 0; _var0 < _bag.size(); _var0++) {
                Object _agent = _bag.get(_var0);
                Agent.State nx = ((Agent) _agent).getState(currentState);
                {
                    if (nx.pos.equals(in.pos)) continue;
                    if (((nx.state == Sim.AGENT_STATE_UNOCCUPIED) && (nx.env_sugar_level > best_sugar_level))) {
                        best_sugar_level = nx.env_sugar_level;
                        best_pos = nx.pos;
                    }
                }
            }
            if ((best_sugar_level > in.env_sugar_level)) {
                out.state = Sim.AGENT_STATE_MOVEMENT_REQUESTED;
                out.target_pos = best_pos;
            } else {
                out.state = Sim.AGENT_STATE_OCCUPIED;
            }
        }
        try {
            this.setPos(out.pos);
            _sim.env.setDistributedObjectLocation(out.pos, this, _sim);
            swapStates();
        } catch (DMasonException e) { e.printStackTrace(); }
    }
    
    public void _movement_response(SimState state) {
        Sim _sim = (Sim) state;
        State in = getInState();
        State out = getOutState();
        in.pos = _sim.env.getObjectLocation(this);
        prepareOutState();
        if ((in.state == Sim.AGENT_STATE_UNOCCUPIED)) {
            int best_priority = (-1);
            int best_agent_id = (-1);
            int best_sugar_level = (-1);
            int best_metabolism = (-1);
            Bag _bag = _sim.env.getNeighborsExactlyWithinDistance(in.pos, Sim.radius);
            for (int _var1 = 0; _var1 < _bag.size(); _var1++) {
                Object _agent = _bag.get(_var1);
                Agent.State nx = ((Agent) _agent).getState(currentState);
                {
                    if (((nx.state == Sim.AGENT_STATE_MOVEMENT_REQUESTED) && nx.target_pos.equals(in.pos))) {
                        int message_priority = 0;
                        if ((message_priority > best_priority)) {
                            best_priority = message_priority;
                            best_agent_id = nx.agent_id;
                            best_sugar_level = nx.sugar_level;
                            best_metabolism = nx.metabolism;
                        }
                    }
                }
            }
            if ((best_agent_id >= 0)) {
                out.state = Sim.AGENT_STATE_OCCUPIED;
                out.agent_id = best_agent_id;
                out.sugar_level = best_sugar_level;
                out.metabolism = best_metabolism;
            }
        }
        try {
            this.setPos(out.pos);
            _sim.env.setDistributedObjectLocation(out.pos, this, _sim);
            swapStates();
        } catch (DMasonException e) { e.printStackTrace(); }
    }
    
    public void _movement_transaction(SimState state) {
        Sim _sim = (Sim) state;
        State in = getInState();
        State out = getOutState();
        in.pos = _sim.env.getObjectLocation(this);
        prepareOutState();
        if ((in.state == Sim.AGENT_STATE_MOVEMENT_REQUESTED)) {
            boolean moved = false;
            Bag _bag = _sim.env.getNeighborsExactlyWithinDistance(in.pos, Sim.radius);
            for (int _var2 = 0; _var2 < _bag.size(); _var2++) {
                Object _agent = _bag.get(_var2);
                Agent.State nx = ((Agent) _agent).getState(currentState);
                {
                    if (((nx.state == Sim.AGENT_STATE_OCCUPIED) && (nx.agent_id == in.agent_id))) {
                        moved = true;
                        out.state = Sim.AGENT_STATE_UNOCCUPIED;
                        out.agent_id = (-1);
                        out.sugar_level = 0;
                        out.metabolism = 0;
                    }
                }
            }
            if ((!moved)) {
                out.state = Sim.AGENT_STATE_OCCUPIED;
            }
        }
        try {
            this.setPos(out.pos);
            _sim.env.setDistributedObjectLocation(out.pos, this, _sim);
            swapStates();
        } catch (DMasonException e) { e.printStackTrace(); }
    }
}