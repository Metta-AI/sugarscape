import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
original = root.parent / 'openabl-c-published-grid-001'
protocol = json.loads((root / 'protocol.json').read_text())
env = os.environ.copy()
env['OMP_NUM_THREADS'] = '1'
with (root / 'completed.jsonl').open('x') as ledger:
    for size in protocol['requested_cells']:
        assert shutil.disk_usage(root).free > 1024**3
        out = root / str(size)
        out.mkdir()
        source = original / str(size) / 'generated'
        for name in ['libabl.c', 'libabl.h']:
            shutil.copy2(source / name, out / name)
        native = (source / 'main.c').read_text()
        patched, count = re.subn(r'^(\s*)((?:metabolise_and_growback|movement_request|movement_response|movement_transaction))\((_var\d+), (_var\d+)\);', lambda m: f'{m[1]}*{m[4]} = *{m[3]};{m[1]}{m[2]}({m[3]}, {m[4]});', native, flags=re.MULTILINE)
        assert count == 4
        (out / 'main.c').write_text(patched)
        (out / 'buffer-copy.patch').write_text(''.join(difflib.unified_diff(native.splitlines(keepends=True), patched.splitlines(keepends=True), fromfile='native/main.c', tofile='control/main.c')))
        commands = [
            ['/opt/homebrew/bin/gcc-16', '-O2', '-std=c99', 'main.c', 'libabl.c', '-lm', '-fopenmp', '-o', 'main'],
            [str(out / 'main')],
            [sys.executable, str(root / 'initialize.py'), str(out / 'initial.json'), str(out / 'initialization-audit.json'), '--requested-cells', str(size)],
            [sys.executable, str(root / 'replay.py'), str(out / 'initial.json'), str(out / 'final.json'), str(out / 'replay-audit.json'), '--steps', '100', '--buffer', 'copy'],
        ]
        (out / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        for i, command in enumerate(commands):
            start = time.monotonic()
            with (out / f'stage-{i}.log').open('x') as log:
                result = subprocess.run(command, cwd=out, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=14400 if i == 3 else 3600)
            (out / f'stage-{i}-exit.json').write_text(json.dumps({'exit_code': result.returncode, 'elapsed_seconds': time.monotonic() - start}) + '\n')
            result.check_returncode()
        assert (out / 'initial.json').read_bytes() == (original / str(size) / 'initial.json').read_bytes()
        initial = json.loads((out / 'initial.json').read_text())['Agent']
        final = json.loads((out / 'final.json').read_text())['Agent']
        record = {'requested_cells': size, 'initialization': json.loads((out / 'initialization-audit.json').read_text()), 'replay': json.loads((out / 'replay-audit.json').read_text()), 'initial_byte_identical': True, 'initial_occupied': sum(x['state'] != 0 for x in initial), 'final_occupied': sum(x['state'] != 0 for x in final), 'sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*.json')}}
        ledger.write(json.dumps(record) + '\n')
        ledger.flush()
        print(f'Validated copy control {size}', flush=True)
