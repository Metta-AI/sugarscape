#include <stdio.h>
#include "libabl.h"

typedef struct {
    float2 pos;
    float2 target_pos;
    int agent_id;
    int state;
    int sugar_level;
    int metabolism;
    int env_sugar_level;
    int max_env_sugar_level;
} Agent;
static const type_info Agent_info[] = {
    { TYPE_FLOAT2, offsetof(Agent, pos), "pos", true },
    { TYPE_FLOAT2, offsetof(Agent, target_pos), "target_pos", false },
    { TYPE_INT, offsetof(Agent, agent_id), "agent_id", false },
    { TYPE_INT, offsetof(Agent, state), "state", false },
    { TYPE_INT, offsetof(Agent, sugar_level), "sugar_level", false },
    { TYPE_INT, offsetof(Agent, metabolism), "metabolism", false },
    { TYPE_INT, offsetof(Agent, env_sugar_level), "env_sugar_level", false },
    { TYPE_INT, offsetof(Agent, max_env_sugar_level), "max_env_sugar_level", false },
    { TYPE_END, sizeof(Agent), NULL }
};

struct agent_struct {
    dyn_array agents_Agent;
    dyn_array agents_Agent_dbuf;
};
struct agent_struct agents;
static const agent_info agents_info[] = {
    { Agent_info, offsetof(struct agent_struct, agents_Agent), "Agent" },
    { NULL, 0, NULL }
};

double PI = 3.14159;
int AGENT_STATE_UNOCCUPIED = 0;
int AGENT_STATE_OCCUPIED = 1;
int AGENT_STATE_MOVEMENT_REQUESTED = 2;
int AGENT_STATE_MOVEMENT_UNRESOLVED = 3;
int SUGAR_GROWBACK_RATE = 1;
int min_start_sugar_level = 1;
int max_start_sugar_level = 10;
double radius = 1.5;
int num_timesteps = 100;
double occupiedFrac = 0.1;
int num_agents = 2000;
int grid_width = 44;
float2 sugar_center1 = {11.0, 11.0};
float2 sugar_center2 = {33.0, 33.0};
int global_max_env_sugar_level = 50;
double sugar_variance = 48.4;
float2 random_1(float2 min, float2 max) {
    return float2_create(random_float(min.x, max.x), random_float(min.y, max.y));
}
float3 random_2(float3 min, float3 max) {
    return float3_create(random_float(min.x, max.x), random_float(min.y, max.y), random_float(min.z, max.z));
}
double random_3(double max) {
    return random_float(0, max);
}
float2 random_4(float2 max) {
    return random_1(float2_fill(0), max);
}
float3 random_5(float3 max) {
    return random_2(float3_fill(0), max);
}
int randomInt_1(int max) {
    return random_int(0, max);
}
double clamp(double pos, double min, double max) {
    return ((pos < min) ? min : ((pos > max) ? max : pos));
}
float2 clamp_1(float2 pos, float2 min, float2 max) {
    return float2_create(((pos.x < min.x) ? min.x : ((pos.x > max.x) ? max.x : pos.x)), ((pos.y < min.y) ? min.y : ((pos.y > max.y) ? max.y : pos.y)));
}
float3 clamp_2(float3 pos, float3 min, float3 max) {
    return float3_create(((pos.x < min.x) ? min.x : ((pos.x > max.x) ? max.x : pos.x)), ((pos.y < min.y) ? min.y : ((pos.y > max.y) ? max.y : pos.y)), ((pos.z < min.z) ? min.z : ((pos.z > max.z) ? max.z : pos.z)));
}
double clamp_3(double pos, double max) {
    return clamp(pos, 0, max);
}
float2 clamp_4(float2 pos, float2 max) {
    return clamp_1(pos, float2_fill(0), max);
}
float3 clamp_5(float3 pos, float3 max) {
    return clamp_2(pos, float3_fill(0), max);
}
double wraparound(double pos, double max) {
    return ((pos < 0) ? (max + pos) : ((pos >= max) ? (pos - max) : pos));
}
float2 wraparound_1(float2 pos, float2 max) {
    return float2_create(((pos.x < 0) ? (max.x + pos.x) : ((pos.x >= max.x) ? (pos.x - max.x) : pos.x)), ((pos.y < 0) ? (max.y + pos.y) : ((pos.y >= max.y) ? (pos.y - max.y) : pos.y)));
}
float3 wraparound_2(float3 pos, float3 max) {
    return float3_create(((pos.x < 0) ? (max.x + pos.x) : ((pos.x >= max.x) ? (pos.x - max.x) : pos.x)), ((pos.y < 0) ? (max.y + pos.y) : ((pos.y >= max.y) ? (pos.y - max.y) : pos.y)), ((pos.z < 0) ? (max.z + pos.z) : ((pos.z >= max.z) ? (pos.z - max.z) : pos.z)));
}
bool is_inside(float2 pos, float2 max) {
    return ((((pos.x >= 0) && (pos.y >= 0)) && (pos.x <= max.x)) && (pos.y <= max.y));
}




int calc_max_env_sugar_level(int x, int y) {
    int gmax = global_max_env_sugar_level;
    float2 pos = float2_create(x, y);
    int max = 0;
    double d1 = dist_float2(pos, sugar_center1);
    max += ((float) gmax * exp((((-d1) * d1) / (2.0 * sugar_variance))));
    double d2 = dist_float2(pos, sugar_center2);
    max += ((float) gmax * exp((((-d2) * d2) / (2.0 * sugar_variance))));
    return max;
}
int main() {
    int id = 0;
    for (int x = 0, _var0 = grid_width; x < _var0; ++x) {
        for (int y = 0, _var1 = grid_width; y < _var1; ++y) {
            bool occupied = (random_3(1.0) < occupiedFrac);
            int max_env_sugar_level = calc_max_env_sugar_level(x, y);
            *DYN_ARRAY_PLACE(&agents.agents_Agent, Agent) = (Agent) {
                .pos = float2_create(((float) x + 0.5), ((float) y + 0.5)),
                .target_pos = float2_fill(0),
                .agent_id = id,
                .state = (occupied ? AGENT_STATE_OCCUPIED : AGENT_STATE_UNOCCUPIED),
                .sugar_level = (occupied ? random_int(min_start_sugar_level, max_start_sugar_level) : 0),
                .metabolism = (occupied ? 1 : 0),
                .env_sugar_level = random_int(0, max_env_sugar_level),
                .max_env_sugar_level = max_env_sugar_level,
            };
            id += 1;
        }
    }
    save(&agents, agents_info, "iterations/0.xml", SAVE_FLAME_XML);char _cmd_buf[100];
    snprintf(_cmd_buf, sizeof(_cmd_buf), "./main %d iterations/0.xml", num_timesteps);
    int _cmd_ret = system(_cmd_buf);
    if (_cmd_ret != 0) { return _cmd_ret; }
    
    return 0;
}
