/**
 * \file  memory.c
 * \brief Holds memory functions.
 */

#include "header.h"


void unittest_metabolise_and_growback_start_1()
{
	
	
	//return metabolise_and_growback();
}

void unittest_movement_request_gen_1_2()
{
	
	
	//return movement_request_gen();
}

void unittest_movement_request_2_3()
{
	int rc;
	
	
	rc = MB_Iterator_Create(b_movement_request_message, &i_movement_request_message);
	#ifdef ERRCHECK
	if (rc != MB_SUCCESS)
	{
	   fprintf(stderr, "ERROR: Could not create Iterator for 'movement_request_message'\n");
	   switch(rc) {
	       case MB_ERR_INVALID:
	           fprintf(stderr, "\t reason: 'movement_request_message' board is invalid\n");
	           break;
	       case MB_ERR_LOCKED:
               fprintf(stderr, "\t reason: 'movement_request_message' board is locked\n");
               break;
           case MB_ERR_MEMALLOC:
               fprintf(stderr, "\t reason: out of memory\n");
               break;
           case MB_ERR_INTERNAL:
               fprintf(stderr, "\t reason: internal error. Recompile libmoard in debug mode for more info \n");
               break;
	   }
	}
	#endif
	
	//return movement_request();
}

void unittest_movement_response_gen_3_4()
{
	
	
	//return movement_response_gen();
}

void unittest_movement_response_4_5()
{
	int rc;
	
	
	rc = MB_Iterator_Create(b_movement_response_message, &i_movement_response_message);
	#ifdef ERRCHECK
	if (rc != MB_SUCCESS)
	{
	   fprintf(stderr, "ERROR: Could not create Iterator for 'movement_response_message'\n");
	   switch(rc) {
	       case MB_ERR_INVALID:
	           fprintf(stderr, "\t reason: 'movement_response_message' board is invalid\n");
	           break;
	       case MB_ERR_LOCKED:
               fprintf(stderr, "\t reason: 'movement_response_message' board is locked\n");
               break;
           case MB_ERR_MEMALLOC:
               fprintf(stderr, "\t reason: out of memory\n");
               break;
           case MB_ERR_INTERNAL:
               fprintf(stderr, "\t reason: internal error. Recompile libmoard in debug mode for more info \n");
               break;
	   }
	}
	#endif
	
	//return movement_response();
}

void unittest_movement_transaction_gen_5_6()
{
	
	
	//return movement_transaction_gen();
}

void unittest_movement_transaction_6_7()
{
	int rc;
	
	
	rc = MB_Iterator_Create(b_movement_transaction_message, &i_movement_transaction_message);
	#ifdef ERRCHECK
	if (rc != MB_SUCCESS)
	{
	   fprintf(stderr, "ERROR: Could not create Iterator for 'movement_transaction_message'\n");
	   switch(rc) {
	       case MB_ERR_INVALID:
	           fprintf(stderr, "\t reason: 'movement_transaction_message' board is invalid\n");
	           break;
	       case MB_ERR_LOCKED:
               fprintf(stderr, "\t reason: 'movement_transaction_message' board is locked\n");
               break;
           case MB_ERR_MEMALLOC:
               fprintf(stderr, "\t reason: out of memory\n");
               break;
           case MB_ERR_INTERNAL:
               fprintf(stderr, "\t reason: internal error. Recompile libmoard in debug mode for more info \n");
               break;
	   }
	}
	#endif
	
	//return movement_transaction();
}


void free_messages()
{
	int rc;
	
	    rc = MB_Clear(b_movement_request_message);
	    #ifdef ERRCHECK
	    if (rc != MB_SUCCESS)
	    {
	       fprintf(stderr, "ERROR: Could not clear 'movement_request_message' board\n");
	       switch(rc) {
	           case MB_ERR_INVALID:
	               fprintf(stderr, "\t reason: 'movement_request_message' board is invalid\n");
	               break;
	           case MB_ERR_LOCKED:
	               fprintf(stderr, "\t reason: 'movement_request_message' board is locked\n");
	               break;
	           case MB_ERR_INTERNAL:
	               fprintf(stderr, "\t reason: internal error. Recompile libmoard in debug mode for more info \n");
	               break;
	           default:
                   fprintf(stderr, "\t MB_Clear returned error code: %d (see libmboard docs for details)\n", rc);
                   break;
	       }

	       
       	   exit(rc);
	    }
	    #endif
	
	    rc = MB_Clear(b_movement_response_message);
	    #ifdef ERRCHECK
	    if (rc != MB_SUCCESS)
	    {
	       fprintf(stderr, "ERROR: Could not clear 'movement_response_message' board\n");
	       switch(rc) {
	           case MB_ERR_INVALID:
	               fprintf(stderr, "\t reason: 'movement_response_message' board is invalid\n");
	               break;
	           case MB_ERR_LOCKED:
	               fprintf(stderr, "\t reason: 'movement_response_message' board is locked\n");
	               break;
	           case MB_ERR_INTERNAL:
	               fprintf(stderr, "\t reason: internal error. Recompile libmoard in debug mode for more info \n");
	               break;
	           default:
                   fprintf(stderr, "\t MB_Clear returned error code: %d (see libmboard docs for details)\n", rc);
                   break;
	       }

	       
       	   exit(rc);
	    }
	    #endif
	
	    rc = MB_Clear(b_movement_transaction_message);
	    #ifdef ERRCHECK
	    if (rc != MB_SUCCESS)
	    {
	       fprintf(stderr, "ERROR: Could not clear 'movement_transaction_message' board\n");
	       switch(rc) {
	           case MB_ERR_INVALID:
	               fprintf(stderr, "\t reason: 'movement_transaction_message' board is invalid\n");
	               break;
	           case MB_ERR_LOCKED:
	               fprintf(stderr, "\t reason: 'movement_transaction_message' board is locked\n");
	               break;
	           case MB_ERR_INTERNAL:
	               fprintf(stderr, "\t reason: internal error. Recompile libmoard in debug mode for more info \n");
	               break;
	           default:
                   fprintf(stderr, "\t MB_Clear returned error code: %d (see libmboard docs for details)\n", rc);
                   break;
	       }

	       
       	   exit(rc);
	    }
	    #endif
	
}

/** \fn void initialise_pointers()
 * \brief Initialises pointers to xmachine, message, and node lists.
 */
void initialise_pointers()
{
int rc;

	/* Initialise message sync composite params as NULL */
	FLAME_m_movement_request_message_composite_params = NULL;

	    rc = MB_Create(&b_movement_request_message, sizeof(m_movement_request_message));
	    #ifdef ERRCHECK
	    if (rc != MB_SUCCESS)
	    {
	       fprintf(stderr, "ERROR: Could not create 'movement_request_message' board\n");
	       switch(rc) {
	           case MB_ERR_INVALID:
	               fprintf(stderr, "\t reason: Invalid message size\n");
	               break;
	           case MB_ERR_MEMALLOC:
	               fprintf(stderr, "\t reason: out of memory\n");
	               break;
	           case MB_ERR_INTERNAL:
	               fprintf(stderr, "\t reason: internal error. Recompile libmoard in debug mode for more info \n");
	               break;
	           default:
                   fprintf(stderr, "\t MB_Create returned error code: %d (see libmboard docs for details)\n", rc);
                   break;
	       }

	       
       	   exit(rc);
	    }
	    #endif
	
	/* Initialise message sync composite params as NULL */
	FLAME_m_movement_response_message_composite_params = NULL;

	    rc = MB_Create(&b_movement_response_message, sizeof(m_movement_response_message));
	    #ifdef ERRCHECK
	    if (rc != MB_SUCCESS)
	    {
	       fprintf(stderr, "ERROR: Could not create 'movement_response_message' board\n");
	       switch(rc) {
	           case MB_ERR_INVALID:
	               fprintf(stderr, "\t reason: Invalid message size\n");
	               break;
	           case MB_ERR_MEMALLOC:
	               fprintf(stderr, "\t reason: out of memory\n");
	               break;
	           case MB_ERR_INTERNAL:
	               fprintf(stderr, "\t reason: internal error. Recompile libmoard in debug mode for more info \n");
	               break;
	           default:
                   fprintf(stderr, "\t MB_Create returned error code: %d (see libmboard docs for details)\n", rc);
                   break;
	       }

	       
       	   exit(rc);
	    }
	    #endif
	
	/* Initialise message sync composite params as NULL */
	FLAME_m_movement_transaction_message_composite_params = NULL;

	    rc = MB_Create(&b_movement_transaction_message, sizeof(m_movement_transaction_message));
	    #ifdef ERRCHECK
	    if (rc != MB_SUCCESS)
	    {
	       fprintf(stderr, "ERROR: Could not create 'movement_transaction_message' board\n");
	       switch(rc) {
	           case MB_ERR_INVALID:
	               fprintf(stderr, "\t reason: Invalid message size\n");
	               break;
	           case MB_ERR_MEMALLOC:
	               fprintf(stderr, "\t reason: out of memory\n");
	               break;
	           case MB_ERR_INTERNAL:
	               fprintf(stderr, "\t reason: internal error. Recompile libmoard in debug mode for more info \n");
	               break;
	           default:
                   fprintf(stderr, "\t MB_Create returned error code: %d (see libmboard docs for details)\n", rc);
                   break;
	       }

	       
       	   exit(rc);
	    }
	    #endif
	
	Agent_7_state = init_Agent_state();

	Agent_6_state = init_Agent_state();

	Agent_5_state = init_Agent_state();

	Agent_4_state = init_Agent_state();

	Agent_3_state = init_Agent_state();

	Agent_2_state = init_Agent_state();

	Agent_1_state = init_Agent_state();

	Agent_start_state = init_Agent_state();

	temp_node_info = NULL;
	p_node_info = &temp_node_info;
}

/** \fn void initialise_unit_testing()
 * \brief Initialises framework for unit testing.
 */
void initialise_unit_testing()
{
	int rc;

	rc = MB_Env_Init();
	#ifdef ERRCHECK
	if (rc != MB_SUCCESS)
	{
	   fprintf(stderr, "ERROR: Failed to initialise Message Board environment\n");
	   switch(rc) {
	       case MB_ERR_MPI:
	           fprintf(stderr, "\t reason: MPI library not initialised\n");
	           break;
	       case MB_ERR_MEMALLOC:
	           fprintf(stderr, "\t reason: out of memory\n");
	           break;
	       default:
               fprintf(stderr, "\t MB_Env_Init returned error code: %d (see libmboard docs for details)\n", rc);
               break;
	       }

	       
       	   exit(rc);

	}
	#endif

	initialise_pointers();
}

FLAME_output * add_FLAME_output(FLAME_output ** outputs)
{
	FLAME_output * current;

	current = (FLAME_output *)malloc(sizeof(FLAME_output));
	CHECK_POINTER(current);
	current->next = *outputs;
	*outputs = current;

	current->type = -1;
	current->format = -1;
	current->location = NULL;
	current->period = -1;
	current->phase = -1;
	current->flag = 0;

	return current;
}

void free_FLAME_outputs(FLAME_output ** outputs)
{
	FLAME_output * current, * next;

	current = *outputs;
	while(current)
	{
		next = current->next;
		free(current->location);
		free(current);
		current = next;
	}
	*outputs = NULL;
}

/* add_location */
/** \fn void add_location(double point, location ** p_location)
 * \brief Adds a location in order into the location list.
 * \param point Position of an agent.
 * \param p_location Pointer Pointer to the location list.
 */
void add_location(double point, location ** p_location)
{
	location * current = *p_location;
	location * tmp = NULL;
	location * newlocation = NULL;
	int found = 0;

	while(found == 0)
	{
		if(current == NULL) found = 1;
		else if(point > current->point) found = 1;
		else
		{
			tmp = current;
			current = current->next;
		}
	}

	newlocation = (location *)malloc(sizeof(location));
	CHECK_POINTER(newlocation);
	if(tmp)
	{
		tmp->next = newlocation;
	}
	else
	{
		*p_location = newlocation;
	}

	newlocation->next = current;
	newlocation->point = point;
}

/* freelocations */
/** \fn void freelocations(location ** p_location)
 * \brief Free locations from the location list.
 * \param p_location Pointer Pointer to the location list.
 */
void freelocations(location ** p_location)
{
	location * head = *p_location;
	location * tmp = NULL;

	while(head)
	{
		tmp = head->next;
		free(head);
		head = tmp;
	}

	*p_location = NULL;
}

void init_int_static_array(/*@out@*/ int * array, int size)
{
	int i;

	for(i = 0; i < size; i++) array[i] = 0;
}

void init_float_static_array(/*@out@*/ float * array, int size)
{
	int i;

	for(i = 0; i < size; i++) array[i] = 0.0;
}

void init_double_static_array(/*@out@*/ double* array, int size)
{
	int i;

	for(i = 0; i < size; i++) array[i] = 0.0;
}

void init_char_static_array(/*@out@*/ char * array, int size)
{
	int i;

	for(i = 0; i < size; i++) array[i] = '\0';
}




xmachine_memory_Agent_state * init_Agent_state()
{
	xmachine_memory_Agent_state * current = (xmachine_memory_Agent_state *)malloc(sizeof(xmachine_memory_Agent_state));
	CHECK_POINTER(current);

	current->agents = NULL;
	current->count = 0;

	return current;
}

xmachine_memory_Agent * init_Agent_agent()
{
	xmachine_memory_Agent * current = (xmachine_memory_Agent *)malloc(sizeof(xmachine_memory_Agent));
	CHECK_POINTER(current);

	current->pos_x = 0.0;
	current->pos_y = 0.0;
	current->target_pos_x = 0.0;
	current->target_pos_y = 0.0;
	current->agent_id = 0;
	current->state = 0;
	current->sugar_level = 0;
	current->metabolism = 0;
	current->env_sugar_level = 0;
	current->max_env_sugar_level = 0;

	return current;
}

void free_Agent_agent(xmachine_memory_Agent_holder * tmp, xmachine_memory_Agent_state * state)
{
	if(tmp->prev == NULL) state->agents = tmp->next;
	else tmp->prev->next = tmp->next;
	if(tmp->next != NULL) tmp->next->prev = tmp->prev;

	

	free(tmp->agent);
	free(tmp);
}

void unittest_init_Agent_agent()
{
	current_xmachine_Agent = (xmachine_memory_Agent *)malloc(sizeof(xmachine_memory_Agent));
	CHECK_POINTER(current);

		current_xmachine_Agent->pos_x = 0.0;
		current_xmachine_Agent->pos_y = 0.0;
		current_xmachine_Agent->target_pos_x = 0.0;
		current_xmachine_Agent->target_pos_y = 0.0;
		current_xmachine_Agent->agent_id = 0;
		current_xmachine_Agent->state = 0;
		current_xmachine_Agent->sugar_level = 0;
		current_xmachine_Agent->metabolism = 0;
		current_xmachine_Agent->env_sugar_level = 0;
		current_xmachine_Agent->max_env_sugar_level = 0;
	
}

void unittest_free_Agent_agent()
{
	
	free(current_xmachine_Agent);
}

void free_Agent_agents()
{
	current_xmachine_Agent_holder = Agent_7_state->agents;
	while(current_xmachine_Agent_holder)
	{
		temp_xmachine_Agent_holder = current_xmachine_Agent_holder->next;
		free_Agent_agent(current_xmachine_Agent_holder, Agent_7_state);
		current_xmachine_Agent_holder = temp_xmachine_Agent_holder;
	}
	Agent_7_state->count = 0;
	current_xmachine_Agent_holder = Agent_6_state->agents;
	while(current_xmachine_Agent_holder)
	{
		temp_xmachine_Agent_holder = current_xmachine_Agent_holder->next;
		free_Agent_agent(current_xmachine_Agent_holder, Agent_6_state);
		current_xmachine_Agent_holder = temp_xmachine_Agent_holder;
	}
	Agent_6_state->count = 0;
	current_xmachine_Agent_holder = Agent_5_state->agents;
	while(current_xmachine_Agent_holder)
	{
		temp_xmachine_Agent_holder = current_xmachine_Agent_holder->next;
		free_Agent_agent(current_xmachine_Agent_holder, Agent_5_state);
		current_xmachine_Agent_holder = temp_xmachine_Agent_holder;
	}
	Agent_5_state->count = 0;
	current_xmachine_Agent_holder = Agent_4_state->agents;
	while(current_xmachine_Agent_holder)
	{
		temp_xmachine_Agent_holder = current_xmachine_Agent_holder->next;
		free_Agent_agent(current_xmachine_Agent_holder, Agent_4_state);
		current_xmachine_Agent_holder = temp_xmachine_Agent_holder;
	}
	Agent_4_state->count = 0;
	current_xmachine_Agent_holder = Agent_3_state->agents;
	while(current_xmachine_Agent_holder)
	{
		temp_xmachine_Agent_holder = current_xmachine_Agent_holder->next;
		free_Agent_agent(current_xmachine_Agent_holder, Agent_3_state);
		current_xmachine_Agent_holder = temp_xmachine_Agent_holder;
	}
	Agent_3_state->count = 0;
	current_xmachine_Agent_holder = Agent_2_state->agents;
	while(current_xmachine_Agent_holder)
	{
		temp_xmachine_Agent_holder = current_xmachine_Agent_holder->next;
		free_Agent_agent(current_xmachine_Agent_holder, Agent_2_state);
		current_xmachine_Agent_holder = temp_xmachine_Agent_holder;
	}
	Agent_2_state->count = 0;
	current_xmachine_Agent_holder = Agent_1_state->agents;
	while(current_xmachine_Agent_holder)
	{
		temp_xmachine_Agent_holder = current_xmachine_Agent_holder->next;
		free_Agent_agent(current_xmachine_Agent_holder, Agent_1_state);
		current_xmachine_Agent_holder = temp_xmachine_Agent_holder;
	}
	Agent_1_state->count = 0;
	current_xmachine_Agent_holder = Agent_start_state->agents;
	while(current_xmachine_Agent_holder)
	{
		temp_xmachine_Agent_holder = current_xmachine_Agent_holder->next;
		free_Agent_agent(current_xmachine_Agent_holder, Agent_start_state);
		current_xmachine_Agent_holder = temp_xmachine_Agent_holder;
	}
	Agent_start_state->count = 0;
}

void free_Agent_states()
{
	free(Agent_7_state);
	free(Agent_6_state);
	free(Agent_5_state);
	free(Agent_4_state);
	free(Agent_3_state);
	free(Agent_2_state);
	free(Agent_1_state);
	free(Agent_start_state);
}

void transition_Agent_agent(xmachine_memory_Agent_holder * tmp, xmachine_memory_Agent_state * from_state, xmachine_memory_Agent_state * to_state)
{
	if(tmp->prev == NULL) from_state->agents = tmp->next;
	else tmp->prev->next = tmp->next;
	if(tmp->next != NULL) tmp->next->prev = tmp->prev;

	add_Agent_agent_internal(tmp->agent, to_state);
	free(tmp);
}

void add_Agent_agent_internal(xmachine_memory_Agent * agent, xmachine_memory_Agent_state * state)
{
	xmachine_memory_Agent_holder * current = (xmachine_memory_Agent_holder *)malloc(sizeof(xmachine_memory_Agent_holder));
	CHECK_POINTER(current);

	current->next = state->agents;
	current->prev = NULL;
	state->agents = current;
	if(current->next != NULL) current->next->prev = current;
	current->agent = agent;

	state->count++;

}

/** \fn void add_Agent_agent(double pos_x, double pos_y, double target_pos_x, double target_pos_y, int agent_id, int state, int sugar_level, int metabolism, int env_sugar_level, int max_env_sugar_level)
 * \brief Add Agent X-machine to the current being used X-machine list.
 * \param pos_x Variable for the X-machine memory.
 * \param pos_y Variable for the X-machine memory.
 * \param target_pos_x Variable for the X-machine memory.
 * \param target_pos_y Variable for the X-machine memory.
 * \param agent_id Variable for the X-machine memory.
 * \param state Variable for the X-machine memory.
 * \param sugar_level Variable for the X-machine memory.
 * \param metabolism Variable for the X-machine memory.
 * \param env_sugar_level Variable for the X-machine memory.
 * \param max_env_sugar_level Variable for the X-machine memory.
 */
void add_Agent_agent(double pos_x, double pos_y, double target_pos_x, double target_pos_y, int agent_id, int state, int sugar_level, int metabolism, int env_sugar_level, int max_env_sugar_level)
{
	xmachine_memory_Agent * current;

	current = init_Agent_agent();
	/* new line added to handle dynamic agent creation*/
	current_xmachine_Agent_next_state = Agent_start_state;
	add_Agent_agent_internal(current, current_xmachine_Agent_next_state);

	current->pos_x = pos_x;
	current->pos_y = pos_y;
	current->target_pos_x = target_pos_x;
	current->target_pos_y = target_pos_y;
	current->agent_id = agent_id;
	current->state = state;
	current->sugar_level = sugar_level;
	current->metabolism = metabolism;
	current->env_sugar_level = env_sugar_level;
	current->max_env_sugar_level = max_env_sugar_level;
}


/* freexmachines */
/** \fn void freexmachines()
 * \brief Free the currently being used X-machine list.
 */
void freexmachines()
{
	free_Agent_agents();
	
}


/** \fn void set_pos_x(double pos_x)
 * \brief Set pos_x memory variable for current X-machine.
 * \param pos_x New value for variable.
 */
void set_pos_x(double pos_x)
{
	if(current_xmachine->xmachine_Agent)
	{
		assert(pos_x < FLAME_DOUBLE_MAX);
		assert(pos_x > FLAME_DOUBLE_MIN);
		(*current_xmachine->xmachine_Agent).pos_x = pos_x;
	}
}

/** \fn double get_pos_x()
 * \brief Get pos_x memory variable from current X-machine.
 * \return Value for variable.
 */
double get_pos_x()
{
	if(current_xmachine->xmachine_Agent) return (*current_xmachine->xmachine_Agent).pos_x;

    // suppress compiler warning by returning dummy value /
    // this statement should rightfully NEVER be reached /
    return (double)0;
}

/** \fn void set_pos_y(double pos_y)
 * \brief Set pos_y memory variable for current X-machine.
 * \param pos_y New value for variable.
 */
void set_pos_y(double pos_y)
{
	if(current_xmachine->xmachine_Agent)
	{
		assert(pos_y < FLAME_DOUBLE_MAX);
		assert(pos_y > FLAME_DOUBLE_MIN);
		(*current_xmachine->xmachine_Agent).pos_y = pos_y;
	}
}

/** \fn double get_pos_y()
 * \brief Get pos_y memory variable from current X-machine.
 * \return Value for variable.
 */
double get_pos_y()
{
	if(current_xmachine->xmachine_Agent) return (*current_xmachine->xmachine_Agent).pos_y;

    // suppress compiler warning by returning dummy value /
    // this statement should rightfully NEVER be reached /
    return (double)0;
}

/** \fn void set_target_pos_x(double target_pos_x)
 * \brief Set target_pos_x memory variable for current X-machine.
 * \param target_pos_x New value for variable.
 */
void set_target_pos_x(double target_pos_x)
{
	if(current_xmachine->xmachine_Agent)
	{
		assert(target_pos_x < FLAME_DOUBLE_MAX);
		assert(target_pos_x > FLAME_DOUBLE_MIN);
		(*current_xmachine->xmachine_Agent).target_pos_x = target_pos_x;
	}
}

/** \fn double get_target_pos_x()
 * \brief Get target_pos_x memory variable from current X-machine.
 * \return Value for variable.
 */
double get_target_pos_x()
{
	if(current_xmachine->xmachine_Agent) return (*current_xmachine->xmachine_Agent).target_pos_x;

    // suppress compiler warning by returning dummy value /
    // this statement should rightfully NEVER be reached /
    return (double)0;
}

/** \fn void set_target_pos_y(double target_pos_y)
 * \brief Set target_pos_y memory variable for current X-machine.
 * \param target_pos_y New value for variable.
 */
void set_target_pos_y(double target_pos_y)
{
	if(current_xmachine->xmachine_Agent)
	{
		assert(target_pos_y < FLAME_DOUBLE_MAX);
		assert(target_pos_y > FLAME_DOUBLE_MIN);
		(*current_xmachine->xmachine_Agent).target_pos_y = target_pos_y;
	}
}

/** \fn double get_target_pos_y()
 * \brief Get target_pos_y memory variable from current X-machine.
 * \return Value for variable.
 */
double get_target_pos_y()
{
	if(current_xmachine->xmachine_Agent) return (*current_xmachine->xmachine_Agent).target_pos_y;

    // suppress compiler warning by returning dummy value /
    // this statement should rightfully NEVER be reached /
    return (double)0;
}

/** \fn void set_agent_id(int agent_id)
 * \brief Set agent_id memory variable for current X-machine.
 * \param agent_id New value for variable.
 */
void set_agent_id(int agent_id)
{
	if(current_xmachine->xmachine_Agent)
	{
		assert(agent_id < FLAME_DOUBLE_MAX);
		assert(agent_id > FLAME_DOUBLE_MIN);
		(*current_xmachine->xmachine_Agent).agent_id = agent_id;
	}
}

/** \fn int get_agent_id()
 * \brief Get agent_id memory variable from current X-machine.
 * \return Value for variable.
 */
int get_agent_id()
{
	if(current_xmachine->xmachine_Agent) return (*current_xmachine->xmachine_Agent).agent_id;

    // suppress compiler warning by returning dummy value /
    // this statement should rightfully NEVER be reached /
    return (int)0;
}

/** \fn void set_state(int state)
 * \brief Set state memory variable for current X-machine.
 * \param state New value for variable.
 */
void set_state(int state)
{
	if(current_xmachine->xmachine_Agent)
	{
		assert(state < FLAME_DOUBLE_MAX);
		assert(state > FLAME_DOUBLE_MIN);
		(*current_xmachine->xmachine_Agent).state = state;
	}
}

/** \fn int get_state()
 * \brief Get state memory variable from current X-machine.
 * \return Value for variable.
 */
int get_state()
{
	if(current_xmachine->xmachine_Agent) return (*current_xmachine->xmachine_Agent).state;

    // suppress compiler warning by returning dummy value /
    // this statement should rightfully NEVER be reached /
    return (int)0;
}

/** \fn void set_sugar_level(int sugar_level)
 * \brief Set sugar_level memory variable for current X-machine.
 * \param sugar_level New value for variable.
 */
void set_sugar_level(int sugar_level)
{
	if(current_xmachine->xmachine_Agent)
	{
		assert(sugar_level < FLAME_DOUBLE_MAX);
		assert(sugar_level > FLAME_DOUBLE_MIN);
		(*current_xmachine->xmachine_Agent).sugar_level = sugar_level;
	}
}

/** \fn int get_sugar_level()
 * \brief Get sugar_level memory variable from current X-machine.
 * \return Value for variable.
 */
int get_sugar_level()
{
	if(current_xmachine->xmachine_Agent) return (*current_xmachine->xmachine_Agent).sugar_level;

    // suppress compiler warning by returning dummy value /
    // this statement should rightfully NEVER be reached /
    return (int)0;
}

/** \fn void set_metabolism(int metabolism)
 * \brief Set metabolism memory variable for current X-machine.
 * \param metabolism New value for variable.
 */
void set_metabolism(int metabolism)
{
	if(current_xmachine->xmachine_Agent)
	{
		assert(metabolism < FLAME_DOUBLE_MAX);
		assert(metabolism > FLAME_DOUBLE_MIN);
		(*current_xmachine->xmachine_Agent).metabolism = metabolism;
	}
}

/** \fn int get_metabolism()
 * \brief Get metabolism memory variable from current X-machine.
 * \return Value for variable.
 */
int get_metabolism()
{
	if(current_xmachine->xmachine_Agent) return (*current_xmachine->xmachine_Agent).metabolism;

    // suppress compiler warning by returning dummy value /
    // this statement should rightfully NEVER be reached /
    return (int)0;
}

/** \fn void set_env_sugar_level(int env_sugar_level)
 * \brief Set env_sugar_level memory variable for current X-machine.
 * \param env_sugar_level New value for variable.
 */
void set_env_sugar_level(int env_sugar_level)
{
	if(current_xmachine->xmachine_Agent)
	{
		assert(env_sugar_level < FLAME_DOUBLE_MAX);
		assert(env_sugar_level > FLAME_DOUBLE_MIN);
		(*current_xmachine->xmachine_Agent).env_sugar_level = env_sugar_level;
	}
}

/** \fn int get_env_sugar_level()
 * \brief Get env_sugar_level memory variable from current X-machine.
 * \return Value for variable.
 */
int get_env_sugar_level()
{
	if(current_xmachine->xmachine_Agent) return (*current_xmachine->xmachine_Agent).env_sugar_level;

    // suppress compiler warning by returning dummy value /
    // this statement should rightfully NEVER be reached /
    return (int)0;
}

/** \fn void set_max_env_sugar_level(int max_env_sugar_level)
 * \brief Set max_env_sugar_level memory variable for current X-machine.
 * \param max_env_sugar_level New value for variable.
 */
void set_max_env_sugar_level(int max_env_sugar_level)
{
	if(current_xmachine->xmachine_Agent)
	{
		assert(max_env_sugar_level < FLAME_DOUBLE_MAX);
		assert(max_env_sugar_level > FLAME_DOUBLE_MIN);
		(*current_xmachine->xmachine_Agent).max_env_sugar_level = max_env_sugar_level;
	}
}

/** \fn int get_max_env_sugar_level()
 * \brief Get max_env_sugar_level memory variable from current X-machine.
 * \return Value for variable.
 */
int get_max_env_sugar_level()
{
	if(current_xmachine->xmachine_Agent) return (*current_xmachine->xmachine_Agent).max_env_sugar_level;

    // suppress compiler warning by returning dummy value /
    // this statement should rightfully NEVER be reached /
    return (int)0;
}


/** \fn double agent_get_range()
 * \brief Fixed routine to get the range from current X-machine
  * \return Value of range
  */
double agent_get_range()
{
    double value = 0.0;
    /*if (current_xmachine->xmachine_Agent) value = current_xmachine->xmachine_Agent->;*/

    return value;
}

/** \fn int agent_get_id()
 * \brief Fixed routine to get the id for the current X-machine
  * \return Value of agent id
  */
int agent_get_id()
{
    int value = 0;
    /*if (current_xmachine->xmachine_Agent) value = current_xmachine->xmachine_Agent->agent_id;*/

    return value;
}

/** \fn double agent_get_x()
 * \brief Fixed routine to get the x coordinate from current X-machine
  * \return Value of x coordinate
  */
double agent_get_x()
{
    double value = 0.0;
    /*if (current_xmachine->xmachine_Agent) value = current_xmachine->xmachine_Agent->0.0;*/

    return value;
}
/** \fn double agent_get_y()
 * \brief Fixed routine to get the y coordinate from current X-machine
  * \return Value of y coordinate
  */
double agent_get_y()
{
    double value = 0.0;
    /*if (current_xmachine->xmachine_Agent) value = current_xmachine->xmachine_Agent->0.0;*/

    return value;
}
/** \fn double agent_get_z()
 * \brief Fixed routine to get the z coordinate from current X-machine
  * \return Value of z coordinate
  */
double agent_get_z()
{
    double value = 0.0;

    return value;
}

/** \fn void add_node(int node_id, double minx, double maxx, double miny, double maxy, double minz, double maxz)
 * \brief Add a node to the node list.
 * \param node_id The node ID.
 * \param minx The minumum value on the x-axis of the bounding volume.
 * \param maxx The maximum value on the x-axis of the bounding volume.
 * \param miny The minumum value on the y-axis of the bounding volume.
 * \param maxy The maximum value on the y-axis of the bounding volume.
 * \param minz The minumum value on the z-axis of the bounding volume.
 * \param maxz The maximum value on the z-axis of the bounding volume.
 */
void add_node(int node_id, double minx, double maxx, double miny, double maxy, double minz, double maxz)
{
	node_information * current = *p_node_info;
	node_information * tmp = NULL;

	while(current)
	{
		tmp = current;
		current = current->next;
	}

	current = (node_information *)malloc(sizeof(node_information));
		CHECK_POINTER(current);

	if(tmp)
	{
		tmp->next = current;
	}
	else
	{
		*p_node_info = current;
	}

	current->next = NULL;
	current->node_id = node_id;
	current->agents_in_halo = 0;
	current->agent_total = 0;
	current->agents = NULL;
	current->movement_request_message_messages = NULL;
	current->movement_response_message_messages = NULL;
	current->movement_transaction_message_messages = NULL;


	current->partition_data[0] = minx;
	current->partition_data[1] = maxx;
	current->partition_data[2] = miny;
	current->partition_data[3] = maxy;
	current->partition_data[4] = minz;
	current->partition_data[5] = maxz;
}

/**\fn void free_node_info()
 * \brief Free the node list.
 */
void free_node_info()
{
	node_information * tmp, * head;
	head = *p_node_info;

	while(head)
	{
		tmp = head->next;
		free(head);
		head = tmp;
	}

	*p_node_info = NULL;
}

/** \fn void clean_up(int code)
 * \brief Add a node to the node list.
 * \param code The error code (zero is no error).
 */
void clean_up(int code)
{
    int rc;
	FILE *file;
	char data[100];

	free(current_xmachine);
	/* Free x-machine memory */
	freexmachines();
	/* Free space partitions linked list */
	free_node_info();
	/* Free output list */
	free_FLAME_outputs(&FLAME_outputs);
	/* Free agent states */
	free_Agent_states();


	/* Free index maps */


	/* Free message boards */

	rc = MB_Delete(&b_movement_request_message);
	#ifdef ERRCHECK
    if (rc != MB_SUCCESS)
    {
       fprintf(stderr, "ERROR: Could not delete 'movement_request_message' board\n");
       switch(rc) {
           case MB_ERR_INVALID:
               fprintf(stderr, "\t reason: 'movement_request_message' board has not been created?\n");
               break;
           case MB_ERR_LOCKED:
               fprintf(stderr, "\t reason: 'movement_request_message' board is locked\n");
               break;
           case MB_ERR_INTERNAL:
               fprintf(stderr, "\t reason: internal error. Recompile libmoard in debug mode for more info \n");
               break;
	       default:
               fprintf(stderr, "\t MB_Delete returned error code: %d (see libmboard docs for details)\n", rc);
               break;
	       }

	       
       	   exit(rc);
    }
    #endif

	rc = MB_Delete(&b_movement_response_message);
	#ifdef ERRCHECK
    if (rc != MB_SUCCESS)
    {
       fprintf(stderr, "ERROR: Could not delete 'movement_response_message' board\n");
       switch(rc) {
           case MB_ERR_INVALID:
               fprintf(stderr, "\t reason: 'movement_response_message' board has not been created?\n");
               break;
           case MB_ERR_LOCKED:
               fprintf(stderr, "\t reason: 'movement_response_message' board is locked\n");
               break;
           case MB_ERR_INTERNAL:
               fprintf(stderr, "\t reason: internal error. Recompile libmoard in debug mode for more info \n");
               break;
	       default:
               fprintf(stderr, "\t MB_Delete returned error code: %d (see libmboard docs for details)\n", rc);
               break;
	       }

	       
       	   exit(rc);
    }
    #endif

	rc = MB_Delete(&b_movement_transaction_message);
	#ifdef ERRCHECK
    if (rc != MB_SUCCESS)
    {
       fprintf(stderr, "ERROR: Could not delete 'movement_transaction_message' board\n");
       switch(rc) {
           case MB_ERR_INVALID:
               fprintf(stderr, "\t reason: 'movement_transaction_message' board has not been created?\n");
               break;
           case MB_ERR_LOCKED:
               fprintf(stderr, "\t reason: 'movement_transaction_message' board is locked\n");
               break;
           case MB_ERR_INTERNAL:
               fprintf(stderr, "\t reason: internal error. Recompile libmoard in debug mode for more info \n");
               break;
	       default:
               fprintf(stderr, "\t MB_Delete returned error code: %d (see libmboard docs for details)\n", rc);
               break;
	       }

	       
       	   exit(rc);
    }
    #endif


    rc = MB_Env_Finalise();
    #ifdef ERRCHECK
    if (rc != MB_SUCCESS)
    {
       fprintf(stderr, "ERROR: Could not finalise MB environment\n");
       switch(rc) {
           case MB_ERR_ENV:
               fprintf(stderr, "\t reason: MB environment not yet started?\n");
               break;
	       default:
               fprintf(stderr, "\t MB_Env_Finalise returned error code: %d (see libmboard docs for details)\n", rc);
               break;
	       }

	       
       	   exit(rc);
    }
    #endif



	/* Write log file */
	sprintf(data, "%slog.xml", outputpath);
	file = fopen(data, "a");
	fputs("<!-- <totaltime> unit: seconds -->\n", file);
	fputs("<totaltime>", file);
	sprintf(data, "%.3f", total_time);
	fputs(data, file);
	fputs("</totaltime>\n", file);
	/*fputs("<totalmessages>", file);
	sprintf(data, "%i", total_messages);
	fputs(data, file);
	fputs("</totalmessages>", file);*/
	fputs("</model_run>", file);
	fclose(file);


	if(code != 0)
	{
		printf("*** Error: ");
		if(code == 100) printf("cannot handle specified number of space partitions");
		if(code == 101) printf("could not find number of space partitions config in file");

		printf(" ***");
		exit(0);
	}
}



/** \fn int_array * init_int_array()
 * \brief Allocate memory for a dynamic integer array.
 * \return int_array Pointer to the new dynamic integer array.
 */
void init_int_array(int_array * array)
{
	(*array).size = 0;
	(*array).total_size = ARRAY_BLOCK_SIZE;
	(*array).array = (int *)malloc(ARRAY_BLOCK_SIZE * sizeof(int));
	CHECK_POINTER((*array).array);
}

/** \fn void reset_int_array(int_array * array)
* \brief Reset the int array to hold nothing.
* \param array Pointer to the dynamic integer array.
*/
void reset_int_array(int_array * array)
{
	(*array).size = 0;
}

/** \fn void free_int_array(int_array * array)
* \brief Free the memory of a dynamic integer array.
* \param array Pointer to the dynamic integer array.
*/
void free_int_array(int_array * array)
{
	free((*array).array);
}

void copy_int_array(int_array * from, int_array * to)
{
	int i;
	//to = init_int_array();

	for (i = 0; i < (*from).size; i++)
	{
		add_int(to, (*from).array[i]);
	}
}

/** \fn void sort_int_array(int_array * array)
* \brief Sort the elements of a dynamic integer array with smallest first.
* \param array Pointer to the dynamic integer array.
*/
/*void sort_int_array(int_array * array)
{
	int i, j, temp;

	for(i=0; i<((*array).size-1); i++)
	{
		for(j=0; j<((*array).size-1)-i; j++)
		{
			if(*((*array).array+j+1) < *((*array).array+j))
			{
                temp = *((*array).(*array)+j);
                *((*array).array+j) = *((*array).array+j+1);
                *((*array).array+j+1) = temp;
			}
		}
	}
}*/

/** \fn int quicksort_int(int *array, int elements)
 *  \brief Sorts the elements of the integer array in ascending order.
 *  \param Pointer to integer array
 *  \param Number of elements that must be sorted
 *  \return integer value indicating success(0) or failure(1)
 */
/*int quicksort_int(int array, int elements)
{
	#define  LEVEL  1000
	int  pivot, begin[LEVEL], end[LEVEL], i=0, left, right ;
	begin[0]=0; end[0]=elements;
	while (i>=0)
	{
		left=begin[i]; right=end[i]-1;
		if (left<right)
		{
			pivot=array[left]; if (i==LEVEL-1) return 1;
			while (left<right)
			{
				while (array[right]>=pivot && left<right) right--;
				if (left<right) array[left++]=array[right];
				while (array[left]<=pivot && left<right) left++;
				if (left<right) array[right--]=array[left];
			}
			array[left]=pivot;
			begin[i+1]=left+1;
			end[i+1]=end[i];
			end[i++]=left;
		}
	    else
	    {
	      i--;
	    }
	}
	return 0;
}*/

/** \fn void add_int(int_array * array, int new_int)
* \brief Add an integer to the dynamic integer array.
* \param array Pointer to the dynamic integer array.
* \param new_int The integer to add
*/
void add_int(int_array * array, int new_int)
{
	if((*array).size == (*array).total_size)
	{
		(*array).total_size = (int)((*array).total_size * ARRAY_GROWTH_RATE);
		(*array).array = (int *)realloc((*array).array, ((*array).total_size * sizeof(int)));
	}
	(*array).array[(*array).size] = new_int;
	(*array).size++;
}

/** \fn void remove_int(int_array * array, int index)
 * \brief Remove an integer from a dynamic integer array.
 * \param array Pointer to the dynamic integer array.
 * \param index The index of the integer to remove.
 */
void remove_int(int_array * array, int index)
{
	int i;

	if(index < (*array).size)
	{
		/* memcopy?? */
		for(i = index; i < (*array).size - 1; i++)
		{
			(*array).array[i] = (*array).array[i+1];
		}
		(*array).size--;
	}
}

/** \fn void print_int_array(int_array * array)
 * \brief Print the elements of a dynamic integer array.
 * \param array Pointer to the dynamic integer array.
 */
void print_int_array(int_array * array)
{
	int i;

	for(i=0; i<(*array).size; i++)
	{
		printf("%d> %d", i, (*array).array[i]);
	}
}

/** \fn float_array * init_float_array()
 * \brief Allocate memory for a dynamic float array.
 * \return float_array Pointer to the new dynamic float array.
 */
void init_float_array(float_array * array)
{
	(*array).size = 0;
	(*array).total_size = ARRAY_BLOCK_SIZE;
	(*array).array = (float *)malloc(ARRAY_BLOCK_SIZE * sizeof(float));
	CHECK_POINTER((*array).array);
}

/** \fn void reset_float_array(float_array * array)
* \brief Reset the float array to hold nothing.
* \param array Pointer to the dynamic float array.
*/
void reset_float_array(float_array * array)
{
	(*array).size = 0;
}

/** \fn void free_float_array(float_array * array)
* \brief Free the memory of a dynamic float array.
* \param array Pointer to the dynamic float array.
*/
void free_float_array(float_array * array)
{
	free((*array).array);
}

void copy_float_array(float_array * from, float_array * to)
{
	int i;
	//to = init_float_array();

	for (i = 0; i < (*from).size; i++)
	{
		add_float(to, (*from).array[i]);
	}
}

/** \fn void sort_float_array(float_array * array)
* \brief Sort the elements of a dynamic float array with smallest first.
* \param array Pointer to the dynamic float array.
*/
/*void sort_float_array(float_array array)
{
	int i, j;
	float temp;
	// Using bubble sorts nested loops //
	for(i=0; i<(array.size-1); i++)
	{
		for(j=0; j<(array.size-1)-i; j++)
		{
			// Comparing the values between neighbours //
			if(*(array.array+j+1) < *(array.array+j))
			{
                // Swap neighbours //
                temp = *(array.array+j);
                *(array.array+j) = *(array.array+j+1);
                *(array.array+j+1) = temp;
			}
		}
	}
}*/

/** \fn int quicksort_float(float *array, int elements)
 *  \brief Sorts the elements of the float array in ascending order.
 *  \param Pointer to float array
 *  \param Number of elements that must be sorted
 *  \return integer value indicating success(0) or failure(1)
 */
/*int quicksort_float(float array, int elements)
{
	#define  LEVEL  1000
	int i=0, left, right ;
	float pivot, begin[LEVEL], end[LEVEL];
	begin[0]=0; end[0]=elements;
	while (i>=0)
	{
		left=begin[i]; right=end[i]-1;
		if (left<right)
		{
			pivot=array[left]; if (i==LEVEL-1) return 1;
			while (left<right)
			{
				while (array[right]>=pivot && left<right) right--;
				if (left<right) array[left++]=array[right];
				while (array[left]<=pivot && left<right) left++;
				if (left<right) array[right--]=array[left];
			}
			array[left]=pivot;
			begin[i+1]=left+1;
			end[i+1]=end[i];
			end[i++]=left;
		}
	    else
	    {
	      i--;
	    }
	}
	return 0;
}*/

/** \fn void add_float(float_array * array, float new_float)
* \brief Add an floateger to the dynamic float array.
* \param array Pointer to the dynamic float array.
* \param new_float The float to add
*/
void add_float(float_array * array, float new_float)
{
	if((*array).size == (*array).total_size)
	{
		(*array).total_size = (int)((*array).total_size * ARRAY_GROWTH_RATE);
		(*array).array = (float *)realloc((*array).array, ((*array).total_size * sizeof(float)));
	}
	(*array).array[(*array).size] = new_float;
	(*array).size++;
}

/** \fn void remove_float(float_array * array, int index)
 * \brief Remove an floateger from a dynamic float array.
 * \param array Pointer to the dynamic float array.
 * \param index The index of the float to remove.
 */
void remove_float(float_array * array, int index)
{
	int i;

	if(index < (*array).size)
	{
		/* memcopy?? */
		for(i = index; i < (*array).size - 1; i++)
		{
			(*array).array[i] = (*array).array[i+1];
		}
		(*array).size--;
	}
}

/** \fn void print_float_array(float_array * array)
 * \brief Print the elements of a dynamic float array.
 * \param array Pointer to the dynamic float array.
 */
void print_float_array(float_array * array)
{
	int i;
	/* printf(""); // compiler does not like empty prfloats */
	for(i=0; i<(*array).size; i++)
	{
		printf("%d> %f", i, (*array).array[i]);
	}
}

/** \fn double_array * init_double_array()
 * \brief Allocate memory for a dynamic double array.
 * \return double_array Pointer to the new dynamic double array.
 */
void init_double_array(double_array * array)
{
	(*array).size = 0;
	(*array).total_size = ARRAY_BLOCK_SIZE;
	(*array).array = (double *)malloc(ARRAY_BLOCK_SIZE * sizeof(double));
	CHECK_POINTER((*array).array);
}

/** \fn void reset_double_array(double_array * array)
* \brief Reset the double array to hold nothing.
* \param array Pointer to the dynamic double array.
*/
void reset_double_array(double_array * array)
{
	(*array).size = 0;
}

/** \fn void free_double_array(double_array * array)
 * \brief Free the memory of a dynamic double array.
 * \param array Pointer to the dynamic double array.
 */
void free_double_array(double_array * array)
{
	free((*array).array);
}

void copy_double_array(double_array * from, double_array * to)
{
	int i;
	//to = init_double_array();

	for (i = 0; i < (*from).size; i++)
	{
		add_double(to, (*from).array[i]);
	}
}

/** \fn void sort_double_array(double_array * array)
 * \brief Sort the elements of a dynamic double array with smallest first.
 * \param array Pointer to the dynamic double array.
 */
/*void sort_double_array(double_array array)
{
	int i, j;
	double temp;

	// Using bubble sorts nested loops //
	for(i=0; i<(array.size-1); i++)
	{
		for(j=0; j<(array.size-1)-i; j++)
		{
			// Comparing the values between neighbours //
			if(*(array.array+j+1) < *(array.array+j))
			{
                // Swap neighbours //
                temp = *(array.array+j);
                *(array.array+j) = *(array.array+j+1);
                *(array.array+j+1) = temp;
			}
		}
	}
}*/

/** \fn int quicksort_double(double *array, int elements)
 *  \brief Sorts the elements of the double array in ascending order.
 *  \param Pointer to double array
 *  \param Number of elements that must be sorted
 *  \return integer value indicating success(0) or failure(1)
 */
/*int quicksort_double(double array, int elements)
{
	#define  LEVEL  1000
	double pivot, begin[LEVEL], end[LEVEL];
	int  i=0, left, right ;
	begin[0]=0; end[0]=elements;
	while (i>=0)
	{
		left=begin[i]; right=end[i]-1;
		if (left<right)
		{
			pivot=array[left]; if (i==LEVEL-1) return 1;
			while (left<right)
			{
				while (array[right]>=pivot && left<right) right--;
				if (left<right) array[left++]=array[right];
				while (array[left]<=pivot && left<right) left++;
				if (left<right) array[right--]=array[left];
			}
			array[left]=pivot;
			begin[i+1]=left+1;
			end[i+1]=end[i];
			end[i++]=left;
		}
	    else
	    {
	      i--;
	    }
	}
	return 0;
}*/

/** \fn void add_double(double_array * array, double new_double)
 * \brief Add an double to the dynamic double array.
 * \param array Pointer to the dynamic double array.
 * \param new_double The double to add
 */
void add_double(double_array * array, double new_double)
{
	if((*array).size == (*array).total_size)
	{
		(*array).total_size = (int)((*array).total_size * ARRAY_GROWTH_RATE);
		(*array).array = (double *)realloc((*array).array, ((*array).total_size * sizeof(double)));
	}
	(*array).array[(*array).size] = new_double;
	(*array).size++;
}

/** \fn void remove_double(double_array * array, int index)
 * \brief Remove an double from a dynamic double array.
 * \param array Pointer to the dynamic double array.
 * \param index The index of the double to remove.
 */
void remove_double(double_array * array, int index)
{
	int i;
	if(index < (*array).size)
	{
		/* memcopy?? */
		for(i = index; i < (*array).size - 1; i++)
		{
			(*array).array[i] = (*array).array[i+1];
		}
		(*array).size--;
	}
}

/** \fn void print_double_array(double_array * array)
 * \brief Print the elements of a dynamic double array.
 * \param array Pointer to the dynamic double array.
 */
void print_double_array(double_array * array)
{
	int i;

	for(i=0; i<(*array).size; i++)
	{
		printf("%d> %f", i, (*array).array[i]);
	}
}

/** \fn char_array * init_char_array()
 * \brief Allocate memory for a dynamic char array.
 * \return char_array Pointer to the new dynamic char array.
 */
void init_char_array(char_array * array)
{
	(*array).size = 0;
	(*array).total_size = ARRAY_BLOCK_SIZE;
	(*array).array = (char *)malloc(ARRAY_BLOCK_SIZE * sizeof(char));
	CHECK_POINTER((*array).array);
	(*array).array[0] = '\0';
}

/** \fn void reset_char_array(char_array * array)
* \brief Reset the char array to hold nothing.
* \param array Pointer to the dynamic char array.
*/
void reset_char_array(char_array * array)
{
	(*array).size = 0;
}

/** \fn void free_char_array(char_array * array)
 * \brief Free the memory of a dynamic char array.
 * \param array Pointer to the dynamic char array.
 */
void free_char_array(char_array * array)
{
	free((*array).array);
}

void copy_char_array(char_array * from, char_array * to)
{
	int i;

	for (i = 0; i < (*from).size; i++)
	{
		add_char(to, (*from).array[i]);
	}
}

/** \fn void add_char(char_array * array, char new_char)
 * \brief Add an char to the dynamic char array.
 * \param array Pointer to the dynamic char array.
 * \param new_char The char to add
 */
void add_char(char_array * array, char new_char)
{
	if((*array).size + 1 == (*array).total_size)
	{
		(*array).total_size = (int)((*array).total_size * ARRAY_GROWTH_RATE);
		(*array).array = (char *)realloc((*array).array, ((*array).total_size * sizeof(char)));
	}
	(*array).array[(*array).size] = new_char;
	(*array).array[(*array).size + 1] = '\0';
	(*array).size++;
}

/** \fn void remove_char(char_array * array, int index)
 * \brief Remove an char from a dynamic char array.
 * \param array Pointer to the dynamic char array.
 * \param index The index of the char to remove.
 */
void remove_char(char_array * array, int index)
{
	int i;
	if(index < (*array).size)
	{
		/* memcopy?? */
		for(i = index; i < (*array).size - 1; i++)
		{
			(*array).array[i] = (*array).array[i+1];
		}
		(*array).size--;
	}
}

/** \fn char * copy_array_to_str(char_array * array)
 * \brief Return pointer to string from a char_array.
 * \param array Pointer to the dynamic integer array.
 * \return char Pointer to the new string.
 */
char * copy_array_to_str(char_array * array)
{
	char * new_string = (char *)malloc( ((*array).size + 1) * sizeof(char));
	CHECK_POINTER(new_string);
	return strcpy(new_string, (*array).array);
}

/** \fn void print_char_array(char_array * array)
 * \brief Print the elements of a dynamic char array.
 * \param array Pointer to the dynamic char array.
 */
void print_char_array(char_array * array)
{
	printf("%s", (*array).array);
}


/** \fn int idle()
 * \brief an idle function for use by agents.
 */
int idle()
{
	return 0;
}



