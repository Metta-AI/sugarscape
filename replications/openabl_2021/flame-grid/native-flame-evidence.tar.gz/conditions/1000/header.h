/**
 * \file  header.h
 * \brief Header for xmachine data structures and transition functions.
 */
#ifndef _HEADER_H
#define _HEADER_H

#ifdef _DEBUG_MODE
    #define ERRCHECK
#else
    #define NDEBUG
#endif

#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <limits.h>
#include "mboard.h"

#define FLAME_INT_MAX (int)1e+12
#define FLAME_DOUBLE_MAX 1e+12
#define FLAME_INT_MIN (int)-1e+12
#define FLAME_DOUBLE_MIN -1e+12

#define FLAME_TEST_PRINT_START_AND_END_OF_MODEL_FUNCTIONS 0
#define FLAME_TEST_PRINT_START_AND_END_OF_LIBMBOARD_CALLS 0
#define FLAME_USE_FILTERS_IN_SYNC 1

/*#define PAUSE printf("PAUSE - type anything to continue");i=getc(stdin);*/
#define PAUSE

#ifdef START_END
int start_simulation(void);
int end_simulation(void);
int start_iteration(void);
int end_iteration(void);
#endif


/* Checking macros */
#ifdef CHECK_MEMORY
#define CHECK_POINTER(PT) if(PT==NULL){printf("**** ERROR in Memory check 1\n");exit(1);}
#else
#define CHECK_POINTER(PT)
#endif


















#define START_LOOP_OVER_Agent_AGENTS  \
    current_xmachine_Agent_holder = Agent_start_state->agents;\
    while (current_xmachine_Agent_holder) {\
	temp_xmachine_Agent_holder = current_xmachine_Agent_holder->next;\
	current_xmachine_Agent = current_xmachine_Agent_holder->agent;\
	current_xmachine->xmachine_Agent = current_xmachine_Agent;
#define END_LOOP_OVER_Agent_AGENTS \
	current_xmachine_Agent = NULL;\
	current_xmachine->xmachine_Agent = NULL;\
	current_xmachine_Agent_holder = temp_xmachine_Agent_holder;\
    }





/** \def ARRAY_BLOCK_SIZE
 * \brief The block size to allocate to dynamic arrays. */
#define ARRAY_BLOCK_SIZE 10
/** \def ARRAY_GROWTH_RATE
 * \brief Growth ratio to scale size of dynamic arrays. 
 * Use golden ratio. This makes for a Fibonacci sequence, so the next allocation size 
 * is the sum of the current size and the previous size thus improving the chance of 
 * memory block reuse. It also allows for moderate rate of growth.
 */
#define ARRAY_GROWTH_RATE 1.618034
/** \def START_MOVEMENT_REQUEST_MESSAGE_MESSAGE_LOOP
 * \brief Start of loop to process movement_request_message messages. */
#define START_MOVEMENT_REQUEST_MESSAGE_MESSAGE_LOOP  for(movement_request_message_message = get_first_movement_request_message_message(); movement_request_message_message != NULL; movement_request_message_message = get_next_movement_request_message_message(movement_request_message_message)) {
/** \def FINISH_MOVEMENT_REQUEST_MESSAGE_MESSAGE_LOOP
 * \brief Finish of loop to process movement_request_message messages. */
#define FINISH_MOVEMENT_REQUEST_MESSAGE_MESSAGE_LOOP }
/** \def START_MOVEMENT_RESPONSE_MESSAGE_MESSAGE_LOOP
 * \brief Start of loop to process movement_response_message messages. */
#define START_MOVEMENT_RESPONSE_MESSAGE_MESSAGE_LOOP  for(movement_response_message_message = get_first_movement_response_message_message(); movement_response_message_message != NULL; movement_response_message_message = get_next_movement_response_message_message(movement_response_message_message)) {
/** \def FINISH_MOVEMENT_RESPONSE_MESSAGE_MESSAGE_LOOP
 * \brief Finish of loop to process movement_response_message messages. */
#define FINISH_MOVEMENT_RESPONSE_MESSAGE_MESSAGE_LOOP }
/** \def START_MOVEMENT_TRANSACTION_MESSAGE_MESSAGE_LOOP
 * \brief Start of loop to process movement_transaction_message messages. */
#define START_MOVEMENT_TRANSACTION_MESSAGE_MESSAGE_LOOP  for(movement_transaction_message_message = get_first_movement_transaction_message_message(); movement_transaction_message_message != NULL; movement_transaction_message_message = get_next_movement_transaction_message_message(movement_transaction_message_message)) {
/** \def FINISH_MOVEMENT_TRANSACTION_MESSAGE_MESSAGE_LOOP
 * \brief Finish of loop to process movement_transaction_message messages. */
#define FINISH_MOVEMENT_TRANSACTION_MESSAGE_MESSAGE_LOOP }


struct FLAME_output
{
	int type; /* 0=snapshot 1=Agent */
	int format; /* 0=XML */
	char * location;
	int period;
	int phase;
	int flag; /* Used when outputting to show it has been used */

	struct FLAME_output * next;
};
typedef struct FLAME_output FLAME_output;

/** \struct int_array
 * \brief Dynamic array to hold integers.
 *
 * Holds a pointer to an integer array and values for size and memory size.
 */
struct int_array
{
	int size;
	int total_size;

	int * array;
};

/** \struct float_array
 * \brief Dynamic array to hold floats.
 *
 * Holds a pointer to an float array and values for size and memory size.
 */
struct float_array
{
	int size;
	int total_size;

	float * array;
};

/** \struct double_array
 * \brief Dynamic array to hold doubles.
 *
 * Holds a pointer to a double array and values for size and memory size.
 */
struct double_array
{
	int size;
	int total_size;

	double * array;
};

/** \struct char_array
 * \brief Dynamic array to hold chars.
 *
 * Holds a pointer to a char array and values for size and memory size.
 */
struct char_array
{
	int size;
	int total_size;

	char * array;
};

/** \typedef struct int_array int_array
 * \brief Typedef for int_array struct.
 */
typedef struct int_array int_array;
/** \typedef struct float_array float_array
 * \brief Typedef for float_array struct.
 */
typedef struct float_array float_array;
/** \typedef struct double_array double_array
 * \brief Typedef for double_array struct.
 */
typedef struct double_array double_array;
/** \typedef struct char_array char_array
 * \brief Typedef for char_array struct.
 */
typedef struct char_array char_array;


/** \struct xmachine_memory_Agent
 * \brief Holds memory of xmachine Agent.
 */
struct xmachine_memory_Agent
{
	double pos_x;	/**< X-machine memory variable pos_x of type double. */
	double pos_y;	/**< X-machine memory variable pos_y of type double. */
	double target_pos_x;	/**< X-machine memory variable target_pos_x of type double. */
	double target_pos_y;	/**< X-machine memory variable target_pos_y of type double. */
	int agent_id;	/**< X-machine memory variable agent_id of type int. */
	int state;	/**< X-machine memory variable state of type int. */
	int sugar_level;	/**< X-machine memory variable sugar_level of type int. */
	int metabolism;	/**< X-machine memory variable metabolism of type int. */
	int env_sugar_level;	/**< X-machine memory variable env_sugar_level of type int. */
	int max_env_sugar_level;	/**< X-machine memory variable max_env_sugar_level of type int. */
};

/** \struct xmachine_memory_Agent_holder
 * \brief Holds struct of memory of xmachine Agent.
 */
struct xmachine_memory_Agent_holder
{
	/*@dependent@*/ struct xmachine_memory_Agent * agent;	/**< Pointer to X-machine memory Agent. */

	/*@dependent@*/ struct xmachine_memory_Agent_holder * prev;	/**< Pointer to previous Agent agent in the list.  */
	/*@dependent@*/ struct xmachine_memory_Agent_holder * next;	/**< Pointer to next Agent agent in the list.  */
};

/** \struct xmachine_memory_Agent_holder
 * \brief Holds struct of memory of xmachine Agent.
 */
struct xmachine_memory_Agent_state
{
	/*@dependent@*/ struct xmachine_memory_Agent_holder * agents;	/**< Pointer to X-machine memory Agent. */

	int count;	/**< Number of agents that were in this state.  */
};

/** \struct xmachine
 * \brief Holds xmachines.
 */
struct xmachine
{
	/*@dependent@*/ /*@null@*/ /*@out@*/ struct xmachine_memory_Agent * xmachine_Agent;	/**< Pointer to X-machine memory of type Agent.  */
};

/** \var void* FLAME_m_movement_request_message_composite_params\n
 * \brief Pointer to message sync agent composite params */
void* FLAME_m_movement_request_message_composite_params;

/** \struct m_movement_request_message
 * \brief Holds message of type movement_request_message_message.
 */
struct m_movement_request_message
{
	double pos_x;	/**< Message memory variable pos_x of type double. */
	double pos_y;	/**< Message memory variable pos_y of type double. */
	int state;	/**< Message memory variable state of type int. */
	int env_sugar_level;	/**< Message memory variable env_sugar_level of type int. */
};

/** \var void* FLAME_m_movement_response_message_composite_params\n
 * \brief Pointer to message sync agent composite params */
void* FLAME_m_movement_response_message_composite_params;

/** \struct m_movement_response_message
 * \brief Holds message of type movement_response_message_message.
 */
struct m_movement_response_message
{
	double pos_x;	/**< Message memory variable pos_x of type double. */
	double pos_y;	/**< Message memory variable pos_y of type double. */
	double target_pos_x;	/**< Message memory variable target_pos_x of type double. */
	double target_pos_y;	/**< Message memory variable target_pos_y of type double. */
	int agent_id;	/**< Message memory variable agent_id of type int. */
	int state;	/**< Message memory variable state of type int. */
	int sugar_level;	/**< Message memory variable sugar_level of type int. */
	int metabolism;	/**< Message memory variable metabolism of type int. */
};

/** \var void* FLAME_m_movement_transaction_message_composite_params\n
 * \brief Pointer to message sync agent composite params */
void* FLAME_m_movement_transaction_message_composite_params;

/** \struct m_movement_transaction_message
 * \brief Holds message of type movement_transaction_message_message.
 */
struct m_movement_transaction_message
{
	double pos_x;	/**< Message memory variable pos_x of type double. */
	double pos_y;	/**< Message memory variable pos_y of type double. */
	int agent_id;	/**< Message memory variable agent_id of type int. */
	int state;	/**< Message memory variable state of type int. */
};

/** \typedef struct xmachine xmachine
 * \brief Typedef for xmachine struct.
 */
typedef struct xmachine xmachine;
/** \var typedef xmachine_memory_Agent xmachine_memory_Agent
 * \brief Typedef for xmachine_memory_Agent struct.
 */
typedef struct xmachine_memory_Agent xmachine_memory_Agent;
/** \var typedef xmachine_memory_Agent xmachine_memory_Agent
 * \brief Typedef for xmachine_memory_Agent struct.
 */
typedef struct xmachine_memory_Agent_holder xmachine_memory_Agent_holder;
/** \var typedef xmachine_memory_Agent xmachine_memory_Agent
 * \brief Typedef for xmachine_memory_Agent struct.
 */
typedef struct xmachine_memory_Agent_state xmachine_memory_Agent_state;
/** \typedef m_movement_request_message m_movement_request_message
 * \brief Typedef for m_movement_request_message struct.
 */
typedef struct m_movement_request_message m_movement_request_message;

/** \typedef m_movement_response_message m_movement_response_message
 * \brief Typedef for m_movement_response_message struct.
 */
typedef struct m_movement_response_message m_movement_response_message;

/** \typedef m_movement_transaction_message m_movement_transaction_message
 * \brief Typedef for m_movement_transaction_message struct.
 */
typedef struct m_movement_transaction_message m_movement_transaction_message;


/** \struct location
 * \brief Holds location for calculating space partitioning .
 */
struct location
{
	double point;		/**< Point on an axis. */

	struct location * next;	/**< Pointer to next location on the list. */
};

/** \struct node_information
 * \brief Holds node information .
 */
struct node_information
{
	int node_id;	/**< Node ID. */
	double partition_data[6];	/**< Defines bounding box. */
	int neighbours[10]; /**< Defines the neighbours to this node - -99 if no neighbour */
	int agents_in_halo;	/**< Number of agents in the halo region. */
	int agent_total;	/**< Total number of agents on the node. */
	struct xmachine * agents;	/**< Pointer to list of X-machines. */
	struct m_movement_request_message * movement_request_message_messages;	/**< Pointer to movement_request_message message list. */
	struct m_movement_response_message * movement_response_message_messages;	/**< Pointer to movement_response_message message list. */
	struct m_movement_transaction_message * movement_transaction_message_messages;	/**< Pointer to movement_transaction_message message list. */

	struct node_information * next;	/**< Pointer to next node on the list. */
};


/** \typedef struct location location
 * \brief Typedef for location struct.
 */
typedef struct location location;
/** \typedef struct node_information node_information
 * \brief Typedef for node_information struct.
 */
typedef struct node_information node_information;

/** \var xmachine * temp_xmachine
* \brief Pointer to xmachine to initialise linked list. */
xmachine * temp_xmachine;

/** \var m_movement_request_message * temp_movement_request_message_message
* \brief Pointer to m_movement_request_message to initialise linked list. */
m_movement_request_message * temp_movement_request_message_message;
/** \var m_movement_response_message * temp_movement_response_message_message
* \brief Pointer to m_movement_response_message to initialise linked list. */
m_movement_response_message * temp_movement_response_message_message;
/** \var m_movement_transaction_message * temp_movement_transaction_message_message
* \brief Pointer to m_movement_transaction_message to initialise linked list. */
m_movement_transaction_message * temp_movement_transaction_message_message;
/** \var node_information * temp_node_info
* \brief Pointer to node_information to initialise linked list. */
node_information * temp_node_info;
/** \var char outputpath[1000]
* \brief Output path for files. */
char outputpath[1000];
/** \var long total_time
* \brief Total time for the simulation run (in seconds) */
double total_time;
/** \var int total_messages
* \brief Total messages sent between nodes for the simulation run */
int total_messages;
/** \var int totalnodes
* \brief Number of nodes */
int totalnodes;
/** \var xmachine ** p_xmachine
* \brief Pointer to first pointer of x-machine memory list */
//xmachine ** p_xmachine;
/** \var xmachine * current_xmachine
* \brief Pointer to current x-machine memory that is being processed */
xmachine * current_xmachine;
/* Pointer to current $agent_name agent */
/*@dependent@*/ /*@null@*/ /*@out@*/ xmachine_memory_Agent * current_xmachine_Agent;
/*@dependent@*/ xmachine_memory_Agent_holder * temp_xmachine_Agent_holder;
/*@dependent@*/ /*@null@*/ /*@out@*/ xmachine_memory_Agent_holder * current_xmachine_Agent_holder;
xmachine_memory_Agent_state * current_xmachine_Agent_next_state; /* New agents added to this state */
/* Pointer to list of Agent agents in state 7 state */
//xmachine_memory_Agent * temp_xmachine_Agent_7;
xmachine_memory_Agent_state * Agent_7_state;
/* Pointer to list of Agent agents in state 6 state */
//xmachine_memory_Agent * temp_xmachine_Agent_6;
xmachine_memory_Agent_state * Agent_6_state;
/* Pointer to list of Agent agents in state 5 state */
//xmachine_memory_Agent * temp_xmachine_Agent_5;
xmachine_memory_Agent_state * Agent_5_state;
/* Pointer to list of Agent agents in state 4 state */
//xmachine_memory_Agent * temp_xmachine_Agent_4;
xmachine_memory_Agent_state * Agent_4_state;
/* Pointer to list of Agent agents in state 3 state */
//xmachine_memory_Agent * temp_xmachine_Agent_3;
xmachine_memory_Agent_state * Agent_3_state;
/* Pointer to list of Agent agents in state 2 state */
//xmachine_memory_Agent * temp_xmachine_Agent_2;
xmachine_memory_Agent_state * Agent_2_state;
/* Pointer to list of Agent agents in state 1 state */
//xmachine_memory_Agent * temp_xmachine_Agent_1;
xmachine_memory_Agent_state * Agent_1_state;
/* Pointer to list of Agent agents in state start state */
//xmachine_memory_Agent * temp_xmachine_Agent_start;
xmachine_memory_Agent_state * Agent_start_state;



MBt_Board b_movement_request_message;
MBt_Iterator i_movement_request_message;

MBt_Board b_movement_response_message;
MBt_Iterator i_movement_response_message;

MBt_Board b_movement_transaction_message;
MBt_Iterator i_movement_transaction_message;


/** \var m_movement_request_message * movement_request_message_message
* \brief Pointer to message struct for looping through movement_request_message message list */
m_movement_request_message * movement_request_message_message;
/** \var m_movement_response_message * movement_response_message_message
* \brief Pointer to message struct for looping through movement_response_message message list */
m_movement_response_message * movement_response_message_message;
/** \var m_movement_transaction_message * movement_transaction_message_message
* \brief Pointer to message struct for looping through movement_transaction_message message list */
m_movement_transaction_message * movement_transaction_message_message;
/** \var FLAME_output ** FLAME_outputs
* \brief Pointer to list of outputs */
FLAME_output * FLAME_outputs;
/** \var node_information * p_node_info
* \brief Pointer to first pointer of node list */
node_information ** p_node_info;
/** \var node_information * current_node
* \brief Pointer to current node */
node_information * current_node;


/** \var int node_number\n
 *  \brief Node number (not needed for serial codes) */
int node_number;



/** \var int iteration_loop
* \brief The current iteration number */
int iteration_loop;
/** \var int output_frequency
* \brief Frequency to output results */
int output_frequency;
/** \var int output_offset
* \brief Offset to output results */
int output_offset;

/** \def SPINF
* \brief Dummy inf value for space partition data. */
#define SPINF 999999.123456
/** \def RELEASE
* \brief Used to kill an agent via 'return RELEASE;'. */
#define RELEASE 1
/** \def kill_me_now
* \brief Used to kill an agent via 'kill_me_now'. */
#define kill_me_now return 1

void initialise_pointers(void);
void initialise_unit_testing(void);
FLAME_output * add_FLAME_output(FLAME_output ** outputs);
void free_FLAME_outputs(FLAME_output ** outputs);
void add_location(double point, location ** p_location);
void freelocations(location ** p_location);
void add_node(int node_id, double minx, double maxx, double miny, double maxy, double minz, double maxz);
void clean_up(int code);
void propagate_agents(void);
void propagate_messages_init(void);
void propagate_messages_complete(void);
void create_partitions(char * filename, int * itno);
void free_node_info(void);
void free_agent(void);
void freexmachines(void);
/* model datatypes */

void init_int_static_array(/*@out@*/ int * array, int size);
void init_int_array(int_array * array);
void reset_int_array(int_array * array);
void free_int_array(int_array * array);
void copy_int_array(int_array * from, int_array * to);
//void sort_int_array(int_array array);
//int quicksort_int(int array, int elements);
void add_int(int_array * array, int new_int);
void remove_int(int_array * array, int index);
void print_int_array(int_array * array);
void init_float_static_array(float * array, int size);
void init_float_array(float_array * array);
void reset_float_array(float_array * array);
void free_float_array(float_array * array);
void copy_float_array(float_array * from, float_array * to);
//void sort_float_array(float_array array);
//int quicksort_float(float array, int elements);
void add_float(float_array * array, float new_float);
void remove_float(float_array * array, int index);
void print_float_array(float_array * array);
void init_double_static_array(/*@out@*/ double* array, int size);
void init_double_array(double_array * array);
void reset_double_array(double_array * array);
void free_double_array(double_array * array);
void copy_double_array(double_array * from, double_array * to);
//void sort_double_array(double_array array);
//int quicksort_double(double array, int elements);
void add_double(double_array * array, double new_double);
void remove_double(double_array * array, int index);
void print_double_array(double_array * array);
void init_char_static_array(/*@out@*/ char * array, int size);
void init_char_array(char_array * array);
void reset_char_array(char_array * array);
void free_char_array(char_array * array);
void copy_char_array(char_array * from, char_array * to);
void add_char(char_array * array, char new_char);
void remove_char(char_array * array, int index);
char * copy_array_to_str(char_array * array);
void print_char_array(char_array * array);
int idle(void);
/* xml.c */
int read_int_static_array(char * buffer, int buffer_size, int * j, int * int_static_array, int size);
int read_float_static_array(char * buffer, int buffer_size, int * j, float * float_static_array, int size);
int read_double_static_array(char * buffer, int buffer_size, int * j, double * double_static_array, int size);
int read_char_static_array(char * buffer, int buffer_size, int * j, char * char_static_array, int size);
int read_int_dynamic_array(char * buffer, int buffer_size, int * j, int_array * int_dynamic_array);
int read_float_dynamic_array(char * buffer, int buffer_size, int * j, float_array * float_dynamic_array);
int read_double_dynamic_array(char * buffer, int buffer_size, int * j, double_array * double_dynamic_array);
int read_char_dynamic_array(char * buffer, int buffer_size, int * j, char_array * char_dynamic_array);


void readinitialstates(char * filename, char * filelocation, int * itno, double cloud_data[],
					   int partition_method, int flag);
void saveiterationdata(int iteration_number);


xmachine_memory_Agent_state * init_Agent_state();
xmachine_memory_Agent * init_Agent_agent();
void free_Agent_agent(xmachine_memory_Agent_holder * tmp, xmachine_memory_Agent_state * state);
void transition_Agent_agent(xmachine_memory_Agent_holder * tmp, xmachine_memory_Agent_state * from_state, xmachine_memory_Agent_state * to_state);
void add_Agent_agent_internal(xmachine_memory_Agent * agent, xmachine_memory_Agent_state * state);
void add_Agent_agent(double pos_x, double pos_y, double target_pos_x, double target_pos_y, int agent_id, int state, int sugar_level, int metabolism, int env_sugar_level, int max_env_sugar_level);
void unittest_init_Agent_agent();
void unittest_free_Agent_agent();

void add_movement_request_message_message(double pos_x, double pos_y, int state, int env_sugar_level);
m_movement_request_message * add_movement_request_message_message_internal(void);
m_movement_request_message * get_first_movement_request_message_message(void);
m_movement_request_message * get_next_movement_request_message_message(m_movement_request_message * current);
void freemovement_request_messagemessages(void);

void add_movement_response_message_message(double pos_x, double pos_y, double target_pos_x, double target_pos_y, int agent_id, int state, int sugar_level, int metabolism);
m_movement_response_message * add_movement_response_message_message_internal(void);
m_movement_response_message * get_first_movement_response_message_message(void);
m_movement_response_message * get_next_movement_response_message_message(m_movement_response_message * current);
void freemovement_response_messagemessages(void);

void add_movement_transaction_message_message(double pos_x, double pos_y, int agent_id, int state);
m_movement_transaction_message * add_movement_transaction_message_message_internal(void);
m_movement_transaction_message * get_first_movement_transaction_message_message(void);
m_movement_transaction_message * get_next_movement_transaction_message_message(m_movement_transaction_message * current);
void freemovement_transaction_messagemessages(void);


void set_pos_x(double pos_x);
double get_pos_x();
void set_pos_y(double pos_y);
double get_pos_y();
void set_target_pos_x(double target_pos_x);
double get_target_pos_x();
void set_target_pos_y(double target_pos_y);
double get_target_pos_y();
void set_agent_id(int agent_id);
int get_agent_id();
void set_state(int state);
int get_state();
void set_sugar_level(int sugar_level);
int get_sugar_level();
void set_metabolism(int metabolism);
int get_metabolism();
void set_env_sugar_level(int env_sugar_level);
int get_env_sugar_level();
void set_max_env_sugar_level(int max_env_sugar_level);
int get_max_env_sugar_level();
int agent_get_id(void);
double agent_get_x(void);
double agent_get_y(void);
double agent_get_z(void);
/* partitioning.c */
void partition_data(int totalnodes, xmachine ** agent_list, double cloud_data[], int partition_method);


void save_partition_data(void);
void generate_partitions(double cloud_data[], int partitions, int partition_method);

/* messageboard.c */
m_movement_request_message * get_next_message_movement_request_message_in_range(m_movement_request_message * current);



m_movement_response_message * get_next_message_movement_response_message_in_range(m_movement_response_message * current);



m_movement_transaction_message * get_next_message_movement_transaction_message_in_range(m_movement_transaction_message * current);




/* memory.c */
xmachine * add_xmachine(void);


/* rules.c */
int FLAME_integer_in_array(int a, int * b, int size);

/* timing.c */
double get_time(void);

int metabolise_and_growback(void);
int movement_request_gen(void);
int movement_request(void);
int movement_response_gen(void);
int movement_response(void);
int movement_transaction_gen(void);
int movement_transaction(void);
#endif
