#include "header.h"
#include "libabl.h"

double PI = 3.14159;
int AGENT_STATE_UNOCCUPIED = 0;
int AGENT_STATE_OCCUPIED = 1;
int AGENT_STATE_MOVEMENT_REQUESTED = 2;
int AGENT_STATE_MOVEMENT_UNRESOLVED = 3;
int SUGAR_GROWBACK_RATE = 1;
int min_start_sugar_level = 1;
int max_start_sugar_level = 10;
double radius = 1.5;
int num_timesteps = 100;
double occupiedFrac = 0.1;
int num_agents = 1000;
int grid_width = 31;
float2 sugar_center1 = {7.75, 7.75};
float2 sugar_center2 = {23.25, 23.25};
int global_max_env_sugar_level = 50;
double sugar_variance = 24.025;
float2 random_1(float2 min, float2 max) {
    return float2_create(random_float(min.x, max.x), random_float(min.y, max.y));
}
float3 random_2(float3 min, float3 max) {
    return float3_create(random_float(min.x, max.x), random_float(min.y, max.y), random_float(min.z, max.z));
}
double random_3(double max) {
    return random_float(0, max);
}
float2 random_4(float2 max) {
    return random_1(float2_fill(0), max);
}
float3 random_5(float3 max) {
    return random_2(float3_fill(0), max);
}
int randomInt_1(int max) {
    return random_int(0, max);
}
double clamp(double pos, double min, double max) {
    return ((pos < min) ? min : ((pos > max) ? max : pos));
}
float2 clamp_1(float2 pos, float2 min, float2 max) {
    return float2_create(((pos.x < min.x) ? min.x : ((pos.x > max.x) ? max.x : pos.x)), ((pos.y < min.y) ? min.y : ((pos.y > max.y) ? max.y : pos.y)));
}
float3 clamp_2(float3 pos, float3 min, float3 max) {
    return float3_create(((pos.x < min.x) ? min.x : ((pos.x > max.x) ? max.x : pos.x)), ((pos.y < min.y) ? min.y : ((pos.y > max.y) ? max.y : pos.y)), ((pos.z < min.z) ? min.z : ((pos.z > max.z) ? max.z : pos.z)));
}
double clamp_3(double pos, double max) {
    return clamp(pos, 0, max);
}
float2 clamp_4(float2 pos, float2 max) {
    return clamp_1(pos, float2_fill(0), max);
}
float3 clamp_5(float3 pos, float3 max) {
    return clamp_2(pos, float3_fill(0), max);
}
double wraparound(double pos, double max) {
    return ((pos < 0) ? (max + pos) : ((pos >= max) ? (pos - max) : pos));
}
float2 wraparound_1(float2 pos, float2 max) {
    return float2_create(((pos.x < 0) ? (max.x + pos.x) : ((pos.x >= max.x) ? (pos.x - max.x) : pos.x)), ((pos.y < 0) ? (max.y + pos.y) : ((pos.y >= max.y) ? (pos.y - max.y) : pos.y)));
}
float3 wraparound_2(float3 pos, float3 max) {
    return float3_create(((pos.x < 0) ? (max.x + pos.x) : ((pos.x >= max.x) ? (pos.x - max.x) : pos.x)), ((pos.y < 0) ? (max.y + pos.y) : ((pos.y >= max.y) ? (pos.y - max.y) : pos.y)), ((pos.z < 0) ? (max.z + pos.z) : ((pos.z >= max.z) ? (pos.z - max.z) : pos.z)));
}
bool is_inside(float2 pos, float2 max) {
    return ((((pos.x >= 0) && (pos.y >= 0)) && (pos.x <= max.x)) && (pos.y <= max.y));
}
int calc_max_env_sugar_level(int x, int y) {
    int gmax = global_max_env_sugar_level;
    float2 pos = float2_create(x, y);
    int max = 0;
    double d1 = dist_float2(pos, sugar_center1);
    max += ((double) gmax * exp((((-d1) * d1) / (2.0 * sugar_variance))));
    double d2 = dist_float2(pos, sugar_center2);
    max += ((double) gmax * exp((((-d2) * d2) / (2.0 * sugar_variance))));
    return max;
}
int metabolise_and_growback() {
    float2 in_pos = float2_create(get_pos_x(), get_pos_y()); (void) in_pos;
    float2 in_target_pos = float2_create(get_target_pos_x(), get_target_pos_y()); (void) in_target_pos;
    int new_env_sugar_level = get_env_sugar_level();
    if ((get_state() == AGENT_STATE_OCCUPIED)) {
        int new_sugar_level = ((get_sugar_level() + get_env_sugar_level()) - get_metabolism());
        new_env_sugar_level = 0;
        if ((new_sugar_level <= 0)) {
            set_state(AGENT_STATE_UNOCCUPIED);
            set_agent_id((-1));
            set_sugar_level(0);
            set_metabolism(0);
        } else {
            set_state(AGENT_STATE_MOVEMENT_UNRESOLVED);
            set_sugar_level(new_sugar_level);
        }
    }
    new_env_sugar_level += SUGAR_GROWBACK_RATE;
    if ((new_env_sugar_level > get_max_env_sugar_level())) {
        new_env_sugar_level = get_max_env_sugar_level();
    }
    set_env_sugar_level(new_env_sugar_level);
    return 0;
}

int movement_request_gen() {
    add_movement_request_message_message(get_pos_x(), get_pos_y(), get_state(), get_env_sugar_level());
    return 0;
}

int movement_request() {
    float2 in_pos = float2_create(get_pos_x(), get_pos_y()); (void) in_pos;
    float2 in_target_pos = float2_create(get_target_pos_x(), get_target_pos_y()); (void) in_target_pos;
    if ((get_state() == AGENT_STATE_MOVEMENT_UNRESOLVED)) {
        int best_sugar_level = (-1);
        float2 best_pos = float2_fill(0);
        START_MOVEMENT_REQUEST_MESSAGE_MESSAGE_LOOP
            float2 nx_pos = float2_create(movement_request_message_message->pos_x, movement_request_message_message->pos_y); (void) nx_pos;
            if (dist_float2(nx_pos, in_pos) >= radius) continue;
            {
                if (float2_equals(nx_pos, in_pos)) continue;
                if (((movement_request_message_message->state == AGENT_STATE_UNOCCUPIED) && (movement_request_message_message->env_sugar_level > best_sugar_level))) {
                    best_sugar_level = movement_request_message_message->env_sugar_level;
                    best_pos = nx_pos;
                }
            }
        FINISH_MOVEMENT_REQUEST_MESSAGE_MESSAGE_LOOP
        if ((best_sugar_level > get_env_sugar_level())) {
            set_state(AGENT_STATE_MOVEMENT_REQUESTED);
            set_target_pos_x(best_pos.x);
            set_target_pos_y(best_pos.y);
            
        } else {
            set_state(AGENT_STATE_OCCUPIED);
        }
    }
    return 0;
}

int movement_response_gen() {
    add_movement_response_message_message(get_pos_x(), get_pos_y(), get_target_pos_x(), get_target_pos_y(), get_agent_id(), get_state(), get_sugar_level(), get_metabolism());
    return 0;
}

int movement_response() {
    float2 in_pos = float2_create(get_pos_x(), get_pos_y()); (void) in_pos;
    float2 in_target_pos = float2_create(get_target_pos_x(), get_target_pos_y()); (void) in_target_pos;
    if ((get_state() == AGENT_STATE_UNOCCUPIED)) {
        int best_priority = (-1);
        int best_agent_id = (-1);
        int best_sugar_level = (-1);
        int best_metabolism = (-1);
        START_MOVEMENT_RESPONSE_MESSAGE_MESSAGE_LOOP
            float2 nx_pos = float2_create(movement_response_message_message->pos_x, movement_response_message_message->pos_y); (void) nx_pos;
            float2 nx_target_pos = float2_create(movement_response_message_message->target_pos_x, movement_response_message_message->target_pos_y); (void) nx_target_pos;
            if (dist_float2(nx_pos, in_pos) >= radius) continue;
            {
                if (((movement_response_message_message->state == AGENT_STATE_MOVEMENT_REQUESTED) && float2_equals(nx_target_pos, in_pos))) {
                    int message_priority = 0;
                    if ((message_priority > best_priority)) {
                        best_priority = message_priority;
                        best_agent_id = movement_response_message_message->agent_id;
                        best_sugar_level = movement_response_message_message->sugar_level;
                        best_metabolism = movement_response_message_message->metabolism;
                    }
                }
            }
        FINISH_MOVEMENT_RESPONSE_MESSAGE_MESSAGE_LOOP
        if ((best_agent_id >= 0)) {
            set_state(AGENT_STATE_OCCUPIED);
            set_agent_id(best_agent_id);
            set_sugar_level(best_sugar_level);
            set_metabolism(best_metabolism);
        }
    }
    return 0;
}

int movement_transaction_gen() {
    add_movement_transaction_message_message(get_pos_x(), get_pos_y(), get_agent_id(), get_state());
    return 0;
}

int movement_transaction() {
    float2 in_pos = float2_create(get_pos_x(), get_pos_y()); (void) in_pos;
    float2 in_target_pos = float2_create(get_target_pos_x(), get_target_pos_y()); (void) in_target_pos;
    if ((get_state() == AGENT_STATE_MOVEMENT_REQUESTED)) {
        bool moved = false;
        START_MOVEMENT_TRANSACTION_MESSAGE_MESSAGE_LOOP
            float2 nx_pos = float2_create(movement_transaction_message_message->pos_x, movement_transaction_message_message->pos_y); (void) nx_pos;
            if (dist_float2(nx_pos, in_pos) >= radius) continue;
            {
                if (((movement_transaction_message_message->state == AGENT_STATE_OCCUPIED) && (movement_transaction_message_message->agent_id == get_agent_id()))) {
                    moved = true;
                    set_state(AGENT_STATE_UNOCCUPIED);
                    set_agent_id((-1));
                    set_sugar_level(0);
                    set_metabolism(0);
                }
            }
        FINISH_MOVEMENT_TRANSACTION_MESSAGE_MESSAGE_LOOP
        if ((!moved)) {
            set_state(AGENT_STATE_OCCUPIED);
        }
    }
    return 0;
}

