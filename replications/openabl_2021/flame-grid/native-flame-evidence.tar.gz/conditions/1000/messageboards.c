/**
 * \file  messageboards.c
 * \brief Holds message board functions.
 */

#include "header.h"



/* Box filtering functions */




union pu_movement_request_message 
{
    m_movement_request_message *ptr;
    void *ptr_anon;
};

/** \fn void add_movement_request_message_message(double pos_x, double pos_y, int state, int env_sugar_level)
 * \brief Add movement_request_message message by calling internal and processing.
 * \param pos_x Message variable.
 * \param pos_y Message variable.
 * \param state Message variable.
 * \param env_sugar_level Message variable.
 */
void add_movement_request_message_message(double pos_x, double pos_y, int state, int env_sugar_level)
{
    int rc;
	m_movement_request_message msg;
    
    msg.pos_x = pos_x;
    msg.pos_y = pos_y;
    msg.state = state;
    msg.env_sugar_level = env_sugar_level;
    
    
    rc = MB_AddMessage(b_movement_request_message, &msg);
    #ifdef ERRCHECK
    if (rc != MB_SUCCESS)
    {
       fprintf(stderr, "ERROR: Could not add message to 'movement_request_message' board\n");
       switch(rc) {
           case MB_ERR_INVALID:
               fprintf(stderr, "\t reason: 'movement_request_message' board has not been created?\n");
               break;
           case MB_ERR_MEMALLOC:
               fprintf(stderr, "\t reason: out of memory\n");
               break;
           case MB_ERR_LOCKED:
               fprintf(stderr, "\t reason: 'movement_request_message' board is locked\n");
               break;
           case MB_ERR_INTERNAL:
               fprintf(stderr, "\t reason: internal error. Recompile libmoard in debug mode for more info \n");
               break;
	       default:
               fprintf(stderr, "\t MB_AddMessage returned error code: %d (see libmboard docs for details)\n", rc);
               break;
	   }
	      
	   
       exit(rc);
    }
    #endif
}

inline static m_movement_request_message* getInternalMessage_movement_request_message(void)
{
    static m_movement_request_message *msg_prev = NULL;
    union pu_movement_request_message msg_pu;
    int rc;
    
    /* deallocate previously returned message */
    if (msg_prev != NULL) 
    {
        free(msg_prev);
    }
    else 
    {
        rc = MB_Iterator_Rewind(i_movement_request_message); 
        #ifdef ERRCHECK
        if (rc != MB_SUCCESS)
        {
            fprintf(stderr, "ERROR: Could not rewind 'movement_request_message' Iterator\n");
            switch(rc) {
                case MB_ERR_INVALID:
                    fprintf(stderr, "\t reason: 'movement_request_message' Iterator has not been created?\n");
                    break;
	            default:
                    fprintf(stderr, "\t MB_Iterator_Rewind returned error code: %d (see libmboard docs for details)\n", rc);
                    break;
	        }
	       
	       
       	   exit(rc);
        }
        #endif
    }
    
    /* get next message from iterator */
    rc = MB_Iterator_GetMessage(i_movement_request_message, &(msg_pu.ptr_anon));
    #ifdef ERRCHECK
    if (rc != MB_SUCCESS)
    {
       fprintf(stderr, "ERROR: Could not get message from 'movement_request_message' Iterator\n");
       switch(rc) {
           case MB_ERR_INVALID:
               fprintf(stderr, "\t reason: 'movement_request_message' Iterator has not been created?\n");
               break;
           case MB_ERR_MEMALLOC:
               fprintf(stderr, "\t reason: out of memory\n");
               break;
	       default:
               fprintf(stderr, "\t MB_Iterator_GetMessage returned error code: %d (see libmboard docs for details)\n", rc);
               break;
	       }
	       
	       
       	   exit(rc);
    }
    #endif
    
    /* store pointer so memory can be deallocated later */
    msg_prev = msg_pu.ptr;
    
    return msg_pu.ptr;
}

/** \fn xmachine_message_movement_request_message * get_first_movement_request_message_message()
 * \brief Get the first movement_request_message message in the movement_request_message message list.
 * \return The first message in the list.
 */
m_movement_request_message * get_first_movement_request_message_message()
{
	return getInternalMessage_movement_request_message();
}

/** \fn xmachine_message_movement_request_message * get_next_movement_request_message_message(xmachine_message_movement_request_message * current)
 * \brief Get the next movement_request_message message in the movement_request_message message list after the current message.
 * \param current The current message in the list.
 * \return The next message in the list.
 */
m_movement_request_message * get_next_movement_request_message_message(m_movement_request_message * current)
{
	return getInternalMessage_movement_request_message();
}


/* Box filtering functions */




union pu_movement_response_message 
{
    m_movement_response_message *ptr;
    void *ptr_anon;
};

/** \fn void add_movement_response_message_message(double pos_x, double pos_y, double target_pos_x, double target_pos_y, int agent_id, int state, int sugar_level, int metabolism)
 * \brief Add movement_response_message message by calling internal and processing.
 * \param pos_x Message variable.
 * \param pos_y Message variable.
 * \param target_pos_x Message variable.
 * \param target_pos_y Message variable.
 * \param agent_id Message variable.
 * \param state Message variable.
 * \param sugar_level Message variable.
 * \param metabolism Message variable.
 */
void add_movement_response_message_message(double pos_x, double pos_y, double target_pos_x, double target_pos_y, int agent_id, int state, int sugar_level, int metabolism)
{
    int rc;
	m_movement_response_message msg;
    
    msg.pos_x = pos_x;
    msg.pos_y = pos_y;
    msg.target_pos_x = target_pos_x;
    msg.target_pos_y = target_pos_y;
    msg.agent_id = agent_id;
    msg.state = state;
    msg.sugar_level = sugar_level;
    msg.metabolism = metabolism;
    
    
    rc = MB_AddMessage(b_movement_response_message, &msg);
    #ifdef ERRCHECK
    if (rc != MB_SUCCESS)
    {
       fprintf(stderr, "ERROR: Could not add message to 'movement_response_message' board\n");
       switch(rc) {
           case MB_ERR_INVALID:
               fprintf(stderr, "\t reason: 'movement_response_message' board has not been created?\n");
               break;
           case MB_ERR_MEMALLOC:
               fprintf(stderr, "\t reason: out of memory\n");
               break;
           case MB_ERR_LOCKED:
               fprintf(stderr, "\t reason: 'movement_response_message' board is locked\n");
               break;
           case MB_ERR_INTERNAL:
               fprintf(stderr, "\t reason: internal error. Recompile libmoard in debug mode for more info \n");
               break;
	       default:
               fprintf(stderr, "\t MB_AddMessage returned error code: %d (see libmboard docs for details)\n", rc);
               break;
	   }
	      
	   
       exit(rc);
    }
    #endif
}

inline static m_movement_response_message* getInternalMessage_movement_response_message(void)
{
    static m_movement_response_message *msg_prev = NULL;
    union pu_movement_response_message msg_pu;
    int rc;
    
    /* deallocate previously returned message */
    if (msg_prev != NULL) 
    {
        free(msg_prev);
    }
    else 
    {
        rc = MB_Iterator_Rewind(i_movement_response_message); 
        #ifdef ERRCHECK
        if (rc != MB_SUCCESS)
        {
            fprintf(stderr, "ERROR: Could not rewind 'movement_response_message' Iterator\n");
            switch(rc) {
                case MB_ERR_INVALID:
                    fprintf(stderr, "\t reason: 'movement_response_message' Iterator has not been created?\n");
                    break;
	            default:
                    fprintf(stderr, "\t MB_Iterator_Rewind returned error code: %d (see libmboard docs for details)\n", rc);
                    break;
	        }
	       
	       
       	   exit(rc);
        }
        #endif
    }
    
    /* get next message from iterator */
    rc = MB_Iterator_GetMessage(i_movement_response_message, &(msg_pu.ptr_anon));
    #ifdef ERRCHECK
    if (rc != MB_SUCCESS)
    {
       fprintf(stderr, "ERROR: Could not get message from 'movement_response_message' Iterator\n");
       switch(rc) {
           case MB_ERR_INVALID:
               fprintf(stderr, "\t reason: 'movement_response_message' Iterator has not been created?\n");
               break;
           case MB_ERR_MEMALLOC:
               fprintf(stderr, "\t reason: out of memory\n");
               break;
	       default:
               fprintf(stderr, "\t MB_Iterator_GetMessage returned error code: %d (see libmboard docs for details)\n", rc);
               break;
	       }
	       
	       
       	   exit(rc);
    }
    #endif
    
    /* store pointer so memory can be deallocated later */
    msg_prev = msg_pu.ptr;
    
    return msg_pu.ptr;
}

/** \fn xmachine_message_movement_response_message * get_first_movement_response_message_message()
 * \brief Get the first movement_response_message message in the movement_response_message message list.
 * \return The first message in the list.
 */
m_movement_response_message * get_first_movement_response_message_message()
{
	return getInternalMessage_movement_response_message();
}

/** \fn xmachine_message_movement_response_message * get_next_movement_response_message_message(xmachine_message_movement_response_message * current)
 * \brief Get the next movement_response_message message in the movement_response_message message list after the current message.
 * \param current The current message in the list.
 * \return The next message in the list.
 */
m_movement_response_message * get_next_movement_response_message_message(m_movement_response_message * current)
{
	return getInternalMessage_movement_response_message();
}


/* Box filtering functions */




union pu_movement_transaction_message 
{
    m_movement_transaction_message *ptr;
    void *ptr_anon;
};

/** \fn void add_movement_transaction_message_message(double pos_x, double pos_y, int agent_id, int state)
 * \brief Add movement_transaction_message message by calling internal and processing.
 * \param pos_x Message variable.
 * \param pos_y Message variable.
 * \param agent_id Message variable.
 * \param state Message variable.
 */
void add_movement_transaction_message_message(double pos_x, double pos_y, int agent_id, int state)
{
    int rc;
	m_movement_transaction_message msg;
    
    msg.pos_x = pos_x;
    msg.pos_y = pos_y;
    msg.agent_id = agent_id;
    msg.state = state;
    
    
    rc = MB_AddMessage(b_movement_transaction_message, &msg);
    #ifdef ERRCHECK
    if (rc != MB_SUCCESS)
    {
       fprintf(stderr, "ERROR: Could not add message to 'movement_transaction_message' board\n");
       switch(rc) {
           case MB_ERR_INVALID:
               fprintf(stderr, "\t reason: 'movement_transaction_message' board has not been created?\n");
               break;
           case MB_ERR_MEMALLOC:
               fprintf(stderr, "\t reason: out of memory\n");
               break;
           case MB_ERR_LOCKED:
               fprintf(stderr, "\t reason: 'movement_transaction_message' board is locked\n");
               break;
           case MB_ERR_INTERNAL:
               fprintf(stderr, "\t reason: internal error. Recompile libmoard in debug mode for more info \n");
               break;
	       default:
               fprintf(stderr, "\t MB_AddMessage returned error code: %d (see libmboard docs for details)\n", rc);
               break;
	   }
	      
	   
       exit(rc);
    }
    #endif
}

inline static m_movement_transaction_message* getInternalMessage_movement_transaction_message(void)
{
    static m_movement_transaction_message *msg_prev = NULL;
    union pu_movement_transaction_message msg_pu;
    int rc;
    
    /* deallocate previously returned message */
    if (msg_prev != NULL) 
    {
        free(msg_prev);
    }
    else 
    {
        rc = MB_Iterator_Rewind(i_movement_transaction_message); 
        #ifdef ERRCHECK
        if (rc != MB_SUCCESS)
        {
            fprintf(stderr, "ERROR: Could not rewind 'movement_transaction_message' Iterator\n");
            switch(rc) {
                case MB_ERR_INVALID:
                    fprintf(stderr, "\t reason: 'movement_transaction_message' Iterator has not been created?\n");
                    break;
	            default:
                    fprintf(stderr, "\t MB_Iterator_Rewind returned error code: %d (see libmboard docs for details)\n", rc);
                    break;
	        }
	       
	       
       	   exit(rc);
        }
        #endif
    }
    
    /* get next message from iterator */
    rc = MB_Iterator_GetMessage(i_movement_transaction_message, &(msg_pu.ptr_anon));
    #ifdef ERRCHECK
    if (rc != MB_SUCCESS)
    {
       fprintf(stderr, "ERROR: Could not get message from 'movement_transaction_message' Iterator\n");
       switch(rc) {
           case MB_ERR_INVALID:
               fprintf(stderr, "\t reason: 'movement_transaction_message' Iterator has not been created?\n");
               break;
           case MB_ERR_MEMALLOC:
               fprintf(stderr, "\t reason: out of memory\n");
               break;
	       default:
               fprintf(stderr, "\t MB_Iterator_GetMessage returned error code: %d (see libmboard docs for details)\n", rc);
               break;
	       }
	       
	       
       	   exit(rc);
    }
    #endif
    
    /* store pointer so memory can be deallocated later */
    msg_prev = msg_pu.ptr;
    
    return msg_pu.ptr;
}

/** \fn xmachine_message_movement_transaction_message * get_first_movement_transaction_message_message()
 * \brief Get the first movement_transaction_message message in the movement_transaction_message message list.
 * \return The first message in the list.
 */
m_movement_transaction_message * get_first_movement_transaction_message_message()
{
	return getInternalMessage_movement_transaction_message();
}

/** \fn xmachine_message_movement_transaction_message * get_next_movement_transaction_message_message(xmachine_message_movement_transaction_message * current)
 * \brief Get the next movement_transaction_message message in the movement_transaction_message message list after the current message.
 * \param current The current message in the list.
 * \return The next message in the list.
 */
m_movement_transaction_message * get_next_movement_transaction_message_message(m_movement_transaction_message * current)
{
	return getInternalMessage_movement_transaction_message();
}

