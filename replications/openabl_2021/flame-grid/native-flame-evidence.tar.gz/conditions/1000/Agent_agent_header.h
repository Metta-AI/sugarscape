/**
 * \file  Agent_agent_header.h
 * \brief Header for agent type memory access.
 */

/** \def POS_X
 * \brief Direct access to pos_x of Agent agent memory variable. */
#define POS_X (current_xmachine_Agent->pos_x)
/** \def POS_Y
 * \brief Direct access to pos_y of Agent agent memory variable. */
#define POS_Y (current_xmachine_Agent->pos_y)
/** \def TARGET_POS_X
 * \brief Direct access to target_pos_x of Agent agent memory variable. */
#define TARGET_POS_X (current_xmachine_Agent->target_pos_x)
/** \def TARGET_POS_Y
 * \brief Direct access to target_pos_y of Agent agent memory variable. */
#define TARGET_POS_Y (current_xmachine_Agent->target_pos_y)
/** \def AGENT_ID
 * \brief Direct access to agent_id of Agent agent memory variable. */
#define AGENT_ID (current_xmachine_Agent->agent_id)
/** \def STATE
 * \brief Direct access to state of Agent agent memory variable. */
#define STATE (current_xmachine_Agent->state)
/** \def SUGAR_LEVEL
 * \brief Direct access to sugar_level of Agent agent memory variable. */
#define SUGAR_LEVEL (current_xmachine_Agent->sugar_level)
/** \def METABOLISM
 * \brief Direct access to metabolism of Agent agent memory variable. */
#define METABOLISM (current_xmachine_Agent->metabolism)
/** \def ENV_SUGAR_LEVEL
 * \brief Direct access to env_sugar_level of Agent agent memory variable. */
#define ENV_SUGAR_LEVEL (current_xmachine_Agent->env_sugar_level)
/** \def MAX_ENV_SUGAR_LEVEL
 * \brief Direct access to max_env_sugar_level of Agent agent memory variable. */
#define MAX_ENV_SUGAR_LEVEL (current_xmachine_Agent->max_env_sugar_level)
