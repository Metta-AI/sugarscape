from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent
workspace=root.parent.parent
build=root.parent/'openabl-flame-build-001'
reference=workspace/'sugarscape-openabl-reference'
env=os.environ.copy()
env['FLAME_XPARSER_DIR']=str(workspace/'sugarscape-openabl-xparser-reference')
env['LIBMBOARD_DIR']=str(build/'libmboard-install')
with (root/'completed.jsonl').open('x') as ledger:
 for size in [500,1000,2000,4000]:
  assert shutil.disk_usage(root).free>2*1024**3
  out=root/str(size);out.mkdir()
  tasks=[([str(root.parent/'openabl-build-001/OpenABL'),'-i',str(reference/'examples/sugarscape.abl'),'-o',str(out/'generated'),'-b','flame','-A',str(reference/'asset'),'-P',f'num_agents={size}','-P','num_timesteps=100'],out),([str(workspace/'sugarscape-openabl-xparser-reference/xparser'),'-f','XMLModelFile.xml'],out/'generated'),(['make',f'LIBMBOARD_DIR={build}/libmboard-install','SERIAL_CCOMP=/opt/homebrew/bin/gcc-16 -fcommon','SERIAL_LOADER=/opt/homebrew/bin/gcc-16','-j2'],out/'generated'),(['/opt/homebrew/bin/gcc-16','-O2','-std=c99','runner.c','libabl.c','-lm','-o','runner'],out/'generated'),(['./runner'],out/'generated')]
  for i,(command,cwd) in enumerate(tasks):
   with (out/f'stage-{i}.log').open('x') as log:r=subprocess.run(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
   (out/f'stage-{i}.json').write_text(json.dumps({'command':command,'cwd':str(cwd),'exit_code':r.returncode})+'\n');r.check_returncode()
  for step in [0,100]:
   xml=ET.parse(out/f'generated/iterations/{step}.xml').getroot();assert int(xml.findtext('itno'))==step;cells=[]
   for agent in xml.findall('xagent'):
    assert agent.findtext('name')=='Agent'
    cells.append({'pos':[float(agent.findtext('pos_x')),float(agent.findtext('pos_y'))],'target_pos':[float(agent.findtext('target_pos_x')),float(agent.findtext('target_pos_y'))],**{k:int(agent.findtext(k)) for k in ['agent_id','state','sugar_level','metabolism','env_sugar_level','max_env_sugar_level']}})
   cells.sort(key=lambda x:tuple(x['pos']));(out/f'state-{step}.json').write_text(json.dumps({'Agent':cells})+'\n')
  commands=[[sys.executable,str(root/'initialize.py'),str(out/'state-0.json'),str(out/'initialization-audit.json'),'--requested-cells',str(size)],[sys.executable,str(root/'replay.py'),str(out/'state-0.json'),str(out/'state-100.json'),str(out/'replay-audit.json'),'--steps','100','--buffer','copy']]
  for i,command in enumerate(commands):
   with (out/f'audit-{i}.log').open('x') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
  record={'requested_cells':size,'initialization':json.loads((out/'initialization-audit.json').read_text()),'replay':json.loads((out/'replay-audit.json').read_text()),'native_initial_xml_sha256':hashlib.sha256((out/'generated/iterations/0.xml').read_bytes()).hexdigest(),'native_final_xml_sha256':hashlib.sha256((out/'generated/iterations/100.xml').read_bytes()).hexdigest(),'completed_study':False};ledger.write(json.dumps(record)+'\n');ledger.flush();print(f'Validated native FLAME{size}',flush=True)
