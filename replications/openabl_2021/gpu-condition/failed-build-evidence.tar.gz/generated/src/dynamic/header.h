
/*
 * FLAME GPU v 1.5.X for CUDA 9
 * Copyright University of Sheffield.
 * Original Author: Dr Paul Richmond (user contributions tracked on https://github.com/FLAMEGPU/FLAMEGPU)
 * Contact: p.richmond@sheffield.ac.uk (http://www.paulrichmond.staff.shef.ac.uk)
 *
 * University of Sheffield retain all intellectual property and
 * proprietary rights in and to this software and related documentation.
 * Any use, reproduction, disclosure, or distribution of this software
 * and related documentation without an express license agreement from
 * University of Sheffield is strictly prohibited.
 *
 * For terms of licence agreement please attached licence or view licence
 * on www.flamegpu.com website.
 *
 */



#ifndef __HEADER
#define __HEADER

#if defined(__NVCC__) && defined(__CUDACC_VER_MAJOR__) && __CUDACC_VER_MAJOR__ >= 9
   // Disable annotation on defaulted function warnings (glm 0.9.9 and CUDA 9.0 introduced this warning)
   #pragma diag_suppress esa_on_defaulted_function_ignored 
#endif

#define GLM_FORCE_NO_CTOR_INIT
#define GLM_FORCE_PURE
#include <glm/glm.hpp>

/* General standard definitions */
//Threads per block (agents per block)
#define THREADS_PER_TILE 64
//Definition for any agent function or helper function
#define __FLAME_GPU_FUNC__ __device__
//Definition for a function used to initialise environment variables
#define __FLAME_GPU_INIT_FUNC__
#define __FLAME_GPU_STEP_FUNC__
#define __FLAME_GPU_EXIT_FUNC__
#define __FLAME_GPU_HOST_FUNC__ __host__

#define USE_CUDA_STREAMS
#define FAST_ATOMIC_SORTING

// FLAME GPU Version Macros.
#define FLAME_GPU_MAJOR_VERSION 1
#define FLAME_GPU_MINOR_VERSION 5
#define FLAME_GPU_PATCH_VERSION 0

/* Constant definitions */
// Maximum length file path in windows is 260 (soon to be longer) and 4096 under linux (assuming ext4)
#define MAX_FILEPATH_LENGTH 4096

typedef unsigned int uint;

//FLAME GPU vector types float, (i)nteger, (u)nsigned integer, (d)ouble
typedef glm::vec2 vec2;
typedef glm::vec3 vec3;
typedef glm::vec4 vec4;
typedef glm::vec2 fvec2;
typedef glm::vec3 fvec3;
typedef glm::vec4 fvec4;
typedef glm::ivec2 ivec2;
typedef glm::ivec3 ivec3;
typedef glm::ivec4 ivec4;
typedef glm::uvec2 uvec2;
typedef glm::uvec3 uvec3;
typedef glm::uvec4 uvec4;
typedef glm::dvec2 dvec2;
typedef glm::dvec3 dvec3;
typedef glm::dvec4 dvec4;

	
//if this is defined then the project must be built with sm_13 or later
#define _DOUBLE_SUPPORT_REQUIRED_

/* Agent population size definitions must be a multiple of THREADS_PER_TILE (default 64) */
//Maximum buffer size (largest agent buffer size)
#define buffer_size_MAX 256

//Maximum population size of xmachine_memory_Agent
#define xmachine_memory_Agent_MAX 256


  
  
/* Message population size definitions */
//Maximum population size of xmachine_mmessage_movement_request_message
#define xmachine_message_movement_request_message_MAX 256

//Maximum population size of xmachine_mmessage_movement_response_message
#define xmachine_message_movement_response_message_MAX 256

//Maximum population size of xmachine_mmessage_movement_transaction_message
#define xmachine_message_movement_transaction_message_MAX 256


/* Define preprocessor symbols for each message to specify the type, to simplify / improve portability */

#define xmachine_message_movement_request_message_partitioningSpatial
#define xmachine_message_movement_response_message_partitioningSpatial
#define xmachine_message_movement_transaction_message_partitioningSpatial

/* Spatial partitioning grid size definitions */
//xmachine_message_movement_request_message partition grid size (gridDim.X*gridDim.Y*gridDim.Z)
#define xmachine_message_movement_request_message_grid_size 100
//xmachine_message_movement_response_message partition grid size (gridDim.X*gridDim.Y*gridDim.Z)
#define xmachine_message_movement_response_message_grid_size 100
//xmachine_message_movement_transaction_message partition grid size (gridDim.X*gridDim.Y*gridDim.Z)
#define xmachine_message_movement_transaction_message_grid_size 100

/* Static Graph size definitions*/
  

/* Default visualisation Colour indices */
 
#define FLAME_GPU_VISUALISATION_COLOUR_BLACK 0
#define FLAME_GPU_VISUALISATION_COLOUR_RED 1
#define FLAME_GPU_VISUALISATION_COLOUR_GREEN 2
#define FLAME_GPU_VISUALISATION_COLOUR_BLUE 3
#define FLAME_GPU_VISUALISATION_COLOUR_YELLOW 4
#define FLAME_GPU_VISUALISATION_COLOUR_CYAN 5
#define FLAME_GPU_VISUALISATION_COLOUR_MAGENTA 6
#define FLAME_GPU_VISUALISATION_COLOUR_WHITE 7
#define FLAME_GPU_VISUALISATION_COLOUR_BROWN 8

/* enum types */

/**
 * MESSAGE_OUTPUT used for all continuous messaging
 */
enum MESSAGE_OUTPUT{
	single_message,
	optional_message,
};

/**
 * AGENT_TYPE used for templates device message functions
 */
enum AGENT_TYPE{
	CONTINUOUS,
	DISCRETE_2D
};


/* Agent structures */

/** struct xmachine_memory_Agent
 * continuous valued agent
 * Holds all agent variables and is aligned to help with coalesced reads on the GPU
 */
struct __align__(16) xmachine_memory_Agent
{
    double x;    /**< X-machine memory variable x of type double.*/
    double y;    /**< X-machine memory variable y of type double.*/
    double z;    /**< X-machine memory variable z of type double.*/
    double target_pos_x;    /**< X-machine memory variable target_pos_x of type double.*/
    double target_pos_y;    /**< X-machine memory variable target_pos_y of type double.*/
    int agent_id;    /**< X-machine memory variable agent_id of type int.*/
    int state;    /**< X-machine memory variable state of type int.*/
    int sugar_level;    /**< X-machine memory variable sugar_level of type int.*/
    int metabolism;    /**< X-machine memory variable metabolism of type int.*/
    int env_sugar_level;    /**< X-machine memory variable env_sugar_level of type int.*/
    int max_env_sugar_level;    /**< X-machine memory variable max_env_sugar_level of type int.*/
};



/* Message structures */

/** struct xmachine_message_movement_request_message
 * Spatial Partitioning
 * Holds all message variables and is aligned to help with coalesced reads on the GPU
 */
struct __align__(16) xmachine_message_movement_request_message
{	
    /* Spatial Partitioning Variables */
    glm::ivec3 _relative_cell;    /**< Relative cell position from agent grid cell position range -1 to 1 */
    int _cell_index_max;    /**< Max boundary value of current cell */
    glm::ivec3 _agent_grid_cell;  /**< Agents partition cell position */
    int _cell_index;        /**< Index of position in current cell */  
      
    double x;        /**< Message variable x of type double.*/  
    double y;        /**< Message variable y of type double.*/  
    double z;        /**< Message variable z of type double.*/  
    int state;        /**< Message variable state of type int.*/  
    int env_sugar_level;        /**< Message variable env_sugar_level of type int.*/
};

/** struct xmachine_message_movement_response_message
 * Spatial Partitioning
 * Holds all message variables and is aligned to help with coalesced reads on the GPU
 */
struct __align__(16) xmachine_message_movement_response_message
{	
    /* Spatial Partitioning Variables */
    glm::ivec3 _relative_cell;    /**< Relative cell position from agent grid cell position range -1 to 1 */
    int _cell_index_max;    /**< Max boundary value of current cell */
    glm::ivec3 _agent_grid_cell;  /**< Agents partition cell position */
    int _cell_index;        /**< Index of position in current cell */  
      
    double x;        /**< Message variable x of type double.*/  
    double y;        /**< Message variable y of type double.*/  
    double z;        /**< Message variable z of type double.*/  
    double target_pos_x;        /**< Message variable target_pos_x of type double.*/  
    double target_pos_y;        /**< Message variable target_pos_y of type double.*/  
    int agent_id;        /**< Message variable agent_id of type int.*/  
    int state;        /**< Message variable state of type int.*/  
    int sugar_level;        /**< Message variable sugar_level of type int.*/  
    int metabolism;        /**< Message variable metabolism of type int.*/
};

/** struct xmachine_message_movement_transaction_message
 * Spatial Partitioning
 * Holds all message variables and is aligned to help with coalesced reads on the GPU
 */
struct __align__(16) xmachine_message_movement_transaction_message
{	
    /* Spatial Partitioning Variables */
    glm::ivec3 _relative_cell;    /**< Relative cell position from agent grid cell position range -1 to 1 */
    int _cell_index_max;    /**< Max boundary value of current cell */
    glm::ivec3 _agent_grid_cell;  /**< Agents partition cell position */
    int _cell_index;        /**< Index of position in current cell */  
      
    double x;        /**< Message variable x of type double.*/  
    double y;        /**< Message variable y of type double.*/  
    double z;        /**< Message variable z of type double.*/  
    int agent_id;        /**< Message variable agent_id of type int.*/  
    int state;        /**< Message variable state of type int.*/
};



/* Agent lists. Structure of Array (SoA) for memory coalescing on GPU */

/** struct xmachine_memory_Agent_list
 * continuous valued agent
 * Variables lists for all agent variables
 */
struct xmachine_memory_Agent_list
{	
    /* Temp variables for agents. Used for parallel operations such as prefix sum */
    int _position [xmachine_memory_Agent_MAX];    /**< Holds agents position in the 1D agent list */
    int _scan_input [xmachine_memory_Agent_MAX];  /**< Used during parallel prefix sum */
    
    double x [xmachine_memory_Agent_MAX];    /**< X-machine memory variable list x of type double.*/
    double y [xmachine_memory_Agent_MAX];    /**< X-machine memory variable list y of type double.*/
    double z [xmachine_memory_Agent_MAX];    /**< X-machine memory variable list z of type double.*/
    double target_pos_x [xmachine_memory_Agent_MAX];    /**< X-machine memory variable list target_pos_x of type double.*/
    double target_pos_y [xmachine_memory_Agent_MAX];    /**< X-machine memory variable list target_pos_y of type double.*/
    int agent_id [xmachine_memory_Agent_MAX];    /**< X-machine memory variable list agent_id of type int.*/
    int state [xmachine_memory_Agent_MAX];    /**< X-machine memory variable list state of type int.*/
    int sugar_level [xmachine_memory_Agent_MAX];    /**< X-machine memory variable list sugar_level of type int.*/
    int metabolism [xmachine_memory_Agent_MAX];    /**< X-machine memory variable list metabolism of type int.*/
    int env_sugar_level [xmachine_memory_Agent_MAX];    /**< X-machine memory variable list env_sugar_level of type int.*/
    int max_env_sugar_level [xmachine_memory_Agent_MAX];    /**< X-machine memory variable list max_env_sugar_level of type int.*/
};



/* Message lists. Structure of Array (SoA) for memory coalescing on GPU */

/** struct xmachine_message_movement_request_message_list
 * Spatial Partitioning
 * Structure of Array for memory coalescing 
 */
struct xmachine_message_movement_request_message_list
{
    /* Non discrete messages have temp variables used for reductions with optional message outputs */
    int _position [xmachine_message_movement_request_message_MAX];    /**< Holds agents position in the 1D agent list */
    int _scan_input [xmachine_message_movement_request_message_MAX];  /**< Used during parallel prefix sum */
    
    double x [xmachine_message_movement_request_message_MAX];    /**< Message memory variable list x of type double.*/
    double y [xmachine_message_movement_request_message_MAX];    /**< Message memory variable list y of type double.*/
    double z [xmachine_message_movement_request_message_MAX];    /**< Message memory variable list z of type double.*/
    int state [xmachine_message_movement_request_message_MAX];    /**< Message memory variable list state of type int.*/
    int env_sugar_level [xmachine_message_movement_request_message_MAX];    /**< Message memory variable list env_sugar_level of type int.*/
    
};

/** struct xmachine_message_movement_response_message_list
 * Spatial Partitioning
 * Structure of Array for memory coalescing 
 */
struct xmachine_message_movement_response_message_list
{
    /* Non discrete messages have temp variables used for reductions with optional message outputs */
    int _position [xmachine_message_movement_response_message_MAX];    /**< Holds agents position in the 1D agent list */
    int _scan_input [xmachine_message_movement_response_message_MAX];  /**< Used during parallel prefix sum */
    
    double x [xmachine_message_movement_response_message_MAX];    /**< Message memory variable list x of type double.*/
    double y [xmachine_message_movement_response_message_MAX];    /**< Message memory variable list y of type double.*/
    double z [xmachine_message_movement_response_message_MAX];    /**< Message memory variable list z of type double.*/
    double target_pos_x [xmachine_message_movement_response_message_MAX];    /**< Message memory variable list target_pos_x of type double.*/
    double target_pos_y [xmachine_message_movement_response_message_MAX];    /**< Message memory variable list target_pos_y of type double.*/
    int agent_id [xmachine_message_movement_response_message_MAX];    /**< Message memory variable list agent_id of type int.*/
    int state [xmachine_message_movement_response_message_MAX];    /**< Message memory variable list state of type int.*/
    int sugar_level [xmachine_message_movement_response_message_MAX];    /**< Message memory variable list sugar_level of type int.*/
    int metabolism [xmachine_message_movement_response_message_MAX];    /**< Message memory variable list metabolism of type int.*/
    
};

/** struct xmachine_message_movement_transaction_message_list
 * Spatial Partitioning
 * Structure of Array for memory coalescing 
 */
struct xmachine_message_movement_transaction_message_list
{
    /* Non discrete messages have temp variables used for reductions with optional message outputs */
    int _position [xmachine_message_movement_transaction_message_MAX];    /**< Holds agents position in the 1D agent list */
    int _scan_input [xmachine_message_movement_transaction_message_MAX];  /**< Used during parallel prefix sum */
    
    double x [xmachine_message_movement_transaction_message_MAX];    /**< Message memory variable list x of type double.*/
    double y [xmachine_message_movement_transaction_message_MAX];    /**< Message memory variable list y of type double.*/
    double z [xmachine_message_movement_transaction_message_MAX];    /**< Message memory variable list z of type double.*/
    int agent_id [xmachine_message_movement_transaction_message_MAX];    /**< Message memory variable list agent_id of type int.*/
    int state [xmachine_message_movement_transaction_message_MAX];    /**< Message memory variable list state of type int.*/
    
};



/* Spatially Partitioned Message boundary Matrices */

/** struct xmachine_message_movement_request_message_PBM
 * Partition Boundary Matrix (PBM) for xmachine_message_movement_request_message 
 */
struct xmachine_message_movement_request_message_PBM
{
	int start[xmachine_message_movement_request_message_grid_size];
	int end_or_count[xmachine_message_movement_request_message_grid_size];
};

/** struct xmachine_message_movement_response_message_PBM
 * Partition Boundary Matrix (PBM) for xmachine_message_movement_response_message 
 */
struct xmachine_message_movement_response_message_PBM
{
	int start[xmachine_message_movement_response_message_grid_size];
	int end_or_count[xmachine_message_movement_response_message_grid_size];
};

/** struct xmachine_message_movement_transaction_message_PBM
 * Partition Boundary Matrix (PBM) for xmachine_message_movement_transaction_message 
 */
struct xmachine_message_movement_transaction_message_PBM
{
	int start[xmachine_message_movement_transaction_message_grid_size];
	int end_or_count[xmachine_message_movement_transaction_message_grid_size];
};



/* Graph structures */


/* Graph Edge Partitioned message boundary structures */


/* Graph utility functions, usable in agent functions and implemented in FLAMEGPU_Kernels */


  /* Random */
  /** struct RNG_rand48
  *	structure used to hold list seeds
  */
  struct RNG_rand48
  {
  glm::uvec2 A, C;
  glm::uvec2 seeds[buffer_size_MAX];
  };


/** getOutputDir
* Gets the output directory of the simulation. This is the same as the 0.xml input directory.
* @return a const char pointer to string denoting the output directory
*/
const char* getOutputDir();

  /* Random Functions (usable in agent functions) implemented in FLAMEGPU_Kernels */

  /**
  * Templated random function using a DISCRETE_2D template calculates the agent index using a 2D block
  * which requires extra processing but will work for CONTINUOUS agents. Using a CONTINUOUS template will
  * not work for DISCRETE_2D agent.
  * @param	rand48	an RNG_rand48 struct which holds the seeds sued to generate a random number on the GPU
  * @return			returns a random float value
  */
  template <int AGENT_TYPE> __FLAME_GPU_FUNC__ float rnd(RNG_rand48* rand48);
/**
 * Non templated random function calls the templated version with DISCRETE_2D which will work in either case
 * @param	rand48	an RNG_rand48 struct which holds the seeds sued to generate a random number on the GPU
 * @return			returns a random float value
 */
__FLAME_GPU_FUNC__ float rnd(RNG_rand48* rand48);

/* Agent function prototypes */

/**
 * metabolise_and_growback FLAMEGPU Agent Function
 * @param agent Pointer to an agent structure of type xmachine_memory_Agent. This represents a single agent instance and can be modified directly.
 
 */
__FLAME_GPU_FUNC__ int metabolise_and_growback(xmachine_memory_Agent* agent);

/**
 * movement_request_gen FLAMEGPU Agent Function
 * @param agent Pointer to an agent structure of type xmachine_memory_Agent. This represents a single agent instance and can be modified directly.
 * @param movement_request_message_messages Pointer to output message list of type xmachine_message_movement_request_message_list. Must be passed as an argument to the add_movement_request_message_message function ??.
 */
__FLAME_GPU_FUNC__ int movement_request_gen(xmachine_memory_Agent* agent, xmachine_message_movement_request_message_list* movement_request_message_messages);

/**
 * movement_request FLAMEGPU Agent Function
 * @param agent Pointer to an agent structure of type xmachine_memory_Agent. This represents a single agent instance and can be modified directly.
 * @param movement_request_message_messages  movement_request_message_messages Pointer to input message list of type xmachine_message__list. Must be passed as an argument to the get_first_movement_request_message_message and get_next_movement_request_message_message functions.* @param partition_matrix Pointer to the partition matrix of type xmachine_message_movement_request_message_PBM. Used within the get_first__message and get_next__message functions for spatially partitioned message access.
 */
__FLAME_GPU_FUNC__ int movement_request(xmachine_memory_Agent* agent, xmachine_message_movement_request_message_list* movement_request_message_messages, xmachine_message_movement_request_message_PBM* partition_matrix);

/**
 * movement_response_gen FLAMEGPU Agent Function
 * @param agent Pointer to an agent structure of type xmachine_memory_Agent. This represents a single agent instance and can be modified directly.
 * @param movement_response_message_messages Pointer to output message list of type xmachine_message_movement_response_message_list. Must be passed as an argument to the add_movement_response_message_message function ??.
 */
__FLAME_GPU_FUNC__ int movement_response_gen(xmachine_memory_Agent* agent, xmachine_message_movement_response_message_list* movement_response_message_messages);

/**
 * movement_response FLAMEGPU Agent Function
 * @param agent Pointer to an agent structure of type xmachine_memory_Agent. This represents a single agent instance and can be modified directly.
 * @param movement_response_message_messages  movement_response_message_messages Pointer to input message list of type xmachine_message__list. Must be passed as an argument to the get_first_movement_response_message_message and get_next_movement_response_message_message functions.* @param partition_matrix Pointer to the partition matrix of type xmachine_message_movement_response_message_PBM. Used within the get_first__message and get_next__message functions for spatially partitioned message access.
 */
__FLAME_GPU_FUNC__ int movement_response(xmachine_memory_Agent* agent, xmachine_message_movement_response_message_list* movement_response_message_messages, xmachine_message_movement_response_message_PBM* partition_matrix);

/**
 * movement_transaction_gen FLAMEGPU Agent Function
 * @param agent Pointer to an agent structure of type xmachine_memory_Agent. This represents a single agent instance and can be modified directly.
 * @param movement_transaction_message_messages Pointer to output message list of type xmachine_message_movement_transaction_message_list. Must be passed as an argument to the add_movement_transaction_message_message function ??.
 */
__FLAME_GPU_FUNC__ int movement_transaction_gen(xmachine_memory_Agent* agent, xmachine_message_movement_transaction_message_list* movement_transaction_message_messages);

/**
 * movement_transaction FLAMEGPU Agent Function
 * @param agent Pointer to an agent structure of type xmachine_memory_Agent. This represents a single agent instance and can be modified directly.
 * @param movement_transaction_message_messages  movement_transaction_message_messages Pointer to input message list of type xmachine_message__list. Must be passed as an argument to the get_first_movement_transaction_message_message and get_next_movement_transaction_message_message functions.* @param partition_matrix Pointer to the partition matrix of type xmachine_message_movement_transaction_message_PBM. Used within the get_first__message and get_next__message functions for spatially partitioned message access.
 */
__FLAME_GPU_FUNC__ int movement_transaction(xmachine_memory_Agent* agent, xmachine_message_movement_transaction_message_list* movement_transaction_message_messages, xmachine_message_movement_transaction_message_PBM* partition_matrix);

  
/* Message Function Prototypes for Spatially Partitioned movement_request_message message implemented in FLAMEGPU_Kernels */

/** add_movement_request_message_message
 * Function for all types of message partitioning
 * Adds a new movement_request_message agent to the xmachine_memory_movement_request_message_list list using a linear mapping
 * @param agents	xmachine_memory_movement_request_message_list agent list
 * @param x	message variable of type double
 * @param y	message variable of type double
 * @param z	message variable of type double
 * @param state	message variable of type int
 * @param env_sugar_level	message variable of type int
 */
 
 __FLAME_GPU_FUNC__ void add_movement_request_message_message(xmachine_message_movement_request_message_list* movement_request_message_messages, double x, double y, double z, int state, int env_sugar_level);
 
/** get_first_movement_request_message_message
 * Get first message function for spatially partitioned messages
 * @param movement_request_message_messages message list
 * @param partition_matrix the boundary partition matrix for the spatially partitioned message list
 * @param agentx x position of the agent
 * @param agenty y position of the agent
 * @param agentz z position of the agent
 * @return        returns the first message from the message list (offset depending on agent block)
 */
__FLAME_GPU_FUNC__ xmachine_message_movement_request_message * get_first_movement_request_message_message(xmachine_message_movement_request_message_list* movement_request_message_messages, xmachine_message_movement_request_message_PBM* partition_matrix, float x, float y, float z);

/** get_next_movement_request_message_message
 * Get first message function for discrete partitioned messages. Template function will call either shared memory or texture cache implementation depending on AGENT_TYPE
 * @param current the current message struct
 * @param movement_request_message_messages message list
 * @param partition_matrix the boundary partition matrix for the spatially partitioned message list
 * @return        returns the first message from the message list (offset depending on agent block)
 */
__FLAME_GPU_FUNC__ xmachine_message_movement_request_message * get_next_movement_request_message_message(xmachine_message_movement_request_message* current, xmachine_message_movement_request_message_list* movement_request_message_messages, xmachine_message_movement_request_message_PBM* partition_matrix);

  
/* Message Function Prototypes for Spatially Partitioned movement_response_message message implemented in FLAMEGPU_Kernels */

/** add_movement_response_message_message
 * Function for all types of message partitioning
 * Adds a new movement_response_message agent to the xmachine_memory_movement_response_message_list list using a linear mapping
 * @param agents	xmachine_memory_movement_response_message_list agent list
 * @param x	message variable of type double
 * @param y	message variable of type double
 * @param z	message variable of type double
 * @param target_pos_x	message variable of type double
 * @param target_pos_y	message variable of type double
 * @param agent_id	message variable of type int
 * @param state	message variable of type int
 * @param sugar_level	message variable of type int
 * @param metabolism	message variable of type int
 */
 
 __FLAME_GPU_FUNC__ void add_movement_response_message_message(xmachine_message_movement_response_message_list* movement_response_message_messages, double x, double y, double z, double target_pos_x, double target_pos_y, int agent_id, int state, int sugar_level, int metabolism);
 
/** get_first_movement_response_message_message
 * Get first message function for spatially partitioned messages
 * @param movement_response_message_messages message list
 * @param partition_matrix the boundary partition matrix for the spatially partitioned message list
 * @param agentx x position of the agent
 * @param agenty y position of the agent
 * @param agentz z position of the agent
 * @return        returns the first message from the message list (offset depending on agent block)
 */
__FLAME_GPU_FUNC__ xmachine_message_movement_response_message * get_first_movement_response_message_message(xmachine_message_movement_response_message_list* movement_response_message_messages, xmachine_message_movement_response_message_PBM* partition_matrix, float x, float y, float z);

/** get_next_movement_response_message_message
 * Get first message function for discrete partitioned messages. Template function will call either shared memory or texture cache implementation depending on AGENT_TYPE
 * @param current the current message struct
 * @param movement_response_message_messages message list
 * @param partition_matrix the boundary partition matrix for the spatially partitioned message list
 * @return        returns the first message from the message list (offset depending on agent block)
 */
__FLAME_GPU_FUNC__ xmachine_message_movement_response_message * get_next_movement_response_message_message(xmachine_message_movement_response_message* current, xmachine_message_movement_response_message_list* movement_response_message_messages, xmachine_message_movement_response_message_PBM* partition_matrix);

  
/* Message Function Prototypes for Spatially Partitioned movement_transaction_message message implemented in FLAMEGPU_Kernels */

/** add_movement_transaction_message_message
 * Function for all types of message partitioning
 * Adds a new movement_transaction_message agent to the xmachine_memory_movement_transaction_message_list list using a linear mapping
 * @param agents	xmachine_memory_movement_transaction_message_list agent list
 * @param x	message variable of type double
 * @param y	message variable of type double
 * @param z	message variable of type double
 * @param agent_id	message variable of type int
 * @param state	message variable of type int
 */
 
 __FLAME_GPU_FUNC__ void add_movement_transaction_message_message(xmachine_message_movement_transaction_message_list* movement_transaction_message_messages, double x, double y, double z, int agent_id, int state);
 
/** get_first_movement_transaction_message_message
 * Get first message function for spatially partitioned messages
 * @param movement_transaction_message_messages message list
 * @param partition_matrix the boundary partition matrix for the spatially partitioned message list
 * @param agentx x position of the agent
 * @param agenty y position of the agent
 * @param agentz z position of the agent
 * @return        returns the first message from the message list (offset depending on agent block)
 */
__FLAME_GPU_FUNC__ xmachine_message_movement_transaction_message * get_first_movement_transaction_message_message(xmachine_message_movement_transaction_message_list* movement_transaction_message_messages, xmachine_message_movement_transaction_message_PBM* partition_matrix, float x, float y, float z);

/** get_next_movement_transaction_message_message
 * Get first message function for discrete partitioned messages. Template function will call either shared memory or texture cache implementation depending on AGENT_TYPE
 * @param current the current message struct
 * @param movement_transaction_message_messages message list
 * @param partition_matrix the boundary partition matrix for the spatially partitioned message list
 * @return        returns the first message from the message list (offset depending on agent block)
 */
__FLAME_GPU_FUNC__ xmachine_message_movement_transaction_message * get_next_movement_transaction_message_message(xmachine_message_movement_transaction_message* current, xmachine_message_movement_transaction_message_list* movement_transaction_message_messages, xmachine_message_movement_transaction_message_PBM* partition_matrix);

  
/* Agent Function Prototypes implemented in FLAMEGPU_Kernels */

/** add_Agent_agent
 * Adds a new continuous valued Agent agent to the xmachine_memory_Agent_list list using a linear mapping. Note that any agent variables with an arrayLength are ommited and not support during the creation of new agents on the fly.
 * @param agents xmachine_memory_Agent_list agent list
 * @param x	agent agent variable of type double
 * @param y	agent agent variable of type double
 * @param z	agent agent variable of type double
 * @param target_pos_x	agent agent variable of type double
 * @param target_pos_y	agent agent variable of type double
 * @param agent_id	agent agent variable of type int
 * @param state	agent agent variable of type int
 * @param sugar_level	agent agent variable of type int
 * @param metabolism	agent agent variable of type int
 * @param env_sugar_level	agent agent variable of type int
 * @param max_env_sugar_level	agent agent variable of type int
 */
__FLAME_GPU_FUNC__ void add_Agent_agent(xmachine_memory_Agent_list* agents, double x, double y, double z, double target_pos_x, double target_pos_y, int agent_id, int state, int sugar_level, int metabolism, int env_sugar_level, int max_env_sugar_level);


/* Agent ID Generation functions implemented in simulation.cu and FLAMEGPU_kernals.cu*/


/* Graph loading function prototypes implemented in io.cu */


  
/* Simulation function prototypes implemented in simulation.cu */
/** getIterationNumber
 *  Get the iteration number (host)
 */
extern unsigned int getIterationNumber();

/** initialise
 * Initialise the simulation. Allocated host and device memory. Reads the initial agent configuration from XML.
 * @param input        XML file path for agent initial configuration
 */
extern void initialise(char * input);

/** cleanup
 * Function cleans up any memory allocations on the host and device
 */
extern void cleanup();

/** singleIteration
 *	Performs a single iteration of the simulation. I.e. performs each agent function on each function layer in the correct order.
 */
extern void singleIteration();

/** saveIterationData
 * Reads the current agent data fromt he device and saves it to XML
 * @param	outputpath	file path to XML file used for output of agent data
 * @param	iteration_number
 * @param h_Agents Pointer to agent list on the host
 * @param d_Agents Pointer to agent list on the GPU device
 * @param h_xmachine_memory_Agent_count Pointer to agent counter
 */
extern void saveIterationData(char* outputpath, int iteration_number, xmachine_memory_Agent_list* h_Agents_Agent_default, xmachine_memory_Agent_list* d_Agents_Agent_default, int h_xmachine_memory_Agent_Agent_default_count);


/** readInitialStates
 * Reads the current agent data from the device and saves it to XML
 * @param	inputpath	file path to XML file used for input of agent data
 * @param h_Agents Pointer to agent list on the host
 * @param h_xmachine_memory_Agent_count Pointer to agent counter
 */
extern void readInitialStates(char* inputpath, xmachine_memory_Agent_list* h_Agents, int* h_xmachine_memory_Agent_count);

/** set_exit_early
 * exits the simulation on the step this is called
 */
extern void set_exit_early();

/** get_exit_early
 * gets whether the simulation is ending this simulation step
 */
extern bool get_exit_early();




/* Return functions used by external code to get agent data from device */

    
/** get_agent_Agent_MAX_count
 * Gets the max agent count for the Agent agent type 
 * @return		the maximum Agent agent count
 */
extern int get_agent_Agent_MAX_count();



/** get_agent_Agent_Agent_default_count
 * Gets the agent count for the Agent agent type in state Agent_default
 * @return		the current Agent agent count in state Agent_default
 */
extern int get_agent_Agent_Agent_default_count();

/** reset_Agent_default_count
 * Resets the agent count of the Agent in state Agent_default to 0. This is useful for interacting with some visualisations.
 */
extern void reset_Agent_Agent_default_count();

/** get_device_Agent_Agent_default_agents
 * Gets a pointer to xmachine_memory_Agent_list on the GPU device
 * @return		a xmachine_memory_Agent_list on the GPU device
 */
extern xmachine_memory_Agent_list* get_device_Agent_Agent_default_agents();

/** get_host_Agent_Agent_default_agents
 * Gets a pointer to xmachine_memory_Agent_list on the CPU host
 * @return		a xmachine_memory_Agent_list on the CPU host
 */
extern xmachine_memory_Agent_list* get_host_Agent_Agent_default_agents();


/** sort_Agents_Agent_default
 * Sorts an agent state list by providing a CUDA kernal to generate key value pairs
 * @param		a pointer CUDA kernal function to generate key value pairs
 */
void sort_Agents_Agent_default(void (*generate_key_value_pairs)(unsigned int* keys, unsigned int* values, xmachine_memory_Agent_list* agents));



/* Host based access of agent variables*/

/** double get_Agent_Agent_default_variable_x(unsigned int index)
 * Gets the value of the x variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable x
 */
__host__ double get_Agent_Agent_default_variable_x(unsigned int index);

/** double get_Agent_Agent_default_variable_y(unsigned int index)
 * Gets the value of the y variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable y
 */
__host__ double get_Agent_Agent_default_variable_y(unsigned int index);

/** double get_Agent_Agent_default_variable_z(unsigned int index)
 * Gets the value of the z variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable z
 */
__host__ double get_Agent_Agent_default_variable_z(unsigned int index);

/** double get_Agent_Agent_default_variable_target_pos_x(unsigned int index)
 * Gets the value of the target_pos_x variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable target_pos_x
 */
__host__ double get_Agent_Agent_default_variable_target_pos_x(unsigned int index);

/** double get_Agent_Agent_default_variable_target_pos_y(unsigned int index)
 * Gets the value of the target_pos_y variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable target_pos_y
 */
__host__ double get_Agent_Agent_default_variable_target_pos_y(unsigned int index);

/** int get_Agent_Agent_default_variable_agent_id(unsigned int index)
 * Gets the value of the agent_id variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable agent_id
 */
__host__ int get_Agent_Agent_default_variable_agent_id(unsigned int index);

/** int get_Agent_Agent_default_variable_state(unsigned int index)
 * Gets the value of the state variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable state
 */
__host__ int get_Agent_Agent_default_variable_state(unsigned int index);

/** int get_Agent_Agent_default_variable_sugar_level(unsigned int index)
 * Gets the value of the sugar_level variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable sugar_level
 */
__host__ int get_Agent_Agent_default_variable_sugar_level(unsigned int index);

/** int get_Agent_Agent_default_variable_metabolism(unsigned int index)
 * Gets the value of the metabolism variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable metabolism
 */
__host__ int get_Agent_Agent_default_variable_metabolism(unsigned int index);

/** int get_Agent_Agent_default_variable_env_sugar_level(unsigned int index)
 * Gets the value of the env_sugar_level variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable env_sugar_level
 */
__host__ int get_Agent_Agent_default_variable_env_sugar_level(unsigned int index);

/** int get_Agent_Agent_default_variable_max_env_sugar_level(unsigned int index)
 * Gets the value of the max_env_sugar_level variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable max_env_sugar_level
 */
__host__ int get_Agent_Agent_default_variable_max_env_sugar_level(unsigned int index);




/* Host based agent creation functions */

/** h_allocate_agent_Agent
 * Utility function to allocate and initialise an agent struct on the host.
 * @return address of a host-allocated Agent struct.
 */
xmachine_memory_Agent* h_allocate_agent_Agent();
/** h_free_agent_Agent
 * Utility function to free a host-allocated agent struct.
 * This also deallocates any agent variable arrays, and sets the pointer to null
 * @param agent address of pointer to the host allocated struct
 */
void h_free_agent_Agent(xmachine_memory_Agent** agent);
/** h_allocate_agent_Agent_array
 * Utility function to allocate an array of structs for  Agent agents.
 * @param count the number of structs to allocate memory for.
 * @return pointer to the allocated array of structs
 */
xmachine_memory_Agent** h_allocate_agent_Agent_array(unsigned int count);
/** h_free_agent_Agent_array(
 * Utility function to deallocate a host array of agent structs, including agent variables, and set pointer values to NULL.
 * @param agents the address of the pointer to the host array of structs.
 * @param count the number of elements in the AoS, to deallocate individual elements.
 */
void h_free_agent_Agent_array(xmachine_memory_Agent*** agents, unsigned int count);


/** h_add_agent_Agent_Agent_default
 * Host function to add a single agent of type Agent to the Agent_default state on the device.
 * This invokes many cudaMempcy, and an append kernel launch. 
 * If multiple agents are to be created in a single iteration, consider h_add_agent_Agent_Agent_default instead.
 * @param agent pointer to agent struct on the host. Agent member arrays are supported.
 */
void h_add_agent_Agent_Agent_default(xmachine_memory_Agent* agent);

/** h_add_agents_Agent_Agent_default(
 * Host function to add multiple agents of type Agent to the Agent_default state on the device if possible.
 * This includes the transparent conversion from AoS to SoA, many calls to cudaMemcpy and an append kernel.
 * @param agents pointer to host struct of arrays of Agent agents
 * @param count the number of agents to copy from the host to the device.
 */
void h_add_agents_Agent_Agent_default(xmachine_memory_Agent** agents, unsigned int count);

  
  
/* Analytics functions for each varible in each state*/
typedef enum {
  REDUCTION_MAX,
  REDUCTION_MIN,
  REDUCTION_SUM
}reduction_operator;


/** double reduce_Agent_Agent_default_x_variable();
 * Reduction functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the reduced variable value of the specified agent name and state
 */
double reduce_Agent_Agent_default_x_variable();



/** double min_Agent_Agent_default_x_variable();
 * Min functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
double min_Agent_Agent_default_x_variable();
/** double max_Agent_Agent_default_x_variable();
 * Max functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
double max_Agent_Agent_default_x_variable();

/** double reduce_Agent_Agent_default_y_variable();
 * Reduction functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the reduced variable value of the specified agent name and state
 */
double reduce_Agent_Agent_default_y_variable();



/** double min_Agent_Agent_default_y_variable();
 * Min functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
double min_Agent_Agent_default_y_variable();
/** double max_Agent_Agent_default_y_variable();
 * Max functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
double max_Agent_Agent_default_y_variable();

/** double reduce_Agent_Agent_default_z_variable();
 * Reduction functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the reduced variable value of the specified agent name and state
 */
double reduce_Agent_Agent_default_z_variable();



/** double min_Agent_Agent_default_z_variable();
 * Min functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
double min_Agent_Agent_default_z_variable();
/** double max_Agent_Agent_default_z_variable();
 * Max functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
double max_Agent_Agent_default_z_variable();

/** double reduce_Agent_Agent_default_target_pos_x_variable();
 * Reduction functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the reduced variable value of the specified agent name and state
 */
double reduce_Agent_Agent_default_target_pos_x_variable();



/** double min_Agent_Agent_default_target_pos_x_variable();
 * Min functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
double min_Agent_Agent_default_target_pos_x_variable();
/** double max_Agent_Agent_default_target_pos_x_variable();
 * Max functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
double max_Agent_Agent_default_target_pos_x_variable();

/** double reduce_Agent_Agent_default_target_pos_y_variable();
 * Reduction functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the reduced variable value of the specified agent name and state
 */
double reduce_Agent_Agent_default_target_pos_y_variable();



/** double min_Agent_Agent_default_target_pos_y_variable();
 * Min functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
double min_Agent_Agent_default_target_pos_y_variable();
/** double max_Agent_Agent_default_target_pos_y_variable();
 * Max functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
double max_Agent_Agent_default_target_pos_y_variable();

/** int reduce_Agent_Agent_default_agent_id_variable();
 * Reduction functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the reduced variable value of the specified agent name and state
 */
int reduce_Agent_Agent_default_agent_id_variable();



/** int count_Agent_Agent_default_agent_id_variable(int count_value){
 * Count can be used for integer only agent variables and allows unique values to be counted using a reduction. Useful for generating histograms.
 * @param count_value The unique value which should be counted
 * @return The number of unique values of the count_value found in the agent state variable list
 */
int count_Agent_Agent_default_agent_id_variable(int count_value);

/** int min_Agent_Agent_default_agent_id_variable();
 * Min functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
int min_Agent_Agent_default_agent_id_variable();
/** int max_Agent_Agent_default_agent_id_variable();
 * Max functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
int max_Agent_Agent_default_agent_id_variable();

/** int reduce_Agent_Agent_default_state_variable();
 * Reduction functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the reduced variable value of the specified agent name and state
 */
int reduce_Agent_Agent_default_state_variable();



/** int count_Agent_Agent_default_state_variable(int count_value){
 * Count can be used for integer only agent variables and allows unique values to be counted using a reduction. Useful for generating histograms.
 * @param count_value The unique value which should be counted
 * @return The number of unique values of the count_value found in the agent state variable list
 */
int count_Agent_Agent_default_state_variable(int count_value);

/** int min_Agent_Agent_default_state_variable();
 * Min functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
int min_Agent_Agent_default_state_variable();
/** int max_Agent_Agent_default_state_variable();
 * Max functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
int max_Agent_Agent_default_state_variable();

/** int reduce_Agent_Agent_default_sugar_level_variable();
 * Reduction functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the reduced variable value of the specified agent name and state
 */
int reduce_Agent_Agent_default_sugar_level_variable();



/** int count_Agent_Agent_default_sugar_level_variable(int count_value){
 * Count can be used for integer only agent variables and allows unique values to be counted using a reduction. Useful for generating histograms.
 * @param count_value The unique value which should be counted
 * @return The number of unique values of the count_value found in the agent state variable list
 */
int count_Agent_Agent_default_sugar_level_variable(int count_value);

/** int min_Agent_Agent_default_sugar_level_variable();
 * Min functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
int min_Agent_Agent_default_sugar_level_variable();
/** int max_Agent_Agent_default_sugar_level_variable();
 * Max functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
int max_Agent_Agent_default_sugar_level_variable();

/** int reduce_Agent_Agent_default_metabolism_variable();
 * Reduction functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the reduced variable value of the specified agent name and state
 */
int reduce_Agent_Agent_default_metabolism_variable();



/** int count_Agent_Agent_default_metabolism_variable(int count_value){
 * Count can be used for integer only agent variables and allows unique values to be counted using a reduction. Useful for generating histograms.
 * @param count_value The unique value which should be counted
 * @return The number of unique values of the count_value found in the agent state variable list
 */
int count_Agent_Agent_default_metabolism_variable(int count_value);

/** int min_Agent_Agent_default_metabolism_variable();
 * Min functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
int min_Agent_Agent_default_metabolism_variable();
/** int max_Agent_Agent_default_metabolism_variable();
 * Max functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
int max_Agent_Agent_default_metabolism_variable();

/** int reduce_Agent_Agent_default_env_sugar_level_variable();
 * Reduction functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the reduced variable value of the specified agent name and state
 */
int reduce_Agent_Agent_default_env_sugar_level_variable();



/** int count_Agent_Agent_default_env_sugar_level_variable(int count_value){
 * Count can be used for integer only agent variables and allows unique values to be counted using a reduction. Useful for generating histograms.
 * @param count_value The unique value which should be counted
 * @return The number of unique values of the count_value found in the agent state variable list
 */
int count_Agent_Agent_default_env_sugar_level_variable(int count_value);

/** int min_Agent_Agent_default_env_sugar_level_variable();
 * Min functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
int min_Agent_Agent_default_env_sugar_level_variable();
/** int max_Agent_Agent_default_env_sugar_level_variable();
 * Max functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
int max_Agent_Agent_default_env_sugar_level_variable();

/** int reduce_Agent_Agent_default_max_env_sugar_level_variable();
 * Reduction functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the reduced variable value of the specified agent name and state
 */
int reduce_Agent_Agent_default_max_env_sugar_level_variable();



/** int count_Agent_Agent_default_max_env_sugar_level_variable(int count_value){
 * Count can be used for integer only agent variables and allows unique values to be counted using a reduction. Useful for generating histograms.
 * @param count_value The unique value which should be counted
 * @return The number of unique values of the count_value found in the agent state variable list
 */
int count_Agent_Agent_default_max_env_sugar_level_variable(int count_value);

/** int min_Agent_Agent_default_max_env_sugar_level_variable();
 * Min functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
int min_Agent_Agent_default_max_env_sugar_level_variable();
/** int max_Agent_Agent_default_max_env_sugar_level_variable();
 * Max functions can be used by visualisations, step and exit functions to gather data for plotting or updating global variables
 * @return the minimum variable value of the specified agent name and state
 */
int max_Agent_Agent_default_max_env_sugar_level_variable();


  
/* global constant variables */


/** getMaximumBound
 * Returns the maximum agent positions determined from the initial loading of agents
 * @return 	a three component float indicating the maximum x, y and z positions of all agents
 */
glm::vec3 getMaximumBounds();

/** getMinimumBounds
 * Returns the minimum agent positions determined from the initial loading of agents
 * @return 	a three component float indicating the minimum x, y and z positions of all agents
 */
glm::vec3 getMinimumBounds();
    
    
#ifdef VISUALISATION
/** initVisualisation
 * Prototype for method which initialises the visualisation. Must be implemented in separate file
 * @param argc	the argument count from the main function used with GLUT
 * @param argv	the argument values from the main function used with GLUT
 */
extern void initVisualisation();

extern void runVisualisation();


#endif

#if defined(PROFILE)
#include "nvToolsExt.h"

#define PROFILE_WHITE   0x00eeeeee
#define PROFILE_GREEN   0x0000ff00
#define PROFILE_BLUE    0x000000ff
#define PROFILE_YELLOW  0x00ffff00
#define PROFILE_MAGENTA 0x00ff00ff
#define PROFILE_CYAN    0x0000ffff
#define PROFILE_RED     0x00ff0000
#define PROFILE_GREY    0x00999999
#define PROFILE_LILAC   0xC8A2C8

const uint32_t profile_colors[] = {
  PROFILE_WHITE,
  PROFILE_GREEN,
  PROFILE_BLUE,
  PROFILE_YELLOW,
  PROFILE_MAGENTA,
  PROFILE_CYAN,
  PROFILE_RED,
  PROFILE_GREY,
  PROFILE_LILAC
};
const int num_profile_colors = sizeof(profile_colors) / sizeof(uint32_t);

// Externed value containing colour information.
extern unsigned int g_profile_colour_id;

#define PROFILE_PUSH_RANGE(name) { \
    unsigned int color_id = g_profile_colour_id % num_profile_colors;\
    nvtxEventAttributes_t eventAttrib = {0}; \
    eventAttrib.version = NVTX_VERSION; \
    eventAttrib.size = NVTX_EVENT_ATTRIB_STRUCT_SIZE; \
    eventAttrib.colorType = NVTX_COLOR_ARGB; \
    eventAttrib.color = profile_colors[color_id]; \
    eventAttrib.messageType = NVTX_MESSAGE_TYPE_ASCII; \
    eventAttrib.message.ascii = name; \
    nvtxRangePushEx(&eventAttrib); \
    g_profile_colour_id++; \
}
#define PROFILE_POP_RANGE() nvtxRangePop();

// Class for simple fire-and-forget profile ranges (ie. functions with multiple return conditions.)
class ProfileScopedRange {
public:
    ProfileScopedRange(const char * name){
      PROFILE_PUSH_RANGE(name);
    }
    ~ProfileScopedRange(){
      PROFILE_POP_RANGE();
    }
};
#define PROFILE_SCOPED_RANGE(name) ProfileScopedRange uniq_name_using_macros(name);
#else
#define PROFILE_PUSH_RANGE(name)
#define PROFILE_POP_RANGE()
#define PROFILE_SCOPED_RANGE(name)
#endif


#endif //__HEADER

