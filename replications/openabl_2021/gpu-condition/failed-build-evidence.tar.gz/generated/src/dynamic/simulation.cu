
/*
 * FLAME GPU v 1.5.X for CUDA 9
 * Copyright University of Sheffield.
 * Original Author: Dr Paul Richmond (user contributions tracked on https://github.com/FLAMEGPU/FLAMEGPU)
 * Contact: p.richmond@sheffield.ac.uk (http://www.paulrichmond.staff.shef.ac.uk)
 *
 * University of Sheffield retain all intellectual property and
 * proprietary rights in and to this software and related documentation.
 * Any use, reproduction, disclosure, or distribution of this software
 * and related documentation without an express license agreement from
 * University of Sheffield is strictly prohibited.
 *
 * For terms of licence agreement please attached licence or view licence
 * on www.flamegpu.com website.
 *
 */


  //Disable internal thrust warnings about conversions
  #ifdef _MSC_VER
  #pragma warning(push)
  #pragma warning (disable : 4267)
  #pragma warning (disable : 4244)
  #endif
  #ifdef __GNUC__
  #pragma GCC diagnostic push
  #pragma GCC diagnostic ignored "-Wunused-parameter"
  #endif

  // includes
  #include <cuda_runtime.h>
#include <device_launch_parameters.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <cmath>
#include <thrust/device_ptr.h>
#include <thrust/scan.h>
#include <thrust/sort.h>
#include <thrust/extrema.h>
#include <thrust/system/cuda/execution_policy.h>
#include <cub/cub.cuh>

// include FLAME kernels
#include "FLAMEGPU_kernals.cu"


#ifdef _MSC_VER
#pragma warning(pop)
#endif
#ifdef __GNUC__
#pragma GCC diagnostic pop
#endif

/* Error check function for safe CUDA API calling */
#define gpuErrchk(ans) { gpuAssert((ans), __FILE__, __LINE__); }
inline void gpuAssert(cudaError_t code, const char *file, int line, bool abort=true)
{
   if (code != cudaSuccess) 
   {
      fprintf(stderr,"GPUassert: %s %s %d\n", cudaGetErrorString(code), file, line);
      if (abort) exit(code);
   }
}

/* Error check function for post CUDA Kernel calling */
#define gpuErrchkLaunch() { gpuLaunchAssert(__FILE__, __LINE__); }
inline void gpuLaunchAssert(const char *file, int line, bool abort=true)
{
	gpuAssert( cudaPeekAtLastError(), file, line );
#ifdef _DEBUG
	gpuAssert( cudaDeviceSynchronize(), file, line );
#endif
   
}

/* SM padding and offset variables */
int SM_START;
int PADDING;

unsigned int g_iterationNumber;

/* Agent Memory */

/* Agent Agent variables these lists are used in the agent function where as the other lists are used only outside the agent functions*/
xmachine_memory_Agent_list* d_Agents;      /**< Pointer to agent list (population) on the device*/
xmachine_memory_Agent_list* d_Agents_swap; /**< Pointer to agent list swap on the device (used when killing agents)*/
xmachine_memory_Agent_list* d_Agents_new;  /**< Pointer to new agent list on the device (used to hold new agents before they are appended to the population)*/
int h_xmachine_memory_Agent_count;   /**< Agent population size counter */ 
uint * d_xmachine_memory_Agent_keys;	  /**< Agent sort identifiers keys*/
uint * d_xmachine_memory_Agent_values;  /**< Agent sort identifiers value */

/* Agent state variables */
xmachine_memory_Agent_list* h_Agents_Agent_default;      /**< Pointer to agent list (population) on host*/
xmachine_memory_Agent_list* d_Agents_Agent_default;      /**< Pointer to agent list (population) on the device*/
int h_xmachine_memory_Agent_Agent_default_count;   /**< Agent population size counter */ 


/* Variables to track the state of host copies of state lists, for the purposes of host agent data access.
 * @future - if the host data is current it may be possible to avoid duplicating memcpy in xml output.
 */
unsigned int h_Agents_Agent_default_variable_x_data_iteration;
unsigned int h_Agents_Agent_default_variable_y_data_iteration;
unsigned int h_Agents_Agent_default_variable_z_data_iteration;
unsigned int h_Agents_Agent_default_variable_target_pos_x_data_iteration;
unsigned int h_Agents_Agent_default_variable_target_pos_y_data_iteration;
unsigned int h_Agents_Agent_default_variable_agent_id_data_iteration;
unsigned int h_Agents_Agent_default_variable_state_data_iteration;
unsigned int h_Agents_Agent_default_variable_sugar_level_data_iteration;
unsigned int h_Agents_Agent_default_variable_metabolism_data_iteration;
unsigned int h_Agents_Agent_default_variable_env_sugar_level_data_iteration;
unsigned int h_Agents_Agent_default_variable_max_env_sugar_level_data_iteration;


/* Message Memory */

/* movement_request_message Message variables */
xmachine_message_movement_request_message_list* h_movement_request_messages;         /**< Pointer to message list on host*/
xmachine_message_movement_request_message_list* d_movement_request_messages;         /**< Pointer to message list on device*/
xmachine_message_movement_request_message_list* d_movement_request_messages_swap;    /**< Pointer to message swap list on device (used for holding optional messages)*/
/* Non partitioned and spatial partitioned message variables  */
int h_message_movement_request_message_count;         /**< message list counter*/
int h_message_movement_request_message_output_type;   /**< message output type (single or optional)*/
/* Spatial Partitioning Variables*/
#ifdef FAST_ATOMIC_SORTING
	uint * d_xmachine_message_movement_request_message_local_bin_index;	  /**< index offset within the assigned bin */
	uint * d_xmachine_message_movement_request_message_unsorted_index;		/**< unsorted index (hash) value for message */
    // Values for CUB exclusive scan of spatially partitioned variables
    void * d_temp_scan_storage_xmachine_message_movement_request_message;
    size_t temp_scan_bytes_xmachine_message_movement_request_message;
#else
	uint * d_xmachine_message_movement_request_message_keys;	  /**< message sort identifier keys*/
	uint * d_xmachine_message_movement_request_message_values;  /**< message sort identifier values */
  uint * d_xmachine_message_movement_request_message_keys_swap;	  /**< message sort identifier keys*/
  uint * d_xmachine_message_movement_request_message_values_swap;  /**< message sort identifier values */

  size_t CUB_temp_storage_bytes_movement_request_message = 0;
  void *d_CUB_temp_storage_movement_request_message = nullptr;
  const unsigned int binCountBits_movement_request_message = (unsigned int)ceil(log(xmachine_message_movement_request_message_grid_size) / log(2));
  #endif
  xmachine_message_movement_request_message_PBM * d_movement_request_message_partition_matrix;  /**< Pointer to PCB matrix */
glm::vec3 h_message_movement_request_message_min_bounds;           /**< min bounds (x,y,z) of partitioning environment */
glm::vec3 h_message_movement_request_message_max_bounds;           /**< max bounds (x,y,z) of partitioning environment */
glm::ivec3 h_message_movement_request_message_partitionDim;           /**< partition dimensions (x,y,z) of partitioning environment */
float h_message_movement_request_message_radius;                 /**< partition radius (used to determin the size of the partitions) */
/* Texture offset values for host */
int h_tex_xmachine_message_movement_request_message_x_offset;
int h_tex_xmachine_message_movement_request_message_y_offset;
int h_tex_xmachine_message_movement_request_message_z_offset;
int h_tex_xmachine_message_movement_request_message_state_offset;
int h_tex_xmachine_message_movement_request_message_env_sugar_level_offset;
int h_tex_xmachine_message_movement_request_message_pbm_start_offset;
int h_tex_xmachine_message_movement_request_message_pbm_end_or_count_offset;

/* movement_response_message Message variables */
xmachine_message_movement_response_message_list* h_movement_response_messages;         /**< Pointer to message list on host*/
xmachine_message_movement_response_message_list* d_movement_response_messages;         /**< Pointer to message list on device*/
xmachine_message_movement_response_message_list* d_movement_response_messages_swap;    /**< Pointer to message swap list on device (used for holding optional messages)*/
/* Non partitioned and spatial partitioned message variables  */
int h_message_movement_response_message_count;         /**< message list counter*/
int h_message_movement_response_message_output_type;   /**< message output type (single or optional)*/
/* Spatial Partitioning Variables*/
#ifdef FAST_ATOMIC_SORTING
	uint * d_xmachine_message_movement_response_message_local_bin_index;	  /**< index offset within the assigned bin */
	uint * d_xmachine_message_movement_response_message_unsorted_index;		/**< unsorted index (hash) value for message */
    // Values for CUB exclusive scan of spatially partitioned variables
    void * d_temp_scan_storage_xmachine_message_movement_response_message;
    size_t temp_scan_bytes_xmachine_message_movement_response_message;
#else
	uint * d_xmachine_message_movement_response_message_keys;	  /**< message sort identifier keys*/
	uint * d_xmachine_message_movement_response_message_values;  /**< message sort identifier values */
  uint * d_xmachine_message_movement_response_message_keys_swap;	  /**< message sort identifier keys*/
  uint * d_xmachine_message_movement_response_message_values_swap;  /**< message sort identifier values */

  size_t CUB_temp_storage_bytes_movement_response_message = 0;
  void *d_CUB_temp_storage_movement_response_message = nullptr;
  const unsigned int binCountBits_movement_response_message = (unsigned int)ceil(log(xmachine_message_movement_response_message_grid_size) / log(2));
  #endif
  xmachine_message_movement_response_message_PBM * d_movement_response_message_partition_matrix;  /**< Pointer to PCB matrix */
glm::vec3 h_message_movement_response_message_min_bounds;           /**< min bounds (x,y,z) of partitioning environment */
glm::vec3 h_message_movement_response_message_max_bounds;           /**< max bounds (x,y,z) of partitioning environment */
glm::ivec3 h_message_movement_response_message_partitionDim;           /**< partition dimensions (x,y,z) of partitioning environment */
float h_message_movement_response_message_radius;                 /**< partition radius (used to determin the size of the partitions) */
/* Texture offset values for host */
int h_tex_xmachine_message_movement_response_message_x_offset;
int h_tex_xmachine_message_movement_response_message_y_offset;
int h_tex_xmachine_message_movement_response_message_z_offset;
int h_tex_xmachine_message_movement_response_message_target_pos_x_offset;
int h_tex_xmachine_message_movement_response_message_target_pos_y_offset;
int h_tex_xmachine_message_movement_response_message_agent_id_offset;
int h_tex_xmachine_message_movement_response_message_state_offset;
int h_tex_xmachine_message_movement_response_message_sugar_level_offset;
int h_tex_xmachine_message_movement_response_message_metabolism_offset;
int h_tex_xmachine_message_movement_response_message_pbm_start_offset;
int h_tex_xmachine_message_movement_response_message_pbm_end_or_count_offset;

/* movement_transaction_message Message variables */
xmachine_message_movement_transaction_message_list* h_movement_transaction_messages;         /**< Pointer to message list on host*/
xmachine_message_movement_transaction_message_list* d_movement_transaction_messages;         /**< Pointer to message list on device*/
xmachine_message_movement_transaction_message_list* d_movement_transaction_messages_swap;    /**< Pointer to message swap list on device (used for holding optional messages)*/
/* Non partitioned and spatial partitioned message variables  */
int h_message_movement_transaction_message_count;         /**< message list counter*/
int h_message_movement_transaction_message_output_type;   /**< message output type (single or optional)*/
/* Spatial Partitioning Variables*/
#ifdef FAST_ATOMIC_SORTING
	uint * d_xmachine_message_movement_transaction_message_local_bin_index;	  /**< index offset within the assigned bin */
	uint * d_xmachine_message_movement_transaction_message_unsorted_index;		/**< unsorted index (hash) value for message */
    // Values for CUB exclusive scan of spatially partitioned variables
    void * d_temp_scan_storage_xmachine_message_movement_transaction_message;
    size_t temp_scan_bytes_xmachine_message_movement_transaction_message;
#else
	uint * d_xmachine_message_movement_transaction_message_keys;	  /**< message sort identifier keys*/
	uint * d_xmachine_message_movement_transaction_message_values;  /**< message sort identifier values */
  uint * d_xmachine_message_movement_transaction_message_keys_swap;	  /**< message sort identifier keys*/
  uint * d_xmachine_message_movement_transaction_message_values_swap;  /**< message sort identifier values */

  size_t CUB_temp_storage_bytes_movement_transaction_message = 0;
  void *d_CUB_temp_storage_movement_transaction_message = nullptr;
  const unsigned int binCountBits_movement_transaction_message = (unsigned int)ceil(log(xmachine_message_movement_transaction_message_grid_size) / log(2));
  #endif
  xmachine_message_movement_transaction_message_PBM * d_movement_transaction_message_partition_matrix;  /**< Pointer to PCB matrix */
glm::vec3 h_message_movement_transaction_message_min_bounds;           /**< min bounds (x,y,z) of partitioning environment */
glm::vec3 h_message_movement_transaction_message_max_bounds;           /**< max bounds (x,y,z) of partitioning environment */
glm::ivec3 h_message_movement_transaction_message_partitionDim;           /**< partition dimensions (x,y,z) of partitioning environment */
float h_message_movement_transaction_message_radius;                 /**< partition radius (used to determin the size of the partitions) */
/* Texture offset values for host */
int h_tex_xmachine_message_movement_transaction_message_x_offset;
int h_tex_xmachine_message_movement_transaction_message_y_offset;
int h_tex_xmachine_message_movement_transaction_message_z_offset;
int h_tex_xmachine_message_movement_transaction_message_agent_id_offset;
int h_tex_xmachine_message_movement_transaction_message_state_offset;
int h_tex_xmachine_message_movement_transaction_message_pbm_start_offset;
int h_tex_xmachine_message_movement_transaction_message_pbm_end_or_count_offset;

  
/* CUDA Streams for function layers */
cudaStream_t stream1;

/* Device memory and sizes for CUB values */

void * d_temp_scan_storage_Agent;
size_t temp_scan_storage_bytes_Agent;


/*Global condition counts*/

/* Agent ID Generation functions implemented in simulation.cu and FLAMEGPU_kernals.cu*/



/* RNG rand48 */
RNG_rand48* h_rand48;    /**< Pointer to RNG_rand48 seed list on host*/
RNG_rand48* d_rand48;    /**< Pointer to RNG_rand48 seed list on device*/

/* Early simulation exit*/
bool g_exit_early;

/* Cuda Event Timers for Instrumentation */
#if defined(INSTRUMENT_ITERATIONS) && INSTRUMENT_ITERATIONS
	cudaEvent_t instrument_iteration_start, instrument_iteration_stop;
	float instrument_iteration_milliseconds = 0.0f;
#endif
#if (defined(INSTRUMENT_AGENT_FUNCTIONS) && INSTRUMENT_AGENT_FUNCTIONS) || (defined(INSTRUMENT_INIT_FUNCTIONS) && INSTRUMENT_INIT_FUNCTIONS) || (defined(INSTRUMENT_STEP_FUNCTIONS) && INSTRUMENT_STEP_FUNCTIONS) || (defined(INSTRUMENT_EXIT_FUNCTIONS) && INSTRUMENT_EXIT_FUNCTIONS)
	cudaEvent_t instrument_start, instrument_stop;
	float instrument_milliseconds = 0.0f;
#endif

/* CUDA Parallel Primatives variables */
int scan_last_sum;           /**< Indicates if the position (in message list) of last message*/
int scan_last_included;      /**< Indicates if last sum value is included in the total sum count*/

/* Agent function prototypes */

/** Agent_metabolise_and_growback
 * Agent function prototype for metabolise_and_growback function of Agent agent
 */
void Agent_metabolise_and_growback(cudaStream_t &stream);

/** Agent_movement_request_gen
 * Agent function prototype for movement_request_gen function of Agent agent
 */
void Agent_movement_request_gen(cudaStream_t &stream);

/** Agent_movement_request
 * Agent function prototype for movement_request function of Agent agent
 */
void Agent_movement_request(cudaStream_t &stream);

/** Agent_movement_response_gen
 * Agent function prototype for movement_response_gen function of Agent agent
 */
void Agent_movement_response_gen(cudaStream_t &stream);

/** Agent_movement_response
 * Agent function prototype for movement_response function of Agent agent
 */
void Agent_movement_response(cudaStream_t &stream);

/** Agent_movement_transaction_gen
 * Agent function prototype for movement_transaction_gen function of Agent agent
 */
void Agent_movement_transaction_gen(cudaStream_t &stream);

/** Agent_movement_transaction
 * Agent function prototype for movement_transaction function of Agent agent
 */
void Agent_movement_transaction(cudaStream_t &stream);

  
void setPaddingAndOffset()
{
    PROFILE_SCOPED_RANGE("setPaddingAndOffset");
	cudaDeviceProp deviceProp;
	cudaGetDeviceProperties(&deviceProp, 0);
	int x64_sys = 0;

	// This function call returns 9999 for both major & minor fields, if no CUDA capable devices are present
	if (deviceProp.major == 9999 && deviceProp.minor == 9999){
		printf("Error: There is no device supporting CUDA.\n");
		exit(EXIT_FAILURE);
	}
    
    //check if double is used and supported
#ifdef _DOUBLE_SUPPORT_REQUIRED_
	printf("Simulation requires full precision double values\n");
	if ((deviceProp.major < 2)&&(deviceProp.minor < 3)){
		printf("Error: Hardware does not support full precision double values!\n");
		exit(EXIT_FAILURE);
	}
    
#endif

	//check 32 or 64bit
	x64_sys = (sizeof(void*)==8);
	if (x64_sys)
	{
		printf("64Bit System Detected\n");
	}
	else
	{
		printf("32Bit System Detected\n");
	}

	SM_START = 0;
	PADDING = 0;
  
	//copy padding and offset to GPU
	gpuErrchk(cudaMemcpyToSymbol( d_SM_START, &SM_START, sizeof(int)));
	gpuErrchk(cudaMemcpyToSymbol( d_PADDING, &PADDING, sizeof(int)));     
}

int is_sqr_pow2(int x){
	int r = (int)pow(4, ceil(log(x)/log(4)));
	return (r == x);
}

int lowest_sqr_pow2(int x){
	int l;
	
	//escape early if x is square power of 2
	if (is_sqr_pow2(x))
		return x;
	
	//lower bound		
	l = (int)pow(4, floor(log(x)/log(4)));
	
	return l;
}

/* Unary function required for cudaOccupancyMaxPotentialBlockSizeVariableSMem to avoid warnings */
int no_sm(int b){
	return 0;
}

/* Unary function to return shared memory size for reorder message kernels */
int reorder_messages_sm_size(int blockSize)
{
	return sizeof(unsigned int)*(blockSize+1);
}


/** getIterationNumber
 *  Get the iteration number (host)
 *  @return a 1 indexed value for the iteration number, which is incremented at the start of each simulation step.
 *      I.e. it is 0 on up until the first call to singleIteration()
 */
extern unsigned int getIterationNumber(){
    return g_iterationNumber;
}

void initialise(char * inputfile){
    PROFILE_SCOPED_RANGE("initialise");

	//set the padding and offset values depending on architecture and OS
	setPaddingAndOffset();
  
		// Initialise some global variables
		g_iterationNumber = 0;
		g_exit_early = false;

    // Initialise variables for tracking which iterations' data is accessible on the host.
    h_Agents_Agent_default_variable_x_data_iteration = 0;
    h_Agents_Agent_default_variable_y_data_iteration = 0;
    h_Agents_Agent_default_variable_z_data_iteration = 0;
    h_Agents_Agent_default_variable_target_pos_x_data_iteration = 0;
    h_Agents_Agent_default_variable_target_pos_y_data_iteration = 0;
    h_Agents_Agent_default_variable_agent_id_data_iteration = 0;
    h_Agents_Agent_default_variable_state_data_iteration = 0;
    h_Agents_Agent_default_variable_sugar_level_data_iteration = 0;
    h_Agents_Agent_default_variable_metabolism_data_iteration = 0;
    h_Agents_Agent_default_variable_env_sugar_level_data_iteration = 0;
    h_Agents_Agent_default_variable_max_env_sugar_level_data_iteration = 0;
    



	printf("Allocating Host and Device memory\n");
    PROFILE_PUSH_RANGE("allocate host");
	/* Agent memory allocation (CPU) */
	int xmachine_Agent_SoA_size = sizeof(xmachine_memory_Agent_list);
	h_Agents_Agent_default = (xmachine_memory_Agent_list*)malloc(xmachine_Agent_SoA_size);

	/* Message memory allocation (CPU) */
	int message_movement_request_message_SoA_size = sizeof(xmachine_message_movement_request_message_list);
	h_movement_request_messages = (xmachine_message_movement_request_message_list*)malloc(message_movement_request_message_SoA_size);
	int message_movement_response_message_SoA_size = sizeof(xmachine_message_movement_response_message_list);
	h_movement_response_messages = (xmachine_message_movement_response_message_list*)malloc(message_movement_response_message_SoA_size);
	int message_movement_transaction_message_SoA_size = sizeof(xmachine_message_movement_transaction_message_list);
	h_movement_transaction_messages = (xmachine_message_movement_transaction_message_list*)malloc(message_movement_transaction_message_SoA_size);

	//Exit if agent or message buffer sizes are to small for function outputs

  /* Graph memory allocation (CPU) */
  

    PROFILE_POP_RANGE(); //"allocate host"
	
			
	/* Set spatial partitioning movement_request_message message variables (min_bounds, max_bounds)*/
	h_message_movement_request_message_radius = (float)1.5;
	gpuErrchk(cudaMemcpyToSymbol( d_message_movement_request_message_radius, &h_message_movement_request_message_radius, sizeof(float)));	
	    h_message_movement_request_message_min_bounds = glm::vec3((float)0, (float)0, (float)0);
	gpuErrchk(cudaMemcpyToSymbol( d_message_movement_request_message_min_bounds, &h_message_movement_request_message_min_bounds, sizeof(glm::vec3)));	
	h_message_movement_request_message_max_bounds = glm::vec3((float)15, (float)15, (float)1.5);
	gpuErrchk(cudaMemcpyToSymbol( d_message_movement_request_message_max_bounds, &h_message_movement_request_message_max_bounds, sizeof(glm::vec3)));	
	h_message_movement_request_message_partitionDim.x = (int)round((h_message_movement_request_message_max_bounds.x - h_message_movement_request_message_min_bounds.x)/h_message_movement_request_message_radius);
	h_message_movement_request_message_partitionDim.y = (int)round((h_message_movement_request_message_max_bounds.y - h_message_movement_request_message_min_bounds.y)/h_message_movement_request_message_radius);
	h_message_movement_request_message_partitionDim.z = (int)round((h_message_movement_request_message_max_bounds.z - h_message_movement_request_message_min_bounds.z)/h_message_movement_request_message_radius);
	gpuErrchk(cudaMemcpyToSymbol( d_message_movement_request_message_partitionDim, &h_message_movement_request_message_partitionDim, sizeof(glm::ivec3)));	
	
			
	/* Set spatial partitioning movement_response_message message variables (min_bounds, max_bounds)*/
	h_message_movement_response_message_radius = (float)1.5;
	gpuErrchk(cudaMemcpyToSymbol( d_message_movement_response_message_radius, &h_message_movement_response_message_radius, sizeof(float)));	
	    h_message_movement_response_message_min_bounds = glm::vec3((float)0, (float)0, (float)0);
	gpuErrchk(cudaMemcpyToSymbol( d_message_movement_response_message_min_bounds, &h_message_movement_response_message_min_bounds, sizeof(glm::vec3)));	
	h_message_movement_response_message_max_bounds = glm::vec3((float)15, (float)15, (float)1.5);
	gpuErrchk(cudaMemcpyToSymbol( d_message_movement_response_message_max_bounds, &h_message_movement_response_message_max_bounds, sizeof(glm::vec3)));	
	h_message_movement_response_message_partitionDim.x = (int)round((h_message_movement_response_message_max_bounds.x - h_message_movement_response_message_min_bounds.x)/h_message_movement_response_message_radius);
	h_message_movement_response_message_partitionDim.y = (int)round((h_message_movement_response_message_max_bounds.y - h_message_movement_response_message_min_bounds.y)/h_message_movement_response_message_radius);
	h_message_movement_response_message_partitionDim.z = (int)round((h_message_movement_response_message_max_bounds.z - h_message_movement_response_message_min_bounds.z)/h_message_movement_response_message_radius);
	gpuErrchk(cudaMemcpyToSymbol( d_message_movement_response_message_partitionDim, &h_message_movement_response_message_partitionDim, sizeof(glm::ivec3)));	
	
			
	/* Set spatial partitioning movement_transaction_message message variables (min_bounds, max_bounds)*/
	h_message_movement_transaction_message_radius = (float)1.5;
	gpuErrchk(cudaMemcpyToSymbol( d_message_movement_transaction_message_radius, &h_message_movement_transaction_message_radius, sizeof(float)));	
	    h_message_movement_transaction_message_min_bounds = glm::vec3((float)0, (float)0, (float)0);
	gpuErrchk(cudaMemcpyToSymbol( d_message_movement_transaction_message_min_bounds, &h_message_movement_transaction_message_min_bounds, sizeof(glm::vec3)));	
	h_message_movement_transaction_message_max_bounds = glm::vec3((float)15, (float)15, (float)1.5);
	gpuErrchk(cudaMemcpyToSymbol( d_message_movement_transaction_message_max_bounds, &h_message_movement_transaction_message_max_bounds, sizeof(glm::vec3)));	
	h_message_movement_transaction_message_partitionDim.x = (int)round((h_message_movement_transaction_message_max_bounds.x - h_message_movement_transaction_message_min_bounds.x)/h_message_movement_transaction_message_radius);
	h_message_movement_transaction_message_partitionDim.y = (int)round((h_message_movement_transaction_message_max_bounds.y - h_message_movement_transaction_message_min_bounds.y)/h_message_movement_transaction_message_radius);
	h_message_movement_transaction_message_partitionDim.z = (int)round((h_message_movement_transaction_message_max_bounds.z - h_message_movement_transaction_message_min_bounds.z)/h_message_movement_transaction_message_radius);
	gpuErrchk(cudaMemcpyToSymbol( d_message_movement_transaction_message_partitionDim, &h_message_movement_transaction_message_partitionDim, sizeof(glm::ivec3)));	
	

	//read initial states
	readInitialStates(inputfile, h_Agents_Agent_default, &h_xmachine_memory_Agent_Agent_default_count);

  // Read graphs from disk
  

  PROFILE_PUSH_RANGE("allocate device");
	
	/* Agent Agent memory allocation (GPU) */
	gpuErrchk( cudaMalloc( (void**) &d_Agents, xmachine_Agent_SoA_size));
	gpuErrchk( cudaMalloc( (void**) &d_Agents_swap, xmachine_Agent_SoA_size));
	gpuErrchk( cudaMalloc( (void**) &d_Agents_new, xmachine_Agent_SoA_size));
    //continuous agent sort identifiers
  gpuErrchk( cudaMalloc( (void**) &d_xmachine_memory_Agent_keys, xmachine_memory_Agent_MAX* sizeof(uint)));
	gpuErrchk( cudaMalloc( (void**) &d_xmachine_memory_Agent_values, xmachine_memory_Agent_MAX* sizeof(uint)));
	/* Agent_default memory allocation (GPU) */
	gpuErrchk( cudaMalloc( (void**) &d_Agents_Agent_default, xmachine_Agent_SoA_size));
	gpuErrchk( cudaMemcpy( d_Agents_Agent_default, h_Agents_Agent_default, xmachine_Agent_SoA_size, cudaMemcpyHostToDevice));
    
	/* movement_request_message Message memory allocation (GPU) */
	gpuErrchk( cudaMalloc( (void**) &d_movement_request_messages, message_movement_request_message_SoA_size));
	gpuErrchk( cudaMalloc( (void**) &d_movement_request_messages_swap, message_movement_request_message_SoA_size));
	gpuErrchk( cudaMemcpy( d_movement_request_messages, h_movement_request_messages, message_movement_request_message_SoA_size, cudaMemcpyHostToDevice));
	gpuErrchk( cudaMalloc( (void**) &d_movement_request_message_partition_matrix, sizeof(xmachine_message_movement_request_message_PBM)));
#ifdef FAST_ATOMIC_SORTING
	gpuErrchk( cudaMalloc( (void**) &d_xmachine_message_movement_request_message_local_bin_index, xmachine_message_movement_request_message_MAX* sizeof(uint)));
	gpuErrchk( cudaMalloc( (void**) &d_xmachine_message_movement_request_message_unsorted_index, xmachine_message_movement_request_message_MAX* sizeof(uint)));
    /* Calculate and allocate CUB temporary memory for exclusive scans */
    d_temp_scan_storage_xmachine_message_movement_request_message = nullptr;
    temp_scan_bytes_xmachine_message_movement_request_message = 0;
    cub::DeviceScan::ExclusiveSum(
        d_temp_scan_storage_xmachine_message_movement_request_message, 
        temp_scan_bytes_xmachine_message_movement_request_message, 
        (int*) nullptr, 
        (int*) nullptr, 
        xmachine_message_movement_request_message_grid_size
    );
    gpuErrchk(cudaMalloc(&d_temp_scan_storage_xmachine_message_movement_request_message, temp_scan_bytes_xmachine_message_movement_request_message));
#else
	gpuErrchk( cudaMalloc( (void**) &d_xmachine_message_movement_request_message_keys, xmachine_message_movement_request_message_MAX* sizeof(uint)));
	gpuErrchk( cudaMalloc( (void**) &d_xmachine_message_movement_request_message_values, xmachine_message_movement_request_message_MAX* sizeof(uint)));
    gpuErrchk( cudaMalloc( (void**) &d_xmachine_message_movement_request_message_keys_swap, xmachine_message_movement_request_message_MAX* sizeof(uint)));
    gpuErrchk( cudaMalloc( (void**) &d_xmachine_message_movement_request_message_values_swap, xmachine_message_movement_request_message_MAX* sizeof(uint)));
    cub::DeviceRadixSort::SortPairs(d_CUB_temp_storage_movement_request_message, CUB_temp_storage_bytes_movement_request_message, d_xmachine_message_movement_request_message_keys, d_xmachine_message_movement_request_message_keys_swap, d_xmachine_message_movement_request_message_values, d_xmachine_message_movement_request_message_values_swap, xmachine_message_movement_request_message_MAX, 0, binCountBits_movement_request_message);
    gpuErrchk(cudaMalloc((void**)&d_CUB_temp_storage_movement_request_message, CUB_temp_storage_bytes_movement_request_message));
#endif
	
	/* movement_response_message Message memory allocation (GPU) */
	gpuErrchk( cudaMalloc( (void**) &d_movement_response_messages, message_movement_response_message_SoA_size));
	gpuErrchk( cudaMalloc( (void**) &d_movement_response_messages_swap, message_movement_response_message_SoA_size));
	gpuErrchk( cudaMemcpy( d_movement_response_messages, h_movement_response_messages, message_movement_response_message_SoA_size, cudaMemcpyHostToDevice));
	gpuErrchk( cudaMalloc( (void**) &d_movement_response_message_partition_matrix, sizeof(xmachine_message_movement_response_message_PBM)));
#ifdef FAST_ATOMIC_SORTING
	gpuErrchk( cudaMalloc( (void**) &d_xmachine_message_movement_response_message_local_bin_index, xmachine_message_movement_response_message_MAX* sizeof(uint)));
	gpuErrchk( cudaMalloc( (void**) &d_xmachine_message_movement_response_message_unsorted_index, xmachine_message_movement_response_message_MAX* sizeof(uint)));
    /* Calculate and allocate CUB temporary memory for exclusive scans */
    d_temp_scan_storage_xmachine_message_movement_response_message = nullptr;
    temp_scan_bytes_xmachine_message_movement_response_message = 0;
    cub::DeviceScan::ExclusiveSum(
        d_temp_scan_storage_xmachine_message_movement_response_message, 
        temp_scan_bytes_xmachine_message_movement_response_message, 
        (int*) nullptr, 
        (int*) nullptr, 
        xmachine_message_movement_response_message_grid_size
    );
    gpuErrchk(cudaMalloc(&d_temp_scan_storage_xmachine_message_movement_response_message, temp_scan_bytes_xmachine_message_movement_response_message));
#else
	gpuErrchk( cudaMalloc( (void**) &d_xmachine_message_movement_response_message_keys, xmachine_message_movement_response_message_MAX* sizeof(uint)));
	gpuErrchk( cudaMalloc( (void**) &d_xmachine_message_movement_response_message_values, xmachine_message_movement_response_message_MAX* sizeof(uint)));
    gpuErrchk( cudaMalloc( (void**) &d_xmachine_message_movement_response_message_keys_swap, xmachine_message_movement_response_message_MAX* sizeof(uint)));
    gpuErrchk( cudaMalloc( (void**) &d_xmachine_message_movement_response_message_values_swap, xmachine_message_movement_response_message_MAX* sizeof(uint)));
    cub::DeviceRadixSort::SortPairs(d_CUB_temp_storage_movement_response_message, CUB_temp_storage_bytes_movement_response_message, d_xmachine_message_movement_response_message_keys, d_xmachine_message_movement_response_message_keys_swap, d_xmachine_message_movement_response_message_values, d_xmachine_message_movement_response_message_values_swap, xmachine_message_movement_response_message_MAX, 0, binCountBits_movement_response_message);
    gpuErrchk(cudaMalloc((void**)&d_CUB_temp_storage_movement_response_message, CUB_temp_storage_bytes_movement_response_message));
#endif
	
	/* movement_transaction_message Message memory allocation (GPU) */
	gpuErrchk( cudaMalloc( (void**) &d_movement_transaction_messages, message_movement_transaction_message_SoA_size));
	gpuErrchk( cudaMalloc( (void**) &d_movement_transaction_messages_swap, message_movement_transaction_message_SoA_size));
	gpuErrchk( cudaMemcpy( d_movement_transaction_messages, h_movement_transaction_messages, message_movement_transaction_message_SoA_size, cudaMemcpyHostToDevice));
	gpuErrchk( cudaMalloc( (void**) &d_movement_transaction_message_partition_matrix, sizeof(xmachine_message_movement_transaction_message_PBM)));
#ifdef FAST_ATOMIC_SORTING
	gpuErrchk( cudaMalloc( (void**) &d_xmachine_message_movement_transaction_message_local_bin_index, xmachine_message_movement_transaction_message_MAX* sizeof(uint)));
	gpuErrchk( cudaMalloc( (void**) &d_xmachine_message_movement_transaction_message_unsorted_index, xmachine_message_movement_transaction_message_MAX* sizeof(uint)));
    /* Calculate and allocate CUB temporary memory for exclusive scans */
    d_temp_scan_storage_xmachine_message_movement_transaction_message = nullptr;
    temp_scan_bytes_xmachine_message_movement_transaction_message = 0;
    cub::DeviceScan::ExclusiveSum(
        d_temp_scan_storage_xmachine_message_movement_transaction_message, 
        temp_scan_bytes_xmachine_message_movement_transaction_message, 
        (int*) nullptr, 
        (int*) nullptr, 
        xmachine_message_movement_transaction_message_grid_size
    );
    gpuErrchk(cudaMalloc(&d_temp_scan_storage_xmachine_message_movement_transaction_message, temp_scan_bytes_xmachine_message_movement_transaction_message));
#else
	gpuErrchk( cudaMalloc( (void**) &d_xmachine_message_movement_transaction_message_keys, xmachine_message_movement_transaction_message_MAX* sizeof(uint)));
	gpuErrchk( cudaMalloc( (void**) &d_xmachine_message_movement_transaction_message_values, xmachine_message_movement_transaction_message_MAX* sizeof(uint)));
    gpuErrchk( cudaMalloc( (void**) &d_xmachine_message_movement_transaction_message_keys_swap, xmachine_message_movement_transaction_message_MAX* sizeof(uint)));
    gpuErrchk( cudaMalloc( (void**) &d_xmachine_message_movement_transaction_message_values_swap, xmachine_message_movement_transaction_message_MAX* sizeof(uint)));
    cub::DeviceRadixSort::SortPairs(d_CUB_temp_storage_movement_transaction_message, CUB_temp_storage_bytes_movement_transaction_message, d_xmachine_message_movement_transaction_message_keys, d_xmachine_message_movement_transaction_message_keys_swap, d_xmachine_message_movement_transaction_message_values, d_xmachine_message_movement_transaction_message_values_swap, xmachine_message_movement_transaction_message_MAX, 0, binCountBits_movement_transaction_message);
    gpuErrchk(cudaMalloc((void**)&d_CUB_temp_storage_movement_transaction_message, CUB_temp_storage_bytes_movement_transaction_message));
#endif
		


  /* Allocate device memory for graphs */
  

    PROFILE_POP_RANGE(); // "allocate device"

    /* Calculate and allocate CUB temporary memory for exclusive scans */
    
    d_temp_scan_storage_Agent = nullptr;
    temp_scan_storage_bytes_Agent = 0;
    cub::DeviceScan::ExclusiveSum(
        d_temp_scan_storage_Agent, 
        temp_scan_storage_bytes_Agent, 
        (int*) nullptr, 
        (int*) nullptr, 
        xmachine_memory_Agent_MAX
    );
    gpuErrchk(cudaMalloc(&d_temp_scan_storage_Agent, temp_scan_storage_bytes_Agent));
    

	/*Set global condition counts*/

	/* RNG rand48 */
    PROFILE_PUSH_RANGE("Initialse RNG_rand48");
	int h_rand48_SoA_size = sizeof(RNG_rand48);
	h_rand48 = (RNG_rand48*)malloc(h_rand48_SoA_size);
	//allocate on GPU
	gpuErrchk( cudaMalloc( (void**) &d_rand48, h_rand48_SoA_size));
	// calculate strided iteration constants
	static const unsigned long long a = 0x5DEECE66DLL, c = 0xB;
	int seed = 123;
	unsigned long long A, C;
	A = 1LL; C = 0LL;
	for (unsigned int i = 0; i < buffer_size_MAX; ++i) {
		C += A*c;
		A *= a;
	}
	h_rand48->A.x = A & 0xFFFFFFLL;
	h_rand48->A.y = (A >> 24) & 0xFFFFFFLL;
	h_rand48->C.x = C & 0xFFFFFFLL;
	h_rand48->C.y = (C >> 24) & 0xFFFFFFLL;
	// prepare first nThreads random numbers from seed
	unsigned long long x = (((unsigned long long)seed) << 16) | 0x330E;
	for (unsigned int i = 0; i < buffer_size_MAX; ++i) {
		x = a*x + c;
		h_rand48->seeds[i].x = x & 0xFFFFFFLL;
		h_rand48->seeds[i].y = (x >> 24) & 0xFFFFFFLL;
	}
	//copy to device
	gpuErrchk( cudaMemcpy( d_rand48, h_rand48, h_rand48_SoA_size, cudaMemcpyHostToDevice));

    PROFILE_POP_RANGE();

	/* Call all init functions */
	/* Prepare cuda event timers for instrumentation */
#if defined(INSTRUMENT_ITERATIONS) && INSTRUMENT_ITERATIONS
	cudaEventCreate(&instrument_iteration_start);
	cudaEventCreate(&instrument_iteration_stop);
#endif
#if (defined(INSTRUMENT_AGENT_FUNCTIONS) && INSTRUMENT_AGENT_FUNCTIONS) || (defined(INSTRUMENT_INIT_FUNCTIONS) && INSTRUMENT_INIT_FUNCTIONS) || (defined(INSTRUMENT_STEP_FUNCTIONS) && INSTRUMENT_STEP_FUNCTIONS) || (defined(INSTRUMENT_EXIT_FUNCTIONS) && INSTRUMENT_EXIT_FUNCTIONS)
	cudaEventCreate(&instrument_start);
	cudaEventCreate(&instrument_stop);
#endif

	
#if defined(INSTRUMENT_INIT_FUNCTIONS) && INSTRUMENT_INIT_FUNCTIONS
	cudaEventRecord(instrument_start);
#endif
    PROFILE_PUSH_RANGE("openabl_init");
    openabl_init();
    PROFILE_POP_RANGE();
#if defined(INSTRUMENT_INIT_FUNCTIONS) && INSTRUMENT_INIT_FUNCTIONS
	cudaEventRecord(instrument_stop);
	cudaEventSynchronize(instrument_stop);
	cudaEventElapsedTime(&instrument_milliseconds, instrument_start, instrument_stop);
	printf("Instrumentation: openabl_init = %f (ms)\n", instrument_milliseconds);
#endif
	

  /* If any Agents can generate IDs, update the device value after init functions have executed */

  
  /* Init CUDA Streams for function layers */
  
  gpuErrchk(cudaStreamCreate(&stream1));

#if defined(OUTPUT_POPULATION_PER_ITERATION) && OUTPUT_POPULATION_PER_ITERATION
	// Print the agent population size of all agents in all states
	
		printf("Init agent_Agent_Agent_default_count: %u\n",get_agent_Agent_Agent_default_count());
	
#endif
} 


void sort_Agents_Agent_default(void (*generate_key_value_pairs)(unsigned int* keys, unsigned int* values, xmachine_memory_Agent_list* agents))
{
	int blockSize;
	int minGridSize;
	int gridSize;

	//generate sort keys
	cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, generate_key_value_pairs, no_sm, h_xmachine_memory_Agent_Agent_default_count); 
	gridSize = (h_xmachine_memory_Agent_Agent_default_count + blockSize - 1) / blockSize;    // Round up according to array size 
	generate_key_value_pairs<<<gridSize, blockSize>>>(d_xmachine_memory_Agent_keys, d_xmachine_memory_Agent_values, d_Agents_Agent_default);
	gpuErrchkLaunch();

	//updated Thrust sort
	thrust::sort_by_key( thrust::device_pointer_cast(d_xmachine_memory_Agent_keys),  thrust::device_pointer_cast(d_xmachine_memory_Agent_keys) + h_xmachine_memory_Agent_Agent_default_count,  thrust::device_pointer_cast(d_xmachine_memory_Agent_values));
	gpuErrchkLaunch();

	//reorder agents
	cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, reorder_Agent_agents, no_sm, h_xmachine_memory_Agent_Agent_default_count); 
	gridSize = (h_xmachine_memory_Agent_Agent_default_count + blockSize - 1) / blockSize;    // Round up according to array size 
	reorder_Agent_agents<<<gridSize, blockSize>>>(d_xmachine_memory_Agent_values, d_Agents_Agent_default, d_Agents_swap);
	gpuErrchkLaunch();

	//swap
	xmachine_memory_Agent_list* d_Agents_temp = d_Agents_Agent_default;
	d_Agents_Agent_default = d_Agents_swap;
	d_Agents_swap = d_Agents_temp;	
}


void cleanup(){
    PROFILE_SCOPED_RANGE("cleanup");

    /* Call all exit functions */
	
#if defined(INSTRUMENT_EXIT_FUNCTIONS) && INSTRUMENT_EXIT_FUNCTIONS
	cudaEventRecord(instrument_start);
#endif

    PROFILE_PUSH_RANGE("openabl_exit");
    openabl_exit();
	PROFILE_POP_RANGE();

#if defined(INSTRUMENT_EXIT_FUNCTIONS) && INSTRUMENT_EXIT_FUNCTIONS
	cudaEventRecord(instrument_stop);
	cudaEventSynchronize(instrument_stop);
	cudaEventElapsedTime(&instrument_milliseconds, instrument_start, instrument_stop);
	printf("Instrumentation: openabl_exit = %f (ms)\n", instrument_milliseconds);
#endif
	

	/* Agent data free*/
	
	/* Agent Agent variables */
	gpuErrchk(cudaFree(d_Agents));
	gpuErrchk(cudaFree(d_Agents_swap));
	gpuErrchk(cudaFree(d_Agents_new));
	
	free( h_Agents_Agent_default);
	gpuErrchk(cudaFree(d_Agents_Agent_default));
	

	/* Message data free */
	
	/* movement_request_message Message variables */
	free( h_movement_request_messages);
	gpuErrchk(cudaFree(d_movement_request_messages));
	gpuErrchk(cudaFree(d_movement_request_messages_swap));
	gpuErrchk(cudaFree(d_movement_request_message_partition_matrix));
#ifdef FAST_ATOMIC_SORTING
	gpuErrchk(cudaFree(d_xmachine_message_movement_request_message_local_bin_index));
	gpuErrchk(cudaFree(d_xmachine_message_movement_request_message_unsorted_index));
  gpuErrchk(cudaFree(d_temp_scan_storage_xmachine_message_movement_request_message));
  d_temp_scan_storage_xmachine_message_movement_request_message = nullptr;
  temp_scan_bytes_xmachine_message_movement_request_message = 0;
#else
	gpuErrchk(cudaFree(d_xmachine_message_movement_request_message_keys));
	gpuErrchk(cudaFree(d_xmachine_message_movement_request_message_values));
    gpuErrchk(cudaFree(d_xmachine_message_movement_request_message_keys_swap));
    gpuErrchk(cudaFree(d_xmachine_message_movement_request_message_values_swap));
    gpuErrchk(cudaFree(d_CUB_temp_storage_movement_request_message));
    #endif
	
	/* movement_response_message Message variables */
	free( h_movement_response_messages);
	gpuErrchk(cudaFree(d_movement_response_messages));
	gpuErrchk(cudaFree(d_movement_response_messages_swap));
	gpuErrchk(cudaFree(d_movement_response_message_partition_matrix));
#ifdef FAST_ATOMIC_SORTING
	gpuErrchk(cudaFree(d_xmachine_message_movement_response_message_local_bin_index));
	gpuErrchk(cudaFree(d_xmachine_message_movement_response_message_unsorted_index));
  gpuErrchk(cudaFree(d_temp_scan_storage_xmachine_message_movement_response_message));
  d_temp_scan_storage_xmachine_message_movement_response_message = nullptr;
  temp_scan_bytes_xmachine_message_movement_response_message = 0;
#else
	gpuErrchk(cudaFree(d_xmachine_message_movement_response_message_keys));
	gpuErrchk(cudaFree(d_xmachine_message_movement_response_message_values));
    gpuErrchk(cudaFree(d_xmachine_message_movement_response_message_keys_swap));
    gpuErrchk(cudaFree(d_xmachine_message_movement_response_message_values_swap));
    gpuErrchk(cudaFree(d_CUB_temp_storage_movement_response_message));
    #endif
	
	/* movement_transaction_message Message variables */
	free( h_movement_transaction_messages);
	gpuErrchk(cudaFree(d_movement_transaction_messages));
	gpuErrchk(cudaFree(d_movement_transaction_messages_swap));
	gpuErrchk(cudaFree(d_movement_transaction_message_partition_matrix));
#ifdef FAST_ATOMIC_SORTING
	gpuErrchk(cudaFree(d_xmachine_message_movement_transaction_message_local_bin_index));
	gpuErrchk(cudaFree(d_xmachine_message_movement_transaction_message_unsorted_index));
  gpuErrchk(cudaFree(d_temp_scan_storage_xmachine_message_movement_transaction_message));
  d_temp_scan_storage_xmachine_message_movement_transaction_message = nullptr;
  temp_scan_bytes_xmachine_message_movement_transaction_message = 0;
#else
	gpuErrchk(cudaFree(d_xmachine_message_movement_transaction_message_keys));
	gpuErrchk(cudaFree(d_xmachine_message_movement_transaction_message_values));
    gpuErrchk(cudaFree(d_xmachine_message_movement_transaction_message_keys_swap));
    gpuErrchk(cudaFree(d_xmachine_message_movement_transaction_message_values_swap));
    gpuErrchk(cudaFree(d_CUB_temp_storage_movement_transaction_message));
    #endif
	

    /* Free temporary CUB memory if required. */
    
    if(d_temp_scan_storage_Agent != nullptr){
      gpuErrchk(cudaFree(d_temp_scan_storage_Agent));
      d_temp_scan_storage_Agent = nullptr;
      temp_scan_storage_bytes_Agent = 0;
    }
    

  /* Graph data free */
  
  
  /* CUDA Streams for function layers */
  
  gpuErrchk(cudaStreamDestroy(stream1));

  /* CUDA Event Timers for Instrumentation */
#if defined(INSTRUMENT_ITERATIONS) && INSTRUMENT_ITERATIONS
	cudaEventDestroy(instrument_iteration_start);
	cudaEventDestroy(instrument_iteration_stop);
#endif
#if (defined(INSTRUMENT_AGENT_FUNCTIONS) && INSTRUMENT_AGENT_FUNCTIONS) || (defined(INSTRUMENT_INIT_FUNCTIONS) && INSTRUMENT_INIT_FUNCTIONS) || (defined(INSTRUMENT_STEP_FUNCTIONS) && INSTRUMENT_STEP_FUNCTIONS) || (defined(INSTRUMENT_EXIT_FUNCTIONS) && INSTRUMENT_EXIT_FUNCTIONS)
	cudaEventDestroy(instrument_start);
	cudaEventDestroy(instrument_stop);
#endif
}

void singleIteration(){
PROFILE_SCOPED_RANGE("singleIteration");

#if defined(INSTRUMENT_ITERATIONS) && INSTRUMENT_ITERATIONS
	cudaEventRecord(instrument_iteration_start);
#endif

    // Increment the iteration number.
    g_iterationNumber++;

  /* set all non partitioned, spatial partitioned and On-Graph Partitioned message counts to 0*/
	h_message_movement_request_message_count = 0;
	//upload to device constant
	gpuErrchk(cudaMemcpyToSymbol( d_message_movement_request_message_count, &h_message_movement_request_message_count, sizeof(int)));
	
	h_message_movement_response_message_count = 0;
	//upload to device constant
	gpuErrchk(cudaMemcpyToSymbol( d_message_movement_response_message_count, &h_message_movement_response_message_count, sizeof(int)));
	
	h_message_movement_transaction_message_count = 0;
	//upload to device constant
	gpuErrchk(cudaMemcpyToSymbol( d_message_movement_transaction_message_count, &h_message_movement_transaction_message_count, sizeof(int)));
	

	/* Call agent functions in order iterating through the layer functions */
	
	/* Layer 1*/
	
#if defined(INSTRUMENT_AGENT_FUNCTIONS) && INSTRUMENT_AGENT_FUNCTIONS
	cudaEventRecord(instrument_start);
#endif
	
    PROFILE_PUSH_RANGE("Agent_metabolise_and_growback");
	Agent_metabolise_and_growback(stream1);
    PROFILE_POP_RANGE();
#if defined(INSTRUMENT_AGENT_FUNCTIONS) && INSTRUMENT_AGENT_FUNCTIONS
	cudaEventRecord(instrument_stop);
	cudaEventSynchronize(instrument_stop);
	cudaEventElapsedTime(&instrument_milliseconds, instrument_start, instrument_stop);
	printf("Instrumentation: Agent_metabolise_and_growback = %f (ms)\n", instrument_milliseconds);
#endif
	cudaDeviceSynchronize();
  
	/* Layer 2*/
	
#if defined(INSTRUMENT_AGENT_FUNCTIONS) && INSTRUMENT_AGENT_FUNCTIONS
	cudaEventRecord(instrument_start);
#endif
	
    PROFILE_PUSH_RANGE("Agent_movement_request_gen");
	Agent_movement_request_gen(stream1);
    PROFILE_POP_RANGE();
#if defined(INSTRUMENT_AGENT_FUNCTIONS) && INSTRUMENT_AGENT_FUNCTIONS
	cudaEventRecord(instrument_stop);
	cudaEventSynchronize(instrument_stop);
	cudaEventElapsedTime(&instrument_milliseconds, instrument_start, instrument_stop);
	printf("Instrumentation: Agent_movement_request_gen = %f (ms)\n", instrument_milliseconds);
#endif
	cudaDeviceSynchronize();
  
	/* Layer 3*/
	
#if defined(INSTRUMENT_AGENT_FUNCTIONS) && INSTRUMENT_AGENT_FUNCTIONS
	cudaEventRecord(instrument_start);
#endif
	
    PROFILE_PUSH_RANGE("Agent_movement_request");
	Agent_movement_request(stream1);
    PROFILE_POP_RANGE();
#if defined(INSTRUMENT_AGENT_FUNCTIONS) && INSTRUMENT_AGENT_FUNCTIONS
	cudaEventRecord(instrument_stop);
	cudaEventSynchronize(instrument_stop);
	cudaEventElapsedTime(&instrument_milliseconds, instrument_start, instrument_stop);
	printf("Instrumentation: Agent_movement_request = %f (ms)\n", instrument_milliseconds);
#endif
	cudaDeviceSynchronize();
  
	/* Layer 4*/
	
#if defined(INSTRUMENT_AGENT_FUNCTIONS) && INSTRUMENT_AGENT_FUNCTIONS
	cudaEventRecord(instrument_start);
#endif
	
    PROFILE_PUSH_RANGE("Agent_movement_response_gen");
	Agent_movement_response_gen(stream1);
    PROFILE_POP_RANGE();
#if defined(INSTRUMENT_AGENT_FUNCTIONS) && INSTRUMENT_AGENT_FUNCTIONS
	cudaEventRecord(instrument_stop);
	cudaEventSynchronize(instrument_stop);
	cudaEventElapsedTime(&instrument_milliseconds, instrument_start, instrument_stop);
	printf("Instrumentation: Agent_movement_response_gen = %f (ms)\n", instrument_milliseconds);
#endif
	cudaDeviceSynchronize();
  
	/* Layer 5*/
	
#if defined(INSTRUMENT_AGENT_FUNCTIONS) && INSTRUMENT_AGENT_FUNCTIONS
	cudaEventRecord(instrument_start);
#endif
	
    PROFILE_PUSH_RANGE("Agent_movement_response");
	Agent_movement_response(stream1);
    PROFILE_POP_RANGE();
#if defined(INSTRUMENT_AGENT_FUNCTIONS) && INSTRUMENT_AGENT_FUNCTIONS
	cudaEventRecord(instrument_stop);
	cudaEventSynchronize(instrument_stop);
	cudaEventElapsedTime(&instrument_milliseconds, instrument_start, instrument_stop);
	printf("Instrumentation: Agent_movement_response = %f (ms)\n", instrument_milliseconds);
#endif
	cudaDeviceSynchronize();
  
	/* Layer 6*/
	
#if defined(INSTRUMENT_AGENT_FUNCTIONS) && INSTRUMENT_AGENT_FUNCTIONS
	cudaEventRecord(instrument_start);
#endif
	
    PROFILE_PUSH_RANGE("Agent_movement_transaction_gen");
	Agent_movement_transaction_gen(stream1);
    PROFILE_POP_RANGE();
#if defined(INSTRUMENT_AGENT_FUNCTIONS) && INSTRUMENT_AGENT_FUNCTIONS
	cudaEventRecord(instrument_stop);
	cudaEventSynchronize(instrument_stop);
	cudaEventElapsedTime(&instrument_milliseconds, instrument_start, instrument_stop);
	printf("Instrumentation: Agent_movement_transaction_gen = %f (ms)\n", instrument_milliseconds);
#endif
	cudaDeviceSynchronize();
  
	/* Layer 7*/
	
#if defined(INSTRUMENT_AGENT_FUNCTIONS) && INSTRUMENT_AGENT_FUNCTIONS
	cudaEventRecord(instrument_start);
#endif
	
    PROFILE_PUSH_RANGE("Agent_movement_transaction");
	Agent_movement_transaction(stream1);
    PROFILE_POP_RANGE();
#if defined(INSTRUMENT_AGENT_FUNCTIONS) && INSTRUMENT_AGENT_FUNCTIONS
	cudaEventRecord(instrument_stop);
	cudaEventSynchronize(instrument_stop);
	cudaEventElapsedTime(&instrument_milliseconds, instrument_start, instrument_stop);
	printf("Instrumentation: Agent_movement_transaction = %f (ms)\n", instrument_milliseconds);
#endif
	cudaDeviceSynchronize();
  

  /* If any Agents can generate IDs, update the host value after agent functions have executed */

    
    /* Call all step functions */
	

/* If any Agents can generate IDs, update the device value after step functions have executed */


#if defined(OUTPUT_POPULATION_PER_ITERATION) && OUTPUT_POPULATION_PER_ITERATION
	// Print the agent population size of all agents in all states
	
		printf("agent_Agent_Agent_default_count: %u\n",get_agent_Agent_Agent_default_count());
	
#endif

#if defined(INSTRUMENT_ITERATIONS) && INSTRUMENT_ITERATIONS
	cudaEventRecord(instrument_iteration_stop);
	cudaEventSynchronize(instrument_iteration_stop);
	cudaEventElapsedTime(&instrument_iteration_milliseconds, instrument_iteration_start, instrument_iteration_stop);
	printf("Instrumentation: Iteration Time = %f (ms)\n", instrument_iteration_milliseconds);
#endif
}

/* finish whole simulation after this step */
void set_exit_early() {
	g_exit_early = true;
}

bool get_exit_early() {
	return g_exit_early;
}

/* Environment functions */

//host constant declaration



/* Agent data access functions*/

    
int get_agent_Agent_MAX_count(){
    return xmachine_memory_Agent_MAX;
}


int get_agent_Agent_Agent_default_count(){
	//continuous agent
	return h_xmachine_memory_Agent_Agent_default_count;
	
}

xmachine_memory_Agent_list* get_device_Agent_Agent_default_agents(){
	return d_Agents_Agent_default;
}

xmachine_memory_Agent_list* get_host_Agent_Agent_default_agents(){
	return h_Agents_Agent_default;
}



/* Host based access of agent variables*/

/** double get_Agent_Agent_default_variable_x(unsigned int index)
 * Gets the value of the x variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable x
 */
__host__ double get_Agent_Agent_default_variable_x(unsigned int index){
    unsigned int count = get_agent_Agent_Agent_default_count();
    unsigned int currentIteration = getIterationNumber();
    
    // If the index is within bounds - no need to check >= 0 due to unsigned.
    if(count > 0 && index < count ){
        // If necessary, copy agent data from the device to the host in the default stream
        if(h_Agents_Agent_default_variable_x_data_iteration != currentIteration){
            gpuErrchk(
                cudaMemcpy(
                    h_Agents_Agent_default->x,
                    d_Agents_Agent_default->x,
                    count * sizeof(double),
                    cudaMemcpyDeviceToHost
                )
            );
            // Update some global value indicating what data is currently present in that host array.
            h_Agents_Agent_default_variable_x_data_iteration = currentIteration;
        }

        // Return the value of the index-th element of the relevant host array.
        return h_Agents_Agent_default->x[index];

    } else {
        fprintf(stderr, "Warning: Attempting to access x for the %u th member of Agent_Agent_default. count is %u at iteration %u\n", index, count, currentIteration);
        // Otherwise we return a default value
        return 0;

    }
}

/** double get_Agent_Agent_default_variable_y(unsigned int index)
 * Gets the value of the y variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable y
 */
__host__ double get_Agent_Agent_default_variable_y(unsigned int index){
    unsigned int count = get_agent_Agent_Agent_default_count();
    unsigned int currentIteration = getIterationNumber();
    
    // If the index is within bounds - no need to check >= 0 due to unsigned.
    if(count > 0 && index < count ){
        // If necessary, copy agent data from the device to the host in the default stream
        if(h_Agents_Agent_default_variable_y_data_iteration != currentIteration){
            gpuErrchk(
                cudaMemcpy(
                    h_Agents_Agent_default->y,
                    d_Agents_Agent_default->y,
                    count * sizeof(double),
                    cudaMemcpyDeviceToHost
                )
            );
            // Update some global value indicating what data is currently present in that host array.
            h_Agents_Agent_default_variable_y_data_iteration = currentIteration;
        }

        // Return the value of the index-th element of the relevant host array.
        return h_Agents_Agent_default->y[index];

    } else {
        fprintf(stderr, "Warning: Attempting to access y for the %u th member of Agent_Agent_default. count is %u at iteration %u\n", index, count, currentIteration);
        // Otherwise we return a default value
        return 0;

    }
}

/** double get_Agent_Agent_default_variable_z(unsigned int index)
 * Gets the value of the z variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable z
 */
__host__ double get_Agent_Agent_default_variable_z(unsigned int index){
    unsigned int count = get_agent_Agent_Agent_default_count();
    unsigned int currentIteration = getIterationNumber();
    
    // If the index is within bounds - no need to check >= 0 due to unsigned.
    if(count > 0 && index < count ){
        // If necessary, copy agent data from the device to the host in the default stream
        if(h_Agents_Agent_default_variable_z_data_iteration != currentIteration){
            gpuErrchk(
                cudaMemcpy(
                    h_Agents_Agent_default->z,
                    d_Agents_Agent_default->z,
                    count * sizeof(double),
                    cudaMemcpyDeviceToHost
                )
            );
            // Update some global value indicating what data is currently present in that host array.
            h_Agents_Agent_default_variable_z_data_iteration = currentIteration;
        }

        // Return the value of the index-th element of the relevant host array.
        return h_Agents_Agent_default->z[index];

    } else {
        fprintf(stderr, "Warning: Attempting to access z for the %u th member of Agent_Agent_default. count is %u at iteration %u\n", index, count, currentIteration);
        // Otherwise we return a default value
        return 0;

    }
}

/** double get_Agent_Agent_default_variable_target_pos_x(unsigned int index)
 * Gets the value of the target_pos_x variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable target_pos_x
 */
__host__ double get_Agent_Agent_default_variable_target_pos_x(unsigned int index){
    unsigned int count = get_agent_Agent_Agent_default_count();
    unsigned int currentIteration = getIterationNumber();
    
    // If the index is within bounds - no need to check >= 0 due to unsigned.
    if(count > 0 && index < count ){
        // If necessary, copy agent data from the device to the host in the default stream
        if(h_Agents_Agent_default_variable_target_pos_x_data_iteration != currentIteration){
            gpuErrchk(
                cudaMemcpy(
                    h_Agents_Agent_default->target_pos_x,
                    d_Agents_Agent_default->target_pos_x,
                    count * sizeof(double),
                    cudaMemcpyDeviceToHost
                )
            );
            // Update some global value indicating what data is currently present in that host array.
            h_Agents_Agent_default_variable_target_pos_x_data_iteration = currentIteration;
        }

        // Return the value of the index-th element of the relevant host array.
        return h_Agents_Agent_default->target_pos_x[index];

    } else {
        fprintf(stderr, "Warning: Attempting to access target_pos_x for the %u th member of Agent_Agent_default. count is %u at iteration %u\n", index, count, currentIteration);
        // Otherwise we return a default value
        return 0;

    }
}

/** double get_Agent_Agent_default_variable_target_pos_y(unsigned int index)
 * Gets the value of the target_pos_y variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable target_pos_y
 */
__host__ double get_Agent_Agent_default_variable_target_pos_y(unsigned int index){
    unsigned int count = get_agent_Agent_Agent_default_count();
    unsigned int currentIteration = getIterationNumber();
    
    // If the index is within bounds - no need to check >= 0 due to unsigned.
    if(count > 0 && index < count ){
        // If necessary, copy agent data from the device to the host in the default stream
        if(h_Agents_Agent_default_variable_target_pos_y_data_iteration != currentIteration){
            gpuErrchk(
                cudaMemcpy(
                    h_Agents_Agent_default->target_pos_y,
                    d_Agents_Agent_default->target_pos_y,
                    count * sizeof(double),
                    cudaMemcpyDeviceToHost
                )
            );
            // Update some global value indicating what data is currently present in that host array.
            h_Agents_Agent_default_variable_target_pos_y_data_iteration = currentIteration;
        }

        // Return the value of the index-th element of the relevant host array.
        return h_Agents_Agent_default->target_pos_y[index];

    } else {
        fprintf(stderr, "Warning: Attempting to access target_pos_y for the %u th member of Agent_Agent_default. count is %u at iteration %u\n", index, count, currentIteration);
        // Otherwise we return a default value
        return 0;

    }
}

/** int get_Agent_Agent_default_variable_agent_id(unsigned int index)
 * Gets the value of the agent_id variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable agent_id
 */
__host__ int get_Agent_Agent_default_variable_agent_id(unsigned int index){
    unsigned int count = get_agent_Agent_Agent_default_count();
    unsigned int currentIteration = getIterationNumber();
    
    // If the index is within bounds - no need to check >= 0 due to unsigned.
    if(count > 0 && index < count ){
        // If necessary, copy agent data from the device to the host in the default stream
        if(h_Agents_Agent_default_variable_agent_id_data_iteration != currentIteration){
            gpuErrchk(
                cudaMemcpy(
                    h_Agents_Agent_default->agent_id,
                    d_Agents_Agent_default->agent_id,
                    count * sizeof(int),
                    cudaMemcpyDeviceToHost
                )
            );
            // Update some global value indicating what data is currently present in that host array.
            h_Agents_Agent_default_variable_agent_id_data_iteration = currentIteration;
        }

        // Return the value of the index-th element of the relevant host array.
        return h_Agents_Agent_default->agent_id[index];

    } else {
        fprintf(stderr, "Warning: Attempting to access agent_id for the %u th member of Agent_Agent_default. count is %u at iteration %u\n", index, count, currentIteration);
        // Otherwise we return a default value
        return 0;

    }
}

/** int get_Agent_Agent_default_variable_state(unsigned int index)
 * Gets the value of the state variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable state
 */
__host__ int get_Agent_Agent_default_variable_state(unsigned int index){
    unsigned int count = get_agent_Agent_Agent_default_count();
    unsigned int currentIteration = getIterationNumber();
    
    // If the index is within bounds - no need to check >= 0 due to unsigned.
    if(count > 0 && index < count ){
        // If necessary, copy agent data from the device to the host in the default stream
        if(h_Agents_Agent_default_variable_state_data_iteration != currentIteration){
            gpuErrchk(
                cudaMemcpy(
                    h_Agents_Agent_default->state,
                    d_Agents_Agent_default->state,
                    count * sizeof(int),
                    cudaMemcpyDeviceToHost
                )
            );
            // Update some global value indicating what data is currently present in that host array.
            h_Agents_Agent_default_variable_state_data_iteration = currentIteration;
        }

        // Return the value of the index-th element of the relevant host array.
        return h_Agents_Agent_default->state[index];

    } else {
        fprintf(stderr, "Warning: Attempting to access state for the %u th member of Agent_Agent_default. count is %u at iteration %u\n", index, count, currentIteration);
        // Otherwise we return a default value
        return 0;

    }
}

/** int get_Agent_Agent_default_variable_sugar_level(unsigned int index)
 * Gets the value of the sugar_level variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable sugar_level
 */
__host__ int get_Agent_Agent_default_variable_sugar_level(unsigned int index){
    unsigned int count = get_agent_Agent_Agent_default_count();
    unsigned int currentIteration = getIterationNumber();
    
    // If the index is within bounds - no need to check >= 0 due to unsigned.
    if(count > 0 && index < count ){
        // If necessary, copy agent data from the device to the host in the default stream
        if(h_Agents_Agent_default_variable_sugar_level_data_iteration != currentIteration){
            gpuErrchk(
                cudaMemcpy(
                    h_Agents_Agent_default->sugar_level,
                    d_Agents_Agent_default->sugar_level,
                    count * sizeof(int),
                    cudaMemcpyDeviceToHost
                )
            );
            // Update some global value indicating what data is currently present in that host array.
            h_Agents_Agent_default_variable_sugar_level_data_iteration = currentIteration;
        }

        // Return the value of the index-th element of the relevant host array.
        return h_Agents_Agent_default->sugar_level[index];

    } else {
        fprintf(stderr, "Warning: Attempting to access sugar_level for the %u th member of Agent_Agent_default. count is %u at iteration %u\n", index, count, currentIteration);
        // Otherwise we return a default value
        return 0;

    }
}

/** int get_Agent_Agent_default_variable_metabolism(unsigned int index)
 * Gets the value of the metabolism variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable metabolism
 */
__host__ int get_Agent_Agent_default_variable_metabolism(unsigned int index){
    unsigned int count = get_agent_Agent_Agent_default_count();
    unsigned int currentIteration = getIterationNumber();
    
    // If the index is within bounds - no need to check >= 0 due to unsigned.
    if(count > 0 && index < count ){
        // If necessary, copy agent data from the device to the host in the default stream
        if(h_Agents_Agent_default_variable_metabolism_data_iteration != currentIteration){
            gpuErrchk(
                cudaMemcpy(
                    h_Agents_Agent_default->metabolism,
                    d_Agents_Agent_default->metabolism,
                    count * sizeof(int),
                    cudaMemcpyDeviceToHost
                )
            );
            // Update some global value indicating what data is currently present in that host array.
            h_Agents_Agent_default_variable_metabolism_data_iteration = currentIteration;
        }

        // Return the value of the index-th element of the relevant host array.
        return h_Agents_Agent_default->metabolism[index];

    } else {
        fprintf(stderr, "Warning: Attempting to access metabolism for the %u th member of Agent_Agent_default. count is %u at iteration %u\n", index, count, currentIteration);
        // Otherwise we return a default value
        return 0;

    }
}

/** int get_Agent_Agent_default_variable_env_sugar_level(unsigned int index)
 * Gets the value of the env_sugar_level variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable env_sugar_level
 */
__host__ int get_Agent_Agent_default_variable_env_sugar_level(unsigned int index){
    unsigned int count = get_agent_Agent_Agent_default_count();
    unsigned int currentIteration = getIterationNumber();
    
    // If the index is within bounds - no need to check >= 0 due to unsigned.
    if(count > 0 && index < count ){
        // If necessary, copy agent data from the device to the host in the default stream
        if(h_Agents_Agent_default_variable_env_sugar_level_data_iteration != currentIteration){
            gpuErrchk(
                cudaMemcpy(
                    h_Agents_Agent_default->env_sugar_level,
                    d_Agents_Agent_default->env_sugar_level,
                    count * sizeof(int),
                    cudaMemcpyDeviceToHost
                )
            );
            // Update some global value indicating what data is currently present in that host array.
            h_Agents_Agent_default_variable_env_sugar_level_data_iteration = currentIteration;
        }

        // Return the value of the index-th element of the relevant host array.
        return h_Agents_Agent_default->env_sugar_level[index];

    } else {
        fprintf(stderr, "Warning: Attempting to access env_sugar_level for the %u th member of Agent_Agent_default. count is %u at iteration %u\n", index, count, currentIteration);
        // Otherwise we return a default value
        return 0;

    }
}

/** int get_Agent_Agent_default_variable_max_env_sugar_level(unsigned int index)
 * Gets the value of the max_env_sugar_level variable of an Agent agent in the Agent_default state on the host. 
 * If the data is not currently on the host, a memcpy of the data of all agents in that state list will be issued, via a global.
 * This has a potentially significant performance impact if used improperly.
 * @param index the index of the agent within the list.
 * @return value of agent variable max_env_sugar_level
 */
__host__ int get_Agent_Agent_default_variable_max_env_sugar_level(unsigned int index){
    unsigned int count = get_agent_Agent_Agent_default_count();
    unsigned int currentIteration = getIterationNumber();
    
    // If the index is within bounds - no need to check >= 0 due to unsigned.
    if(count > 0 && index < count ){
        // If necessary, copy agent data from the device to the host in the default stream
        if(h_Agents_Agent_default_variable_max_env_sugar_level_data_iteration != currentIteration){
            gpuErrchk(
                cudaMemcpy(
                    h_Agents_Agent_default->max_env_sugar_level,
                    d_Agents_Agent_default->max_env_sugar_level,
                    count * sizeof(int),
                    cudaMemcpyDeviceToHost
                )
            );
            // Update some global value indicating what data is currently present in that host array.
            h_Agents_Agent_default_variable_max_env_sugar_level_data_iteration = currentIteration;
        }

        // Return the value of the index-th element of the relevant host array.
        return h_Agents_Agent_default->max_env_sugar_level[index];

    } else {
        fprintf(stderr, "Warning: Attempting to access max_env_sugar_level for the %u th member of Agent_Agent_default. count is %u at iteration %u\n", index, count, currentIteration);
        // Otherwise we return a default value
        return 0;

    }
}



/* Host based agent creation functions */
// These are only available for continuous agents.



/* copy_single_xmachine_memory_Agent_hostToDevice
 * Private function to copy a host agent struct into a device SoA agent list.
 * @param d_dst destination agent state list
 * @param h_agent agent struct
 */
void copy_single_xmachine_memory_Agent_hostToDevice(xmachine_memory_Agent_list * d_dst, xmachine_memory_Agent * h_agent){
 
		gpuErrchk(cudaMemcpy(d_dst->x, &h_agent->x, sizeof(double), cudaMemcpyHostToDevice));
 
		gpuErrchk(cudaMemcpy(d_dst->y, &h_agent->y, sizeof(double), cudaMemcpyHostToDevice));
 
		gpuErrchk(cudaMemcpy(d_dst->z, &h_agent->z, sizeof(double), cudaMemcpyHostToDevice));
 
		gpuErrchk(cudaMemcpy(d_dst->target_pos_x, &h_agent->target_pos_x, sizeof(double), cudaMemcpyHostToDevice));
 
		gpuErrchk(cudaMemcpy(d_dst->target_pos_y, &h_agent->target_pos_y, sizeof(double), cudaMemcpyHostToDevice));
 
		gpuErrchk(cudaMemcpy(d_dst->agent_id, &h_agent->agent_id, sizeof(int), cudaMemcpyHostToDevice));
 
		gpuErrchk(cudaMemcpy(d_dst->state, &h_agent->state, sizeof(int), cudaMemcpyHostToDevice));
 
		gpuErrchk(cudaMemcpy(d_dst->sugar_level, &h_agent->sugar_level, sizeof(int), cudaMemcpyHostToDevice));
 
		gpuErrchk(cudaMemcpy(d_dst->metabolism, &h_agent->metabolism, sizeof(int), cudaMemcpyHostToDevice));
 
		gpuErrchk(cudaMemcpy(d_dst->env_sugar_level, &h_agent->env_sugar_level, sizeof(int), cudaMemcpyHostToDevice));
 
		gpuErrchk(cudaMemcpy(d_dst->max_env_sugar_level, &h_agent->max_env_sugar_level, sizeof(int), cudaMemcpyHostToDevice));

}
/*
 * Private function to copy some elements from a host based struct of arrays to a device based struct of arrays for a single agent state.
 * Individual copies of `count` elements are performed for each agent variable or each component of agent array variables, to avoid wasted data transfer.
 * There will be a point at which a single cudaMemcpy will outperform many smaller memcpys, however host based agent creation should typically only populate a fraction of the maximum buffer size, so this should be more efficient.
 * @optimisation - experimentally find the proportion at which transferring the whole SoA would be better and incorporate this. The same will apply to agent variable arrays.
 * 
 * @param d_dst device destination SoA
 * @oaram h_src host source SoA
 * @param count the number of agents to transfer data for
 */
void copy_partial_xmachine_memory_Agent_hostToDevice(xmachine_memory_Agent_list * d_dst, xmachine_memory_Agent_list * h_src, unsigned int count){
    // Only copy elements if there is data to move.
    if (count > 0){
	 
		gpuErrchk(cudaMemcpy(d_dst->x, h_src->x, count * sizeof(double), cudaMemcpyHostToDevice));
 
		gpuErrchk(cudaMemcpy(d_dst->y, h_src->y, count * sizeof(double), cudaMemcpyHostToDevice));
 
		gpuErrchk(cudaMemcpy(d_dst->z, h_src->z, count * sizeof(double), cudaMemcpyHostToDevice));
 
		gpuErrchk(cudaMemcpy(d_dst->target_pos_x, h_src->target_pos_x, count * sizeof(double), cudaMemcpyHostToDevice));
 
		gpuErrchk(cudaMemcpy(d_dst->target_pos_y, h_src->target_pos_y, count * sizeof(double), cudaMemcpyHostToDevice));
 
		gpuErrchk(cudaMemcpy(d_dst->agent_id, h_src->agent_id, count * sizeof(int), cudaMemcpyHostToDevice));
 
		gpuErrchk(cudaMemcpy(d_dst->state, h_src->state, count * sizeof(int), cudaMemcpyHostToDevice));
 
		gpuErrchk(cudaMemcpy(d_dst->sugar_level, h_src->sugar_level, count * sizeof(int), cudaMemcpyHostToDevice));
 
		gpuErrchk(cudaMemcpy(d_dst->metabolism, h_src->metabolism, count * sizeof(int), cudaMemcpyHostToDevice));
 
		gpuErrchk(cudaMemcpy(d_dst->env_sugar_level, h_src->env_sugar_level, count * sizeof(int), cudaMemcpyHostToDevice));
 
		gpuErrchk(cudaMemcpy(d_dst->max_env_sugar_level, h_src->max_env_sugar_level, count * sizeof(int), cudaMemcpyHostToDevice));

    }
}

xmachine_memory_Agent* h_allocate_agent_Agent(){
	xmachine_memory_Agent* agent = (xmachine_memory_Agent*)malloc(sizeof(xmachine_memory_Agent));
	// Memset the whole agent strcuture
    memset(agent, 0, sizeof(xmachine_memory_Agent));

	return agent;
}
void h_free_agent_Agent(xmachine_memory_Agent** agent){
 
	free((*agent));
	(*agent) = NULL;
}
xmachine_memory_Agent** h_allocate_agent_Agent_array(unsigned int count){
	xmachine_memory_Agent ** agents = (xmachine_memory_Agent**)malloc(count * sizeof(xmachine_memory_Agent*));
	for (unsigned int i = 0; i < count; i++) {
		agents[i] = h_allocate_agent_Agent();
	}
	return agents;
}
void h_free_agent_Agent_array(xmachine_memory_Agent*** agents, unsigned int count){
	for (unsigned int i = 0; i < count; i++) {
		h_free_agent_Agent(&((*agents)[i]));
	}
	free((*agents));
	(*agents) = NULL;
}

void h_unpack_agents_Agent_AoS_to_SoA(xmachine_memory_Agent_list * dst, xmachine_memory_Agent** src, unsigned int count){
	if(count > 0){
		for(unsigned int i = 0; i < count; i++){
			 
			dst->x[i] = src[i]->x;
			 
			dst->y[i] = src[i]->y;
			 
			dst->z[i] = src[i]->z;
			 
			dst->target_pos_x[i] = src[i]->target_pos_x;
			 
			dst->target_pos_y[i] = src[i]->target_pos_y;
			 
			dst->agent_id[i] = src[i]->agent_id;
			 
			dst->state[i] = src[i]->state;
			 
			dst->sugar_level[i] = src[i]->sugar_level;
			 
			dst->metabolism[i] = src[i]->metabolism;
			 
			dst->env_sugar_level[i] = src[i]->env_sugar_level;
			 
			dst->max_env_sugar_level[i] = src[i]->max_env_sugar_level;
			
		}
	}
}


void h_add_agent_Agent_Agent_default(xmachine_memory_Agent* agent){
	if (h_xmachine_memory_Agent_count + 1 > xmachine_memory_Agent_MAX){
		printf("Error: Buffer size of Agent agents in state Agent_default will be exceeded by h_add_agent_Agent_Agent_default\n");
		exit(EXIT_FAILURE);
	}	

	int blockSize;
	int minGridSize;
	int gridSize;
	unsigned int count = 1;
	
	// Copy data from host struct to device SoA for target state
	copy_single_xmachine_memory_Agent_hostToDevice(d_Agents_new, agent);

	// Use append kernel (@optimisation - This can be replaced with a pointer swap if the target state list is empty)
	cudaOccupancyMaxPotentialBlockSizeVariableSMem(&minGridSize, &blockSize, append_Agent_Agents, no_sm, count);
	gridSize = (count + blockSize - 1) / blockSize;
	append_Agent_Agents <<<gridSize, blockSize, 0, stream1 >>>(d_Agents_Agent_default, d_Agents_new, h_xmachine_memory_Agent_Agent_default_count, count);
	gpuErrchkLaunch();
	// Update the number of agents in this state.
	h_xmachine_memory_Agent_Agent_default_count += count;
	gpuErrchk(cudaMemcpyToSymbol(d_xmachine_memory_Agent_Agent_default_count, &h_xmachine_memory_Agent_Agent_default_count, sizeof(int)));
	cudaDeviceSynchronize();

    // Reset host variable status flags for the relevant agent state list as the device state list has been modified.
    h_Agents_Agent_default_variable_x_data_iteration = 0;
    h_Agents_Agent_default_variable_y_data_iteration = 0;
    h_Agents_Agent_default_variable_z_data_iteration = 0;
    h_Agents_Agent_default_variable_target_pos_x_data_iteration = 0;
    h_Agents_Agent_default_variable_target_pos_y_data_iteration = 0;
    h_Agents_Agent_default_variable_agent_id_data_iteration = 0;
    h_Agents_Agent_default_variable_state_data_iteration = 0;
    h_Agents_Agent_default_variable_sugar_level_data_iteration = 0;
    h_Agents_Agent_default_variable_metabolism_data_iteration = 0;
    h_Agents_Agent_default_variable_env_sugar_level_data_iteration = 0;
    h_Agents_Agent_default_variable_max_env_sugar_level_data_iteration = 0;
    

}
void h_add_agents_Agent_Agent_default(xmachine_memory_Agent** agents, unsigned int count){
	if(count > 0){
		int blockSize;
		int minGridSize;
		int gridSize;

		if (h_xmachine_memory_Agent_count + count > xmachine_memory_Agent_MAX){
			printf("Error: Buffer size of Agent agents in state Agent_default will be exceeded by h_add_agents_Agent_Agent_default\n");
			exit(EXIT_FAILURE);
		}

		// Unpack data from AoS into the pre-existing SoA
		h_unpack_agents_Agent_AoS_to_SoA(h_Agents_Agent_default, agents, count);

		// Copy data from the host SoA to the device SoA for the target state
		copy_partial_xmachine_memory_Agent_hostToDevice(d_Agents_new, h_Agents_Agent_default, count);

		// Use append kernel (@optimisation - This can be replaced with a pointer swap if the target state list is empty)
		cudaOccupancyMaxPotentialBlockSizeVariableSMem(&minGridSize, &blockSize, append_Agent_Agents, no_sm, count);
		gridSize = (count + blockSize - 1) / blockSize;
		append_Agent_Agents <<<gridSize, blockSize, 0, stream1 >>>(d_Agents_Agent_default, d_Agents_new, h_xmachine_memory_Agent_Agent_default_count, count);
		gpuErrchkLaunch();
		// Update the number of agents in this state.
		h_xmachine_memory_Agent_Agent_default_count += count;
		gpuErrchk(cudaMemcpyToSymbol(d_xmachine_memory_Agent_Agent_default_count, &h_xmachine_memory_Agent_Agent_default_count, sizeof(int)));
		cudaDeviceSynchronize();

        // Reset host variable status flags for the relevant agent state list as the device state list has been modified.
        h_Agents_Agent_default_variable_x_data_iteration = 0;
        h_Agents_Agent_default_variable_y_data_iteration = 0;
        h_Agents_Agent_default_variable_z_data_iteration = 0;
        h_Agents_Agent_default_variable_target_pos_x_data_iteration = 0;
        h_Agents_Agent_default_variable_target_pos_y_data_iteration = 0;
        h_Agents_Agent_default_variable_agent_id_data_iteration = 0;
        h_Agents_Agent_default_variable_state_data_iteration = 0;
        h_Agents_Agent_default_variable_sugar_level_data_iteration = 0;
        h_Agents_Agent_default_variable_metabolism_data_iteration = 0;
        h_Agents_Agent_default_variable_env_sugar_level_data_iteration = 0;
        h_Agents_Agent_default_variable_max_env_sugar_level_data_iteration = 0;
        

	}
}


/*  Analytics Functions */

double reduce_Agent_Agent_default_x_variable(){
    //reduce in default stream
    return thrust::reduce(thrust::device_pointer_cast(d_Agents_Agent_default->x),  thrust::device_pointer_cast(d_Agents_Agent_default->x) + h_xmachine_memory_Agent_Agent_default_count);
}

double min_Agent_Agent_default_x_variable(){
    //min in default stream
    thrust::device_ptr<double> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->x);
    size_t result_offset = thrust::min_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
double max_Agent_Agent_default_x_variable(){
    //max in default stream
    thrust::device_ptr<double> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->x);
    size_t result_offset = thrust::max_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
double reduce_Agent_Agent_default_y_variable(){
    //reduce in default stream
    return thrust::reduce(thrust::device_pointer_cast(d_Agents_Agent_default->y),  thrust::device_pointer_cast(d_Agents_Agent_default->y) + h_xmachine_memory_Agent_Agent_default_count);
}

double min_Agent_Agent_default_y_variable(){
    //min in default stream
    thrust::device_ptr<double> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->y);
    size_t result_offset = thrust::min_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
double max_Agent_Agent_default_y_variable(){
    //max in default stream
    thrust::device_ptr<double> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->y);
    size_t result_offset = thrust::max_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
double reduce_Agent_Agent_default_z_variable(){
    //reduce in default stream
    return thrust::reduce(thrust::device_pointer_cast(d_Agents_Agent_default->z),  thrust::device_pointer_cast(d_Agents_Agent_default->z) + h_xmachine_memory_Agent_Agent_default_count);
}

double min_Agent_Agent_default_z_variable(){
    //min in default stream
    thrust::device_ptr<double> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->z);
    size_t result_offset = thrust::min_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
double max_Agent_Agent_default_z_variable(){
    //max in default stream
    thrust::device_ptr<double> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->z);
    size_t result_offset = thrust::max_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
double reduce_Agent_Agent_default_target_pos_x_variable(){
    //reduce in default stream
    return thrust::reduce(thrust::device_pointer_cast(d_Agents_Agent_default->target_pos_x),  thrust::device_pointer_cast(d_Agents_Agent_default->target_pos_x) + h_xmachine_memory_Agent_Agent_default_count);
}

double min_Agent_Agent_default_target_pos_x_variable(){
    //min in default stream
    thrust::device_ptr<double> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->target_pos_x);
    size_t result_offset = thrust::min_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
double max_Agent_Agent_default_target_pos_x_variable(){
    //max in default stream
    thrust::device_ptr<double> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->target_pos_x);
    size_t result_offset = thrust::max_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
double reduce_Agent_Agent_default_target_pos_y_variable(){
    //reduce in default stream
    return thrust::reduce(thrust::device_pointer_cast(d_Agents_Agent_default->target_pos_y),  thrust::device_pointer_cast(d_Agents_Agent_default->target_pos_y) + h_xmachine_memory_Agent_Agent_default_count);
}

double min_Agent_Agent_default_target_pos_y_variable(){
    //min in default stream
    thrust::device_ptr<double> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->target_pos_y);
    size_t result_offset = thrust::min_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
double max_Agent_Agent_default_target_pos_y_variable(){
    //max in default stream
    thrust::device_ptr<double> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->target_pos_y);
    size_t result_offset = thrust::max_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
int reduce_Agent_Agent_default_agent_id_variable(){
    //reduce in default stream
    return thrust::reduce(thrust::device_pointer_cast(d_Agents_Agent_default->agent_id),  thrust::device_pointer_cast(d_Agents_Agent_default->agent_id) + h_xmachine_memory_Agent_Agent_default_count);
}

int count_Agent_Agent_default_agent_id_variable(int count_value){
    //count in default stream
    return (int)thrust::count(thrust::device_pointer_cast(d_Agents_Agent_default->agent_id),  thrust::device_pointer_cast(d_Agents_Agent_default->agent_id) + h_xmachine_memory_Agent_Agent_default_count, count_value);
}
int min_Agent_Agent_default_agent_id_variable(){
    //min in default stream
    thrust::device_ptr<int> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->agent_id);
    size_t result_offset = thrust::min_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
int max_Agent_Agent_default_agent_id_variable(){
    //max in default stream
    thrust::device_ptr<int> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->agent_id);
    size_t result_offset = thrust::max_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
int reduce_Agent_Agent_default_state_variable(){
    //reduce in default stream
    return thrust::reduce(thrust::device_pointer_cast(d_Agents_Agent_default->state),  thrust::device_pointer_cast(d_Agents_Agent_default->state) + h_xmachine_memory_Agent_Agent_default_count);
}

int count_Agent_Agent_default_state_variable(int count_value){
    //count in default stream
    return (int)thrust::count(thrust::device_pointer_cast(d_Agents_Agent_default->state),  thrust::device_pointer_cast(d_Agents_Agent_default->state) + h_xmachine_memory_Agent_Agent_default_count, count_value);
}
int min_Agent_Agent_default_state_variable(){
    //min in default stream
    thrust::device_ptr<int> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->state);
    size_t result_offset = thrust::min_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
int max_Agent_Agent_default_state_variable(){
    //max in default stream
    thrust::device_ptr<int> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->state);
    size_t result_offset = thrust::max_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
int reduce_Agent_Agent_default_sugar_level_variable(){
    //reduce in default stream
    return thrust::reduce(thrust::device_pointer_cast(d_Agents_Agent_default->sugar_level),  thrust::device_pointer_cast(d_Agents_Agent_default->sugar_level) + h_xmachine_memory_Agent_Agent_default_count);
}

int count_Agent_Agent_default_sugar_level_variable(int count_value){
    //count in default stream
    return (int)thrust::count(thrust::device_pointer_cast(d_Agents_Agent_default->sugar_level),  thrust::device_pointer_cast(d_Agents_Agent_default->sugar_level) + h_xmachine_memory_Agent_Agent_default_count, count_value);
}
int min_Agent_Agent_default_sugar_level_variable(){
    //min in default stream
    thrust::device_ptr<int> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->sugar_level);
    size_t result_offset = thrust::min_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
int max_Agent_Agent_default_sugar_level_variable(){
    //max in default stream
    thrust::device_ptr<int> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->sugar_level);
    size_t result_offset = thrust::max_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
int reduce_Agent_Agent_default_metabolism_variable(){
    //reduce in default stream
    return thrust::reduce(thrust::device_pointer_cast(d_Agents_Agent_default->metabolism),  thrust::device_pointer_cast(d_Agents_Agent_default->metabolism) + h_xmachine_memory_Agent_Agent_default_count);
}

int count_Agent_Agent_default_metabolism_variable(int count_value){
    //count in default stream
    return (int)thrust::count(thrust::device_pointer_cast(d_Agents_Agent_default->metabolism),  thrust::device_pointer_cast(d_Agents_Agent_default->metabolism) + h_xmachine_memory_Agent_Agent_default_count, count_value);
}
int min_Agent_Agent_default_metabolism_variable(){
    //min in default stream
    thrust::device_ptr<int> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->metabolism);
    size_t result_offset = thrust::min_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
int max_Agent_Agent_default_metabolism_variable(){
    //max in default stream
    thrust::device_ptr<int> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->metabolism);
    size_t result_offset = thrust::max_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
int reduce_Agent_Agent_default_env_sugar_level_variable(){
    //reduce in default stream
    return thrust::reduce(thrust::device_pointer_cast(d_Agents_Agent_default->env_sugar_level),  thrust::device_pointer_cast(d_Agents_Agent_default->env_sugar_level) + h_xmachine_memory_Agent_Agent_default_count);
}

int count_Agent_Agent_default_env_sugar_level_variable(int count_value){
    //count in default stream
    return (int)thrust::count(thrust::device_pointer_cast(d_Agents_Agent_default->env_sugar_level),  thrust::device_pointer_cast(d_Agents_Agent_default->env_sugar_level) + h_xmachine_memory_Agent_Agent_default_count, count_value);
}
int min_Agent_Agent_default_env_sugar_level_variable(){
    //min in default stream
    thrust::device_ptr<int> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->env_sugar_level);
    size_t result_offset = thrust::min_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
int max_Agent_Agent_default_env_sugar_level_variable(){
    //max in default stream
    thrust::device_ptr<int> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->env_sugar_level);
    size_t result_offset = thrust::max_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
int reduce_Agent_Agent_default_max_env_sugar_level_variable(){
    //reduce in default stream
    return thrust::reduce(thrust::device_pointer_cast(d_Agents_Agent_default->max_env_sugar_level),  thrust::device_pointer_cast(d_Agents_Agent_default->max_env_sugar_level) + h_xmachine_memory_Agent_Agent_default_count);
}

int count_Agent_Agent_default_max_env_sugar_level_variable(int count_value){
    //count in default stream
    return (int)thrust::count(thrust::device_pointer_cast(d_Agents_Agent_default->max_env_sugar_level),  thrust::device_pointer_cast(d_Agents_Agent_default->max_env_sugar_level) + h_xmachine_memory_Agent_Agent_default_count, count_value);
}
int min_Agent_Agent_default_max_env_sugar_level_variable(){
    //min in default stream
    thrust::device_ptr<int> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->max_env_sugar_level);
    size_t result_offset = thrust::min_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}
int max_Agent_Agent_default_max_env_sugar_level_variable(){
    //max in default stream
    thrust::device_ptr<int> thrust_ptr = thrust::device_pointer_cast(d_Agents_Agent_default->max_env_sugar_level);
    size_t result_offset = thrust::max_element(thrust_ptr, thrust_ptr + h_xmachine_memory_Agent_Agent_default_count) - thrust_ptr;
    return *(thrust_ptr + result_offset);
}



/* Agent functions */


	
/* Shared memory size calculator for agent function */
int Agent_metabolise_and_growback_sm_size(int blockSize){
	int sm_size;
	sm_size = SM_START;
  
	return sm_size;
}

/** Agent_metabolise_and_growback
 * Agent function prototype for metabolise_and_growback function of Agent agent
 */
void Agent_metabolise_and_growback(cudaStream_t &stream){

    int sm_size;
    int blockSize;
    int minGridSize;
    int gridSize;
    int state_list_size;
	dim3 g; //grid for agent func
	dim3 b; //block for agent func

	
	//CHECK THE CURRENT STATE LIST COUNT IS NOT EQUAL TO 0
	
	if (h_xmachine_memory_Agent_Agent_default_count == 0)
	{
		return;
	}
	
	
	//SET SM size to 0 and save state list size for occupancy calculations
	sm_size = SM_START;
	state_list_size = h_xmachine_memory_Agent_Agent_default_count;

	

	//******************************** AGENT FUNCTION CONDITION *********************
	//THERE IS NOT A FUNCTION CONDITION
	//currentState maps to working list
	xmachine_memory_Agent_list* Agents_Agent_default_temp = d_Agents;
	d_Agents = d_Agents_Agent_default;
	d_Agents_Agent_default = Agents_Agent_default_temp;
	//set working count to current state count
	h_xmachine_memory_Agent_count = h_xmachine_memory_Agent_Agent_default_count;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_count, &h_xmachine_memory_Agent_count, sizeof(int)));	
	//set current state count to 0
	h_xmachine_memory_Agent_Agent_default_count = 0;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_Agent_default_count, &h_xmachine_memory_Agent_Agent_default_count, sizeof(int)));	
	
 

	//******************************** AGENT FUNCTION *******************************

	
	
	//calculate the grid block size for main agent function
	cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, GPUFLAME_metabolise_and_growback, Agent_metabolise_and_growback_sm_size, state_list_size);
	gridSize = (state_list_size + blockSize - 1) / blockSize;
	b.x = blockSize;
	g.x = gridSize;
	
	sm_size = Agent_metabolise_and_growback_sm_size(blockSize);
	
	
	
	
	//MAIN XMACHINE FUNCTION CALL (metabolise_and_growback)
	//Reallocate   : false
	//Input        : 
	//Output       : 
	//Agent Output : 
	GPUFLAME_metabolise_and_growback<<<g, b, sm_size, stream>>>(d_Agents);
	gpuErrchkLaunch();
	
	
	
	//************************ MOVE AGENTS TO NEXT STATE ****************************
    
	//check the working agents wont exceed the buffer size in the new state list
	if (h_xmachine_memory_Agent_Agent_default_count+h_xmachine_memory_Agent_count > xmachine_memory_Agent_MAX){
		printf("Error: Buffer size of metabolise_and_growback agents in state Agent_default will be exceeded moving working agents to next state in function metabolise_and_growback\n");
      exit(EXIT_FAILURE);
      }
      
  //pointer swap the updated data
  Agents_Agent_default_temp = d_Agents;
  d_Agents = d_Agents_Agent_default;
  d_Agents_Agent_default = Agents_Agent_default_temp;
        
	//update new state agent size
	h_xmachine_memory_Agent_Agent_default_count += h_xmachine_memory_Agent_count;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_Agent_default_count, &h_xmachine_memory_Agent_Agent_default_count, sizeof(int)));	
	
	
}



	
/* Shared memory size calculator for agent function */
int Agent_movement_request_gen_sm_size(int blockSize){
	int sm_size;
	sm_size = SM_START;
  
	return sm_size;
}

/** Agent_movement_request_gen
 * Agent function prototype for movement_request_gen function of Agent agent
 */
void Agent_movement_request_gen(cudaStream_t &stream){

    int sm_size;
    int blockSize;
    int minGridSize;
    int gridSize;
    int state_list_size;
	dim3 g; //grid for agent func
	dim3 b; //block for agent func

	
	//CHECK THE CURRENT STATE LIST COUNT IS NOT EQUAL TO 0
	
	if (h_xmachine_memory_Agent_Agent_default_count == 0)
	{
		return;
	}
	
	
	//SET SM size to 0 and save state list size for occupancy calculations
	sm_size = SM_START;
	state_list_size = h_xmachine_memory_Agent_Agent_default_count;

	

	//******************************** AGENT FUNCTION CONDITION *********************
	//THERE IS NOT A FUNCTION CONDITION
	//currentState maps to working list
	xmachine_memory_Agent_list* Agents_Agent_default_temp = d_Agents;
	d_Agents = d_Agents_Agent_default;
	d_Agents_Agent_default = Agents_Agent_default_temp;
	//set working count to current state count
	h_xmachine_memory_Agent_count = h_xmachine_memory_Agent_Agent_default_count;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_count, &h_xmachine_memory_Agent_count, sizeof(int)));	
	//set current state count to 0
	h_xmachine_memory_Agent_Agent_default_count = 0;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_Agent_default_count, &h_xmachine_memory_Agent_Agent_default_count, sizeof(int)));	
	
 

	//******************************** AGENT FUNCTION *******************************

	
	//CONTINUOUS AGENT CHECK FUNCTION OUTPUT BUFFERS FOR OUT OF BOUNDS
	if (h_message_movement_request_message_count + h_xmachine_memory_Agent_count > xmachine_message_movement_request_message_MAX){
		printf("Error: Buffer size of movement_request_message message will be exceeded in function movement_request_gen\n");
		exit(EXIT_FAILURE);
	}
	
	
	//calculate the grid block size for main agent function
	cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, GPUFLAME_movement_request_gen, Agent_movement_request_gen_sm_size, state_list_size);
	gridSize = (state_list_size + blockSize - 1) / blockSize;
	b.x = blockSize;
	g.x = gridSize;
	
	sm_size = Agent_movement_request_gen_sm_size(blockSize);
	
	
	
	//SET THE OUTPUT MESSAGE TYPE FOR CONTINUOUS AGENTS
	//Set the message_type for non partitioned, spatially partitioned and On-Graph Partitioned message outputs
	h_message_movement_request_message_output_type = single_message;
	gpuErrchk( cudaMemcpyToSymbol( d_message_movement_request_message_output_type, &h_message_movement_request_message_output_type, sizeof(int)));
	
	
	//MAIN XMACHINE FUNCTION CALL (movement_request_gen)
	//Reallocate   : false
	//Input        : 
	//Output       : movement_request_message
	//Agent Output : 
	GPUFLAME_movement_request_gen<<<g, b, sm_size, stream>>>(d_Agents, d_movement_request_messages);
	gpuErrchkLaunch();
	
	
	//CONTINUOUS AGENTS SCATTER NON PARTITIONED OPTIONAL OUTPUT MESSAGES
	
	//UPDATE MESSAGE COUNTS FOR CONTINUOUS AGENTS WITH NON PARTITIONED MESSAGE OUTPUT 
	h_message_movement_request_message_count += h_xmachine_memory_Agent_count;
	//Copy count to device
	gpuErrchk( cudaMemcpyToSymbol( d_message_movement_request_message_count, &h_message_movement_request_message_count, sizeof(int)));	
	
	//reset partition matrix
	gpuErrchk( cudaMemset( (void*) d_movement_request_message_partition_matrix, 0, sizeof(xmachine_message_movement_request_message_PBM)));
    //PR Bug fix: Second fix. This should prevent future problems when multiple agents write the same message as now the message structure is completely rebuilt after an output.
    if (h_message_movement_request_message_count > 0){
#ifdef FAST_ATOMIC_SORTING
      //USE ATOMICS TO BUILD PARTITION BOUNDARY
	  cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, hist_movement_request_message_messages, no_sm, h_message_movement_request_message_count); 
	  gridSize = (h_message_movement_request_message_count + blockSize - 1) / blockSize;
	  hist_movement_request_message_messages<<<gridSize, blockSize, 0, stream>>>(d_xmachine_message_movement_request_message_local_bin_index, d_xmachine_message_movement_request_message_unsorted_index, d_movement_request_message_partition_matrix->end_or_count, d_movement_request_messages, h_message_movement_request_message_count);
	  gpuErrchkLaunch();
	
      // Scan
      cub::DeviceScan::ExclusiveSum(
          d_temp_scan_storage_xmachine_message_movement_request_message, 
          temp_scan_bytes_xmachine_message_movement_request_message, 
          d_movement_request_message_partition_matrix->end_or_count,
          d_movement_request_message_partition_matrix->start,
          xmachine_message_movement_request_message_grid_size, 
          stream
      );
	
	  cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, reorder_movement_request_message_messages, no_sm, h_message_movement_request_message_count); 
	  gridSize = (h_message_movement_request_message_count + blockSize - 1) / blockSize; 	// Round up according to array size 
	  reorder_movement_request_message_messages <<<gridSize, blockSize, 0, stream>>>(d_xmachine_message_movement_request_message_local_bin_index, d_xmachine_message_movement_request_message_unsorted_index, d_movement_request_message_partition_matrix->start, d_movement_request_messages, d_movement_request_messages_swap, h_message_movement_request_message_count);
	  gpuErrchkLaunch();
#else
	  //HASH, SORT, REORDER AND BUILD PMB FOR SPATIAL PARTITIONING MESSAGE OUTPUTS
	  //Get message hash values for sorting
	  cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, hash_movement_request_message_messages, no_sm, h_message_movement_request_message_count); 
	  gridSize = (h_message_movement_request_message_count + blockSize - 1) / blockSize;
	  hash_movement_request_message_messages<<<gridSize, blockSize, 0, stream>>>(d_xmachine_message_movement_request_message_keys, d_xmachine_message_movement_request_message_values, d_movement_request_messages);
    gpuErrchkLaunch();
    //Sort
    cub::DeviceRadixSort::SortPairs(d_CUB_temp_storage_movement_request_message, CUB_temp_storage_bytes_movement_request_message, d_xmachine_message_movement_request_message_keys, d_xmachine_message_movement_request_message_keys_swap, d_xmachine_message_movement_request_message_values, d_xmachine_message_movement_request_message_values_swap, h_message_movement_request_message_count, 0, binCountBits_movement_request_message, stream);
    {
    unsigned int *_t = d_xmachine_message_movement_request_message_keys;
    d_xmachine_message_movement_request_message_keys = d_xmachine_message_movement_request_message_keys_swap;
    d_xmachine_message_movement_request_message_keys_swap = _t;
    }
    {
    unsigned int *_t = d_xmachine_message_movement_request_message_values;
    d_xmachine_message_movement_request_message_values = d_xmachine_message_movement_request_message_values_swap;
    d_xmachine_message_movement_request_message_values_swap = _t;
    }
    gpuErrchkLaunch();
    //reorder and build pcb
    gpuErrchk(cudaMemset(d_movement_request_message_partition_matrix->start, 0xffffffff, xmachine_message_movement_request_message_grid_size* sizeof(int)));
	  cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, reorder_movement_request_message_messages, reorder_messages_sm_size, h_message_movement_request_message_count); 
	  gridSize = (h_message_movement_request_message_count + blockSize - 1) / blockSize;
	  int reorder_sm_size = reorder_messages_sm_size(blockSize);
	  reorder_movement_request_message_messages<<<gridSize, blockSize, reorder_sm_size, stream>>>(d_xmachine_message_movement_request_message_keys, d_xmachine_message_movement_request_message_values, d_movement_request_message_partition_matrix, d_movement_request_messages, d_movement_request_messages_swap);
	  gpuErrchkLaunch();
#endif
  }
	//swap ordered list
	xmachine_message_movement_request_message_list* d_movement_request_messages_temp = d_movement_request_messages;
	d_movement_request_messages = d_movement_request_messages_swap;
	d_movement_request_messages_swap = d_movement_request_messages_temp;
	
	
	//************************ MOVE AGENTS TO NEXT STATE ****************************
    
	//check the working agents wont exceed the buffer size in the new state list
	if (h_xmachine_memory_Agent_Agent_default_count+h_xmachine_memory_Agent_count > xmachine_memory_Agent_MAX){
		printf("Error: Buffer size of movement_request_gen agents in state Agent_default will be exceeded moving working agents to next state in function movement_request_gen\n");
      exit(EXIT_FAILURE);
      }
      
  //pointer swap the updated data
  Agents_Agent_default_temp = d_Agents;
  d_Agents = d_Agents_Agent_default;
  d_Agents_Agent_default = Agents_Agent_default_temp;
        
	//update new state agent size
	h_xmachine_memory_Agent_Agent_default_count += h_xmachine_memory_Agent_count;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_Agent_default_count, &h_xmachine_memory_Agent_Agent_default_count, sizeof(int)));	
	
	
}



	
/* Shared memory size calculator for agent function */
int Agent_movement_request_sm_size(int blockSize){
	int sm_size;
	sm_size = SM_START;
  //Continuous agent and message input is spatially partitioned
	sm_size += (blockSize * sizeof(xmachine_message_movement_request_message));
	
	//all continuous agent types require single 32bit word per thread offset (to avoid sm bank conflicts)
	sm_size += (blockSize * PADDING);
	
	return sm_size;
}

/** Agent_movement_request
 * Agent function prototype for movement_request function of Agent agent
 */
void Agent_movement_request(cudaStream_t &stream){

    int sm_size;
    int blockSize;
    int minGridSize;
    int gridSize;
    int state_list_size;
	dim3 g; //grid for agent func
	dim3 b; //block for agent func

	
	//CHECK THE CURRENT STATE LIST COUNT IS NOT EQUAL TO 0
	
	if (h_xmachine_memory_Agent_Agent_default_count == 0)
	{
		return;
	}
	
	
	//SET SM size to 0 and save state list size for occupancy calculations
	sm_size = SM_START;
	state_list_size = h_xmachine_memory_Agent_Agent_default_count;

	

	//******************************** AGENT FUNCTION CONDITION *********************
	//THERE IS NOT A FUNCTION CONDITION
	//currentState maps to working list
	xmachine_memory_Agent_list* Agents_Agent_default_temp = d_Agents;
	d_Agents = d_Agents_Agent_default;
	d_Agents_Agent_default = Agents_Agent_default_temp;
	//set working count to current state count
	h_xmachine_memory_Agent_count = h_xmachine_memory_Agent_Agent_default_count;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_count, &h_xmachine_memory_Agent_count, sizeof(int)));	
	//set current state count to 0
	h_xmachine_memory_Agent_Agent_default_count = 0;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_Agent_default_count, &h_xmachine_memory_Agent_Agent_default_count, sizeof(int)));	
	
 

	//******************************** AGENT FUNCTION *******************************

	
	
	//calculate the grid block size for main agent function
	cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, GPUFLAME_movement_request, Agent_movement_request_sm_size, state_list_size);
	gridSize = (state_list_size + blockSize - 1) / blockSize;
	b.x = blockSize;
	g.x = gridSize;
	
	sm_size = Agent_movement_request_sm_size(blockSize);
	
	
	
	//BIND APPROPRIATE MESSAGE INPUT VARIABLES TO TEXTURES (to make use of the texture cache)
	//any agent with discrete or partitioned message input uses texture caching
	size_t tex_xmachine_message_movement_request_message_x_byte_offset;    
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_request_message_x_byte_offset, tex_xmachine_message_movement_request_message_x, d_movement_request_messages->x, sizeof(double)*xmachine_message_movement_request_message_MAX));
	h_tex_xmachine_message_movement_request_message_x_offset = (int)tex_xmachine_message_movement_request_message_x_byte_offset / sizeof(double);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_request_message_x_offset, &h_tex_xmachine_message_movement_request_message_x_offset, sizeof(int)));
	size_t tex_xmachine_message_movement_request_message_y_byte_offset;    
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_request_message_y_byte_offset, tex_xmachine_message_movement_request_message_y, d_movement_request_messages->y, sizeof(double)*xmachine_message_movement_request_message_MAX));
	h_tex_xmachine_message_movement_request_message_y_offset = (int)tex_xmachine_message_movement_request_message_y_byte_offset / sizeof(double);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_request_message_y_offset, &h_tex_xmachine_message_movement_request_message_y_offset, sizeof(int)));
	size_t tex_xmachine_message_movement_request_message_z_byte_offset;    
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_request_message_z_byte_offset, tex_xmachine_message_movement_request_message_z, d_movement_request_messages->z, sizeof(double)*xmachine_message_movement_request_message_MAX));
	h_tex_xmachine_message_movement_request_message_z_offset = (int)tex_xmachine_message_movement_request_message_z_byte_offset / sizeof(double);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_request_message_z_offset, &h_tex_xmachine_message_movement_request_message_z_offset, sizeof(int)));
	size_t tex_xmachine_message_movement_request_message_state_byte_offset;    
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_request_message_state_byte_offset, tex_xmachine_message_movement_request_message_state, d_movement_request_messages->state, sizeof(int)*xmachine_message_movement_request_message_MAX));
	h_tex_xmachine_message_movement_request_message_state_offset = (int)tex_xmachine_message_movement_request_message_state_byte_offset / sizeof(int);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_request_message_state_offset, &h_tex_xmachine_message_movement_request_message_state_offset, sizeof(int)));
	size_t tex_xmachine_message_movement_request_message_env_sugar_level_byte_offset;    
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_request_message_env_sugar_level_byte_offset, tex_xmachine_message_movement_request_message_env_sugar_level, d_movement_request_messages->env_sugar_level, sizeof(int)*xmachine_message_movement_request_message_MAX));
	h_tex_xmachine_message_movement_request_message_env_sugar_level_offset = (int)tex_xmachine_message_movement_request_message_env_sugar_level_byte_offset / sizeof(int);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_request_message_env_sugar_level_offset, &h_tex_xmachine_message_movement_request_message_env_sugar_level_offset, sizeof(int)));
	//bind pbm start and end indices to textures
	size_t tex_xmachine_message_movement_request_message_pbm_start_byte_offset;
	size_t tex_xmachine_message_movement_request_message_pbm_end_or_count_byte_offset;
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_request_message_pbm_start_byte_offset, tex_xmachine_message_movement_request_message_pbm_start, d_movement_request_message_partition_matrix->start, sizeof(int)*xmachine_message_movement_request_message_grid_size));
	h_tex_xmachine_message_movement_request_message_pbm_start_offset = (int)tex_xmachine_message_movement_request_message_pbm_start_byte_offset / sizeof(int);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_request_message_pbm_start_offset, &h_tex_xmachine_message_movement_request_message_pbm_start_offset, sizeof(int)));
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_request_message_pbm_end_or_count_byte_offset, tex_xmachine_message_movement_request_message_pbm_end_or_count, d_movement_request_message_partition_matrix->end_or_count, sizeof(int)*xmachine_message_movement_request_message_grid_size));
  h_tex_xmachine_message_movement_request_message_pbm_end_or_count_offset = (int)tex_xmachine_message_movement_request_message_pbm_end_or_count_byte_offset / sizeof(int);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_request_message_pbm_end_or_count_offset, &h_tex_xmachine_message_movement_request_message_pbm_end_or_count_offset, sizeof(int)));

	
	
	//MAIN XMACHINE FUNCTION CALL (movement_request)
	//Reallocate   : false
	//Input        : movement_request_message
	//Output       : 
	//Agent Output : 
	GPUFLAME_movement_request<<<g, b, sm_size, stream>>>(d_Agents, d_movement_request_messages, d_movement_request_message_partition_matrix);
	gpuErrchkLaunch();
	
	
	//UNBIND MESSAGE INPUT VARIABLE TEXTURES
	//any agent with discrete or partitioned message input uses texture caching
	gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_request_message_x));
	gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_request_message_y));
	gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_request_message_z));
	gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_request_message_state));
	gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_request_message_env_sugar_level));
	//unbind pbm indices
    gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_request_message_pbm_start));
    gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_request_message_pbm_end_or_count));
    
	
	//************************ MOVE AGENTS TO NEXT STATE ****************************
    
	//check the working agents wont exceed the buffer size in the new state list
	if (h_xmachine_memory_Agent_Agent_default_count+h_xmachine_memory_Agent_count > xmachine_memory_Agent_MAX){
		printf("Error: Buffer size of movement_request agents in state Agent_default will be exceeded moving working agents to next state in function movement_request\n");
      exit(EXIT_FAILURE);
      }
      
  //pointer swap the updated data
  Agents_Agent_default_temp = d_Agents;
  d_Agents = d_Agents_Agent_default;
  d_Agents_Agent_default = Agents_Agent_default_temp;
        
	//update new state agent size
	h_xmachine_memory_Agent_Agent_default_count += h_xmachine_memory_Agent_count;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_Agent_default_count, &h_xmachine_memory_Agent_Agent_default_count, sizeof(int)));	
	
	
}



	
/* Shared memory size calculator for agent function */
int Agent_movement_response_gen_sm_size(int blockSize){
	int sm_size;
	sm_size = SM_START;
  
	return sm_size;
}

/** Agent_movement_response_gen
 * Agent function prototype for movement_response_gen function of Agent agent
 */
void Agent_movement_response_gen(cudaStream_t &stream){

    int sm_size;
    int blockSize;
    int minGridSize;
    int gridSize;
    int state_list_size;
	dim3 g; //grid for agent func
	dim3 b; //block for agent func

	
	//CHECK THE CURRENT STATE LIST COUNT IS NOT EQUAL TO 0
	
	if (h_xmachine_memory_Agent_Agent_default_count == 0)
	{
		return;
	}
	
	
	//SET SM size to 0 and save state list size for occupancy calculations
	sm_size = SM_START;
	state_list_size = h_xmachine_memory_Agent_Agent_default_count;

	

	//******************************** AGENT FUNCTION CONDITION *********************
	//THERE IS NOT A FUNCTION CONDITION
	//currentState maps to working list
	xmachine_memory_Agent_list* Agents_Agent_default_temp = d_Agents;
	d_Agents = d_Agents_Agent_default;
	d_Agents_Agent_default = Agents_Agent_default_temp;
	//set working count to current state count
	h_xmachine_memory_Agent_count = h_xmachine_memory_Agent_Agent_default_count;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_count, &h_xmachine_memory_Agent_count, sizeof(int)));	
	//set current state count to 0
	h_xmachine_memory_Agent_Agent_default_count = 0;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_Agent_default_count, &h_xmachine_memory_Agent_Agent_default_count, sizeof(int)));	
	
 

	//******************************** AGENT FUNCTION *******************************

	
	//CONTINUOUS AGENT CHECK FUNCTION OUTPUT BUFFERS FOR OUT OF BOUNDS
	if (h_message_movement_response_message_count + h_xmachine_memory_Agent_count > xmachine_message_movement_response_message_MAX){
		printf("Error: Buffer size of movement_response_message message will be exceeded in function movement_response_gen\n");
		exit(EXIT_FAILURE);
	}
	
	
	//calculate the grid block size for main agent function
	cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, GPUFLAME_movement_response_gen, Agent_movement_response_gen_sm_size, state_list_size);
	gridSize = (state_list_size + blockSize - 1) / blockSize;
	b.x = blockSize;
	g.x = gridSize;
	
	sm_size = Agent_movement_response_gen_sm_size(blockSize);
	
	
	
	//SET THE OUTPUT MESSAGE TYPE FOR CONTINUOUS AGENTS
	//Set the message_type for non partitioned, spatially partitioned and On-Graph Partitioned message outputs
	h_message_movement_response_message_output_type = single_message;
	gpuErrchk( cudaMemcpyToSymbol( d_message_movement_response_message_output_type, &h_message_movement_response_message_output_type, sizeof(int)));
	
	
	//MAIN XMACHINE FUNCTION CALL (movement_response_gen)
	//Reallocate   : false
	//Input        : 
	//Output       : movement_response_message
	//Agent Output : 
	GPUFLAME_movement_response_gen<<<g, b, sm_size, stream>>>(d_Agents, d_movement_response_messages);
	gpuErrchkLaunch();
	
	
	//CONTINUOUS AGENTS SCATTER NON PARTITIONED OPTIONAL OUTPUT MESSAGES
	
	//UPDATE MESSAGE COUNTS FOR CONTINUOUS AGENTS WITH NON PARTITIONED MESSAGE OUTPUT 
	h_message_movement_response_message_count += h_xmachine_memory_Agent_count;
	//Copy count to device
	gpuErrchk( cudaMemcpyToSymbol( d_message_movement_response_message_count, &h_message_movement_response_message_count, sizeof(int)));	
	
	//reset partition matrix
	gpuErrchk( cudaMemset( (void*) d_movement_response_message_partition_matrix, 0, sizeof(xmachine_message_movement_response_message_PBM)));
    //PR Bug fix: Second fix. This should prevent future problems when multiple agents write the same message as now the message structure is completely rebuilt after an output.
    if (h_message_movement_response_message_count > 0){
#ifdef FAST_ATOMIC_SORTING
      //USE ATOMICS TO BUILD PARTITION BOUNDARY
	  cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, hist_movement_response_message_messages, no_sm, h_message_movement_response_message_count); 
	  gridSize = (h_message_movement_response_message_count + blockSize - 1) / blockSize;
	  hist_movement_response_message_messages<<<gridSize, blockSize, 0, stream>>>(d_xmachine_message_movement_response_message_local_bin_index, d_xmachine_message_movement_response_message_unsorted_index, d_movement_response_message_partition_matrix->end_or_count, d_movement_response_messages, h_message_movement_response_message_count);
	  gpuErrchkLaunch();
	
      // Scan
      cub::DeviceScan::ExclusiveSum(
          d_temp_scan_storage_xmachine_message_movement_response_message, 
          temp_scan_bytes_xmachine_message_movement_response_message, 
          d_movement_response_message_partition_matrix->end_or_count,
          d_movement_response_message_partition_matrix->start,
          xmachine_message_movement_response_message_grid_size, 
          stream
      );
	
	  cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, reorder_movement_response_message_messages, no_sm, h_message_movement_response_message_count); 
	  gridSize = (h_message_movement_response_message_count + blockSize - 1) / blockSize; 	// Round up according to array size 
	  reorder_movement_response_message_messages <<<gridSize, blockSize, 0, stream>>>(d_xmachine_message_movement_response_message_local_bin_index, d_xmachine_message_movement_response_message_unsorted_index, d_movement_response_message_partition_matrix->start, d_movement_response_messages, d_movement_response_messages_swap, h_message_movement_response_message_count);
	  gpuErrchkLaunch();
#else
	  //HASH, SORT, REORDER AND BUILD PMB FOR SPATIAL PARTITIONING MESSAGE OUTPUTS
	  //Get message hash values for sorting
	  cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, hash_movement_response_message_messages, no_sm, h_message_movement_response_message_count); 
	  gridSize = (h_message_movement_response_message_count + blockSize - 1) / blockSize;
	  hash_movement_response_message_messages<<<gridSize, blockSize, 0, stream>>>(d_xmachine_message_movement_response_message_keys, d_xmachine_message_movement_response_message_values, d_movement_response_messages);
    gpuErrchkLaunch();
    //Sort
    cub::DeviceRadixSort::SortPairs(d_CUB_temp_storage_movement_response_message, CUB_temp_storage_bytes_movement_response_message, d_xmachine_message_movement_response_message_keys, d_xmachine_message_movement_response_message_keys_swap, d_xmachine_message_movement_response_message_values, d_xmachine_message_movement_response_message_values_swap, h_message_movement_response_message_count, 0, binCountBits_movement_response_message, stream);
    {
    unsigned int *_t = d_xmachine_message_movement_response_message_keys;
    d_xmachine_message_movement_response_message_keys = d_xmachine_message_movement_response_message_keys_swap;
    d_xmachine_message_movement_response_message_keys_swap = _t;
    }
    {
    unsigned int *_t = d_xmachine_message_movement_response_message_values;
    d_xmachine_message_movement_response_message_values = d_xmachine_message_movement_response_message_values_swap;
    d_xmachine_message_movement_response_message_values_swap = _t;
    }
    gpuErrchkLaunch();
    //reorder and build pcb
    gpuErrchk(cudaMemset(d_movement_response_message_partition_matrix->start, 0xffffffff, xmachine_message_movement_response_message_grid_size* sizeof(int)));
	  cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, reorder_movement_response_message_messages, reorder_messages_sm_size, h_message_movement_response_message_count); 
	  gridSize = (h_message_movement_response_message_count + blockSize - 1) / blockSize;
	  int reorder_sm_size = reorder_messages_sm_size(blockSize);
	  reorder_movement_response_message_messages<<<gridSize, blockSize, reorder_sm_size, stream>>>(d_xmachine_message_movement_response_message_keys, d_xmachine_message_movement_response_message_values, d_movement_response_message_partition_matrix, d_movement_response_messages, d_movement_response_messages_swap);
	  gpuErrchkLaunch();
#endif
  }
	//swap ordered list
	xmachine_message_movement_response_message_list* d_movement_response_messages_temp = d_movement_response_messages;
	d_movement_response_messages = d_movement_response_messages_swap;
	d_movement_response_messages_swap = d_movement_response_messages_temp;
	
	
	//************************ MOVE AGENTS TO NEXT STATE ****************************
    
	//check the working agents wont exceed the buffer size in the new state list
	if (h_xmachine_memory_Agent_Agent_default_count+h_xmachine_memory_Agent_count > xmachine_memory_Agent_MAX){
		printf("Error: Buffer size of movement_response_gen agents in state Agent_default will be exceeded moving working agents to next state in function movement_response_gen\n");
      exit(EXIT_FAILURE);
      }
      
  //pointer swap the updated data
  Agents_Agent_default_temp = d_Agents;
  d_Agents = d_Agents_Agent_default;
  d_Agents_Agent_default = Agents_Agent_default_temp;
        
	//update new state agent size
	h_xmachine_memory_Agent_Agent_default_count += h_xmachine_memory_Agent_count;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_Agent_default_count, &h_xmachine_memory_Agent_Agent_default_count, sizeof(int)));	
	
	
}



	
/* Shared memory size calculator for agent function */
int Agent_movement_response_sm_size(int blockSize){
	int sm_size;
	sm_size = SM_START;
  //Continuous agent and message input is spatially partitioned
	sm_size += (blockSize * sizeof(xmachine_message_movement_response_message));
	
	//all continuous agent types require single 32bit word per thread offset (to avoid sm bank conflicts)
	sm_size += (blockSize * PADDING);
	
	return sm_size;
}

/** Agent_movement_response
 * Agent function prototype for movement_response function of Agent agent
 */
void Agent_movement_response(cudaStream_t &stream){

    int sm_size;
    int blockSize;
    int minGridSize;
    int gridSize;
    int state_list_size;
	dim3 g; //grid for agent func
	dim3 b; //block for agent func

	
	//CHECK THE CURRENT STATE LIST COUNT IS NOT EQUAL TO 0
	
	if (h_xmachine_memory_Agent_Agent_default_count == 0)
	{
		return;
	}
	
	
	//SET SM size to 0 and save state list size for occupancy calculations
	sm_size = SM_START;
	state_list_size = h_xmachine_memory_Agent_Agent_default_count;

	

	//******************************** AGENT FUNCTION CONDITION *********************
	//THERE IS NOT A FUNCTION CONDITION
	//currentState maps to working list
	xmachine_memory_Agent_list* Agents_Agent_default_temp = d_Agents;
	d_Agents = d_Agents_Agent_default;
	d_Agents_Agent_default = Agents_Agent_default_temp;
	//set working count to current state count
	h_xmachine_memory_Agent_count = h_xmachine_memory_Agent_Agent_default_count;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_count, &h_xmachine_memory_Agent_count, sizeof(int)));	
	//set current state count to 0
	h_xmachine_memory_Agent_Agent_default_count = 0;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_Agent_default_count, &h_xmachine_memory_Agent_Agent_default_count, sizeof(int)));	
	
 

	//******************************** AGENT FUNCTION *******************************

	
	
	//calculate the grid block size for main agent function
	cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, GPUFLAME_movement_response, Agent_movement_response_sm_size, state_list_size);
	gridSize = (state_list_size + blockSize - 1) / blockSize;
	b.x = blockSize;
	g.x = gridSize;
	
	sm_size = Agent_movement_response_sm_size(blockSize);
	
	
	
	//BIND APPROPRIATE MESSAGE INPUT VARIABLES TO TEXTURES (to make use of the texture cache)
	//any agent with discrete or partitioned message input uses texture caching
	size_t tex_xmachine_message_movement_response_message_x_byte_offset;    
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_response_message_x_byte_offset, tex_xmachine_message_movement_response_message_x, d_movement_response_messages->x, sizeof(double)*xmachine_message_movement_response_message_MAX));
	h_tex_xmachine_message_movement_response_message_x_offset = (int)tex_xmachine_message_movement_response_message_x_byte_offset / sizeof(double);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_response_message_x_offset, &h_tex_xmachine_message_movement_response_message_x_offset, sizeof(int)));
	size_t tex_xmachine_message_movement_response_message_y_byte_offset;    
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_response_message_y_byte_offset, tex_xmachine_message_movement_response_message_y, d_movement_response_messages->y, sizeof(double)*xmachine_message_movement_response_message_MAX));
	h_tex_xmachine_message_movement_response_message_y_offset = (int)tex_xmachine_message_movement_response_message_y_byte_offset / sizeof(double);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_response_message_y_offset, &h_tex_xmachine_message_movement_response_message_y_offset, sizeof(int)));
	size_t tex_xmachine_message_movement_response_message_z_byte_offset;    
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_response_message_z_byte_offset, tex_xmachine_message_movement_response_message_z, d_movement_response_messages->z, sizeof(double)*xmachine_message_movement_response_message_MAX));
	h_tex_xmachine_message_movement_response_message_z_offset = (int)tex_xmachine_message_movement_response_message_z_byte_offset / sizeof(double);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_response_message_z_offset, &h_tex_xmachine_message_movement_response_message_z_offset, sizeof(int)));
	size_t tex_xmachine_message_movement_response_message_target_pos_x_byte_offset;    
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_response_message_target_pos_x_byte_offset, tex_xmachine_message_movement_response_message_target_pos_x, d_movement_response_messages->target_pos_x, sizeof(double)*xmachine_message_movement_response_message_MAX));
	h_tex_xmachine_message_movement_response_message_target_pos_x_offset = (int)tex_xmachine_message_movement_response_message_target_pos_x_byte_offset / sizeof(double);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_response_message_target_pos_x_offset, &h_tex_xmachine_message_movement_response_message_target_pos_x_offset, sizeof(int)));
	size_t tex_xmachine_message_movement_response_message_target_pos_y_byte_offset;    
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_response_message_target_pos_y_byte_offset, tex_xmachine_message_movement_response_message_target_pos_y, d_movement_response_messages->target_pos_y, sizeof(double)*xmachine_message_movement_response_message_MAX));
	h_tex_xmachine_message_movement_response_message_target_pos_y_offset = (int)tex_xmachine_message_movement_response_message_target_pos_y_byte_offset / sizeof(double);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_response_message_target_pos_y_offset, &h_tex_xmachine_message_movement_response_message_target_pos_y_offset, sizeof(int)));
	size_t tex_xmachine_message_movement_response_message_agent_id_byte_offset;    
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_response_message_agent_id_byte_offset, tex_xmachine_message_movement_response_message_agent_id, d_movement_response_messages->agent_id, sizeof(int)*xmachine_message_movement_response_message_MAX));
	h_tex_xmachine_message_movement_response_message_agent_id_offset = (int)tex_xmachine_message_movement_response_message_agent_id_byte_offset / sizeof(int);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_response_message_agent_id_offset, &h_tex_xmachine_message_movement_response_message_agent_id_offset, sizeof(int)));
	size_t tex_xmachine_message_movement_response_message_state_byte_offset;    
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_response_message_state_byte_offset, tex_xmachine_message_movement_response_message_state, d_movement_response_messages->state, sizeof(int)*xmachine_message_movement_response_message_MAX));
	h_tex_xmachine_message_movement_response_message_state_offset = (int)tex_xmachine_message_movement_response_message_state_byte_offset / sizeof(int);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_response_message_state_offset, &h_tex_xmachine_message_movement_response_message_state_offset, sizeof(int)));
	size_t tex_xmachine_message_movement_response_message_sugar_level_byte_offset;    
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_response_message_sugar_level_byte_offset, tex_xmachine_message_movement_response_message_sugar_level, d_movement_response_messages->sugar_level, sizeof(int)*xmachine_message_movement_response_message_MAX));
	h_tex_xmachine_message_movement_response_message_sugar_level_offset = (int)tex_xmachine_message_movement_response_message_sugar_level_byte_offset / sizeof(int);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_response_message_sugar_level_offset, &h_tex_xmachine_message_movement_response_message_sugar_level_offset, sizeof(int)));
	size_t tex_xmachine_message_movement_response_message_metabolism_byte_offset;    
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_response_message_metabolism_byte_offset, tex_xmachine_message_movement_response_message_metabolism, d_movement_response_messages->metabolism, sizeof(int)*xmachine_message_movement_response_message_MAX));
	h_tex_xmachine_message_movement_response_message_metabolism_offset = (int)tex_xmachine_message_movement_response_message_metabolism_byte_offset / sizeof(int);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_response_message_metabolism_offset, &h_tex_xmachine_message_movement_response_message_metabolism_offset, sizeof(int)));
	//bind pbm start and end indices to textures
	size_t tex_xmachine_message_movement_response_message_pbm_start_byte_offset;
	size_t tex_xmachine_message_movement_response_message_pbm_end_or_count_byte_offset;
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_response_message_pbm_start_byte_offset, tex_xmachine_message_movement_response_message_pbm_start, d_movement_response_message_partition_matrix->start, sizeof(int)*xmachine_message_movement_response_message_grid_size));
	h_tex_xmachine_message_movement_response_message_pbm_start_offset = (int)tex_xmachine_message_movement_response_message_pbm_start_byte_offset / sizeof(int);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_response_message_pbm_start_offset, &h_tex_xmachine_message_movement_response_message_pbm_start_offset, sizeof(int)));
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_response_message_pbm_end_or_count_byte_offset, tex_xmachine_message_movement_response_message_pbm_end_or_count, d_movement_response_message_partition_matrix->end_or_count, sizeof(int)*xmachine_message_movement_response_message_grid_size));
  h_tex_xmachine_message_movement_response_message_pbm_end_or_count_offset = (int)tex_xmachine_message_movement_response_message_pbm_end_or_count_byte_offset / sizeof(int);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_response_message_pbm_end_or_count_offset, &h_tex_xmachine_message_movement_response_message_pbm_end_or_count_offset, sizeof(int)));

	
	
	//MAIN XMACHINE FUNCTION CALL (movement_response)
	//Reallocate   : false
	//Input        : movement_response_message
	//Output       : 
	//Agent Output : 
	GPUFLAME_movement_response<<<g, b, sm_size, stream>>>(d_Agents, d_movement_response_messages, d_movement_response_message_partition_matrix);
	gpuErrchkLaunch();
	
	
	//UNBIND MESSAGE INPUT VARIABLE TEXTURES
	//any agent with discrete or partitioned message input uses texture caching
	gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_response_message_x));
	gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_response_message_y));
	gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_response_message_z));
	gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_response_message_target_pos_x));
	gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_response_message_target_pos_y));
	gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_response_message_agent_id));
	gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_response_message_state));
	gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_response_message_sugar_level));
	gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_response_message_metabolism));
	//unbind pbm indices
    gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_response_message_pbm_start));
    gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_response_message_pbm_end_or_count));
    
	
	//************************ MOVE AGENTS TO NEXT STATE ****************************
    
	//check the working agents wont exceed the buffer size in the new state list
	if (h_xmachine_memory_Agent_Agent_default_count+h_xmachine_memory_Agent_count > xmachine_memory_Agent_MAX){
		printf("Error: Buffer size of movement_response agents in state Agent_default will be exceeded moving working agents to next state in function movement_response\n");
      exit(EXIT_FAILURE);
      }
      
  //pointer swap the updated data
  Agents_Agent_default_temp = d_Agents;
  d_Agents = d_Agents_Agent_default;
  d_Agents_Agent_default = Agents_Agent_default_temp;
        
	//update new state agent size
	h_xmachine_memory_Agent_Agent_default_count += h_xmachine_memory_Agent_count;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_Agent_default_count, &h_xmachine_memory_Agent_Agent_default_count, sizeof(int)));	
	
	
}



	
/* Shared memory size calculator for agent function */
int Agent_movement_transaction_gen_sm_size(int blockSize){
	int sm_size;
	sm_size = SM_START;
  
	return sm_size;
}

/** Agent_movement_transaction_gen
 * Agent function prototype for movement_transaction_gen function of Agent agent
 */
void Agent_movement_transaction_gen(cudaStream_t &stream){

    int sm_size;
    int blockSize;
    int minGridSize;
    int gridSize;
    int state_list_size;
	dim3 g; //grid for agent func
	dim3 b; //block for agent func

	
	//CHECK THE CURRENT STATE LIST COUNT IS NOT EQUAL TO 0
	
	if (h_xmachine_memory_Agent_Agent_default_count == 0)
	{
		return;
	}
	
	
	//SET SM size to 0 and save state list size for occupancy calculations
	sm_size = SM_START;
	state_list_size = h_xmachine_memory_Agent_Agent_default_count;

	

	//******************************** AGENT FUNCTION CONDITION *********************
	//THERE IS NOT A FUNCTION CONDITION
	//currentState maps to working list
	xmachine_memory_Agent_list* Agents_Agent_default_temp = d_Agents;
	d_Agents = d_Agents_Agent_default;
	d_Agents_Agent_default = Agents_Agent_default_temp;
	//set working count to current state count
	h_xmachine_memory_Agent_count = h_xmachine_memory_Agent_Agent_default_count;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_count, &h_xmachine_memory_Agent_count, sizeof(int)));	
	//set current state count to 0
	h_xmachine_memory_Agent_Agent_default_count = 0;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_Agent_default_count, &h_xmachine_memory_Agent_Agent_default_count, sizeof(int)));	
	
 

	//******************************** AGENT FUNCTION *******************************

	
	//CONTINUOUS AGENT CHECK FUNCTION OUTPUT BUFFERS FOR OUT OF BOUNDS
	if (h_message_movement_transaction_message_count + h_xmachine_memory_Agent_count > xmachine_message_movement_transaction_message_MAX){
		printf("Error: Buffer size of movement_transaction_message message will be exceeded in function movement_transaction_gen\n");
		exit(EXIT_FAILURE);
	}
	
	
	//calculate the grid block size for main agent function
	cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, GPUFLAME_movement_transaction_gen, Agent_movement_transaction_gen_sm_size, state_list_size);
	gridSize = (state_list_size + blockSize - 1) / blockSize;
	b.x = blockSize;
	g.x = gridSize;
	
	sm_size = Agent_movement_transaction_gen_sm_size(blockSize);
	
	
	
	//SET THE OUTPUT MESSAGE TYPE FOR CONTINUOUS AGENTS
	//Set the message_type for non partitioned, spatially partitioned and On-Graph Partitioned message outputs
	h_message_movement_transaction_message_output_type = single_message;
	gpuErrchk( cudaMemcpyToSymbol( d_message_movement_transaction_message_output_type, &h_message_movement_transaction_message_output_type, sizeof(int)));
	
	
	//MAIN XMACHINE FUNCTION CALL (movement_transaction_gen)
	//Reallocate   : false
	//Input        : 
	//Output       : movement_transaction_message
	//Agent Output : 
	GPUFLAME_movement_transaction_gen<<<g, b, sm_size, stream>>>(d_Agents, d_movement_transaction_messages);
	gpuErrchkLaunch();
	
	
	//CONTINUOUS AGENTS SCATTER NON PARTITIONED OPTIONAL OUTPUT MESSAGES
	
	//UPDATE MESSAGE COUNTS FOR CONTINUOUS AGENTS WITH NON PARTITIONED MESSAGE OUTPUT 
	h_message_movement_transaction_message_count += h_xmachine_memory_Agent_count;
	//Copy count to device
	gpuErrchk( cudaMemcpyToSymbol( d_message_movement_transaction_message_count, &h_message_movement_transaction_message_count, sizeof(int)));	
	
	//reset partition matrix
	gpuErrchk( cudaMemset( (void*) d_movement_transaction_message_partition_matrix, 0, sizeof(xmachine_message_movement_transaction_message_PBM)));
    //PR Bug fix: Second fix. This should prevent future problems when multiple agents write the same message as now the message structure is completely rebuilt after an output.
    if (h_message_movement_transaction_message_count > 0){
#ifdef FAST_ATOMIC_SORTING
      //USE ATOMICS TO BUILD PARTITION BOUNDARY
	  cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, hist_movement_transaction_message_messages, no_sm, h_message_movement_transaction_message_count); 
	  gridSize = (h_message_movement_transaction_message_count + blockSize - 1) / blockSize;
	  hist_movement_transaction_message_messages<<<gridSize, blockSize, 0, stream>>>(d_xmachine_message_movement_transaction_message_local_bin_index, d_xmachine_message_movement_transaction_message_unsorted_index, d_movement_transaction_message_partition_matrix->end_or_count, d_movement_transaction_messages, h_message_movement_transaction_message_count);
	  gpuErrchkLaunch();
	
      // Scan
      cub::DeviceScan::ExclusiveSum(
          d_temp_scan_storage_xmachine_message_movement_transaction_message, 
          temp_scan_bytes_xmachine_message_movement_transaction_message, 
          d_movement_transaction_message_partition_matrix->end_or_count,
          d_movement_transaction_message_partition_matrix->start,
          xmachine_message_movement_transaction_message_grid_size, 
          stream
      );
	
	  cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, reorder_movement_transaction_message_messages, no_sm, h_message_movement_transaction_message_count); 
	  gridSize = (h_message_movement_transaction_message_count + blockSize - 1) / blockSize; 	// Round up according to array size 
	  reorder_movement_transaction_message_messages <<<gridSize, blockSize, 0, stream>>>(d_xmachine_message_movement_transaction_message_local_bin_index, d_xmachine_message_movement_transaction_message_unsorted_index, d_movement_transaction_message_partition_matrix->start, d_movement_transaction_messages, d_movement_transaction_messages_swap, h_message_movement_transaction_message_count);
	  gpuErrchkLaunch();
#else
	  //HASH, SORT, REORDER AND BUILD PMB FOR SPATIAL PARTITIONING MESSAGE OUTPUTS
	  //Get message hash values for sorting
	  cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, hash_movement_transaction_message_messages, no_sm, h_message_movement_transaction_message_count); 
	  gridSize = (h_message_movement_transaction_message_count + blockSize - 1) / blockSize;
	  hash_movement_transaction_message_messages<<<gridSize, blockSize, 0, stream>>>(d_xmachine_message_movement_transaction_message_keys, d_xmachine_message_movement_transaction_message_values, d_movement_transaction_messages);
    gpuErrchkLaunch();
    //Sort
    cub::DeviceRadixSort::SortPairs(d_CUB_temp_storage_movement_transaction_message, CUB_temp_storage_bytes_movement_transaction_message, d_xmachine_message_movement_transaction_message_keys, d_xmachine_message_movement_transaction_message_keys_swap, d_xmachine_message_movement_transaction_message_values, d_xmachine_message_movement_transaction_message_values_swap, h_message_movement_transaction_message_count, 0, binCountBits_movement_transaction_message, stream);
    {
    unsigned int *_t = d_xmachine_message_movement_transaction_message_keys;
    d_xmachine_message_movement_transaction_message_keys = d_xmachine_message_movement_transaction_message_keys_swap;
    d_xmachine_message_movement_transaction_message_keys_swap = _t;
    }
    {
    unsigned int *_t = d_xmachine_message_movement_transaction_message_values;
    d_xmachine_message_movement_transaction_message_values = d_xmachine_message_movement_transaction_message_values_swap;
    d_xmachine_message_movement_transaction_message_values_swap = _t;
    }
    gpuErrchkLaunch();
    //reorder and build pcb
    gpuErrchk(cudaMemset(d_movement_transaction_message_partition_matrix->start, 0xffffffff, xmachine_message_movement_transaction_message_grid_size* sizeof(int)));
	  cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, reorder_movement_transaction_message_messages, reorder_messages_sm_size, h_message_movement_transaction_message_count); 
	  gridSize = (h_message_movement_transaction_message_count + blockSize - 1) / blockSize;
	  int reorder_sm_size = reorder_messages_sm_size(blockSize);
	  reorder_movement_transaction_message_messages<<<gridSize, blockSize, reorder_sm_size, stream>>>(d_xmachine_message_movement_transaction_message_keys, d_xmachine_message_movement_transaction_message_values, d_movement_transaction_message_partition_matrix, d_movement_transaction_messages, d_movement_transaction_messages_swap);
	  gpuErrchkLaunch();
#endif
  }
	//swap ordered list
	xmachine_message_movement_transaction_message_list* d_movement_transaction_messages_temp = d_movement_transaction_messages;
	d_movement_transaction_messages = d_movement_transaction_messages_swap;
	d_movement_transaction_messages_swap = d_movement_transaction_messages_temp;
	
	
	//************************ MOVE AGENTS TO NEXT STATE ****************************
    
	//check the working agents wont exceed the buffer size in the new state list
	if (h_xmachine_memory_Agent_Agent_default_count+h_xmachine_memory_Agent_count > xmachine_memory_Agent_MAX){
		printf("Error: Buffer size of movement_transaction_gen agents in state Agent_default will be exceeded moving working agents to next state in function movement_transaction_gen\n");
      exit(EXIT_FAILURE);
      }
      
  //pointer swap the updated data
  Agents_Agent_default_temp = d_Agents;
  d_Agents = d_Agents_Agent_default;
  d_Agents_Agent_default = Agents_Agent_default_temp;
        
	//update new state agent size
	h_xmachine_memory_Agent_Agent_default_count += h_xmachine_memory_Agent_count;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_Agent_default_count, &h_xmachine_memory_Agent_Agent_default_count, sizeof(int)));	
	
	
}



	
/* Shared memory size calculator for agent function */
int Agent_movement_transaction_sm_size(int blockSize){
	int sm_size;
	sm_size = SM_START;
  //Continuous agent and message input is spatially partitioned
	sm_size += (blockSize * sizeof(xmachine_message_movement_transaction_message));
	
	//all continuous agent types require single 32bit word per thread offset (to avoid sm bank conflicts)
	sm_size += (blockSize * PADDING);
	
	return sm_size;
}

/** Agent_movement_transaction
 * Agent function prototype for movement_transaction function of Agent agent
 */
void Agent_movement_transaction(cudaStream_t &stream){

    int sm_size;
    int blockSize;
    int minGridSize;
    int gridSize;
    int state_list_size;
	dim3 g; //grid for agent func
	dim3 b; //block for agent func

	
	//CHECK THE CURRENT STATE LIST COUNT IS NOT EQUAL TO 0
	
	if (h_xmachine_memory_Agent_Agent_default_count == 0)
	{
		return;
	}
	
	
	//SET SM size to 0 and save state list size for occupancy calculations
	sm_size = SM_START;
	state_list_size = h_xmachine_memory_Agent_Agent_default_count;

	

	//******************************** AGENT FUNCTION CONDITION *********************
	//THERE IS NOT A FUNCTION CONDITION
	//currentState maps to working list
	xmachine_memory_Agent_list* Agents_Agent_default_temp = d_Agents;
	d_Agents = d_Agents_Agent_default;
	d_Agents_Agent_default = Agents_Agent_default_temp;
	//set working count to current state count
	h_xmachine_memory_Agent_count = h_xmachine_memory_Agent_Agent_default_count;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_count, &h_xmachine_memory_Agent_count, sizeof(int)));	
	//set current state count to 0
	h_xmachine_memory_Agent_Agent_default_count = 0;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_Agent_default_count, &h_xmachine_memory_Agent_Agent_default_count, sizeof(int)));	
	
 

	//******************************** AGENT FUNCTION *******************************

	
	
	//calculate the grid block size for main agent function
	cudaOccupancyMaxPotentialBlockSizeVariableSMem( &minGridSize, &blockSize, GPUFLAME_movement_transaction, Agent_movement_transaction_sm_size, state_list_size);
	gridSize = (state_list_size + blockSize - 1) / blockSize;
	b.x = blockSize;
	g.x = gridSize;
	
	sm_size = Agent_movement_transaction_sm_size(blockSize);
	
	
	
	//BIND APPROPRIATE MESSAGE INPUT VARIABLES TO TEXTURES (to make use of the texture cache)
	//any agent with discrete or partitioned message input uses texture caching
	size_t tex_xmachine_message_movement_transaction_message_x_byte_offset;    
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_transaction_message_x_byte_offset, tex_xmachine_message_movement_transaction_message_x, d_movement_transaction_messages->x, sizeof(double)*xmachine_message_movement_transaction_message_MAX));
	h_tex_xmachine_message_movement_transaction_message_x_offset = (int)tex_xmachine_message_movement_transaction_message_x_byte_offset / sizeof(double);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_transaction_message_x_offset, &h_tex_xmachine_message_movement_transaction_message_x_offset, sizeof(int)));
	size_t tex_xmachine_message_movement_transaction_message_y_byte_offset;    
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_transaction_message_y_byte_offset, tex_xmachine_message_movement_transaction_message_y, d_movement_transaction_messages->y, sizeof(double)*xmachine_message_movement_transaction_message_MAX));
	h_tex_xmachine_message_movement_transaction_message_y_offset = (int)tex_xmachine_message_movement_transaction_message_y_byte_offset / sizeof(double);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_transaction_message_y_offset, &h_tex_xmachine_message_movement_transaction_message_y_offset, sizeof(int)));
	size_t tex_xmachine_message_movement_transaction_message_z_byte_offset;    
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_transaction_message_z_byte_offset, tex_xmachine_message_movement_transaction_message_z, d_movement_transaction_messages->z, sizeof(double)*xmachine_message_movement_transaction_message_MAX));
	h_tex_xmachine_message_movement_transaction_message_z_offset = (int)tex_xmachine_message_movement_transaction_message_z_byte_offset / sizeof(double);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_transaction_message_z_offset, &h_tex_xmachine_message_movement_transaction_message_z_offset, sizeof(int)));
	size_t tex_xmachine_message_movement_transaction_message_agent_id_byte_offset;    
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_transaction_message_agent_id_byte_offset, tex_xmachine_message_movement_transaction_message_agent_id, d_movement_transaction_messages->agent_id, sizeof(int)*xmachine_message_movement_transaction_message_MAX));
	h_tex_xmachine_message_movement_transaction_message_agent_id_offset = (int)tex_xmachine_message_movement_transaction_message_agent_id_byte_offset / sizeof(int);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_transaction_message_agent_id_offset, &h_tex_xmachine_message_movement_transaction_message_agent_id_offset, sizeof(int)));
	size_t tex_xmachine_message_movement_transaction_message_state_byte_offset;    
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_transaction_message_state_byte_offset, tex_xmachine_message_movement_transaction_message_state, d_movement_transaction_messages->state, sizeof(int)*xmachine_message_movement_transaction_message_MAX));
	h_tex_xmachine_message_movement_transaction_message_state_offset = (int)tex_xmachine_message_movement_transaction_message_state_byte_offset / sizeof(int);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_transaction_message_state_offset, &h_tex_xmachine_message_movement_transaction_message_state_offset, sizeof(int)));
	//bind pbm start and end indices to textures
	size_t tex_xmachine_message_movement_transaction_message_pbm_start_byte_offset;
	size_t tex_xmachine_message_movement_transaction_message_pbm_end_or_count_byte_offset;
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_transaction_message_pbm_start_byte_offset, tex_xmachine_message_movement_transaction_message_pbm_start, d_movement_transaction_message_partition_matrix->start, sizeof(int)*xmachine_message_movement_transaction_message_grid_size));
	h_tex_xmachine_message_movement_transaction_message_pbm_start_offset = (int)tex_xmachine_message_movement_transaction_message_pbm_start_byte_offset / sizeof(int);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_transaction_message_pbm_start_offset, &h_tex_xmachine_message_movement_transaction_message_pbm_start_offset, sizeof(int)));
	gpuErrchk( cudaBindTexture(&tex_xmachine_message_movement_transaction_message_pbm_end_or_count_byte_offset, tex_xmachine_message_movement_transaction_message_pbm_end_or_count, d_movement_transaction_message_partition_matrix->end_or_count, sizeof(int)*xmachine_message_movement_transaction_message_grid_size));
  h_tex_xmachine_message_movement_transaction_message_pbm_end_or_count_offset = (int)tex_xmachine_message_movement_transaction_message_pbm_end_or_count_byte_offset / sizeof(int);
	gpuErrchk(cudaMemcpyToSymbol( d_tex_xmachine_message_movement_transaction_message_pbm_end_or_count_offset, &h_tex_xmachine_message_movement_transaction_message_pbm_end_or_count_offset, sizeof(int)));

	
	
	//MAIN XMACHINE FUNCTION CALL (movement_transaction)
	//Reallocate   : false
	//Input        : movement_transaction_message
	//Output       : 
	//Agent Output : 
	GPUFLAME_movement_transaction<<<g, b, sm_size, stream>>>(d_Agents, d_movement_transaction_messages, d_movement_transaction_message_partition_matrix);
	gpuErrchkLaunch();
	
	
	//UNBIND MESSAGE INPUT VARIABLE TEXTURES
	//any agent with discrete or partitioned message input uses texture caching
	gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_transaction_message_x));
	gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_transaction_message_y));
	gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_transaction_message_z));
	gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_transaction_message_agent_id));
	gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_transaction_message_state));
	//unbind pbm indices
    gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_transaction_message_pbm_start));
    gpuErrchk( cudaUnbindTexture(tex_xmachine_message_movement_transaction_message_pbm_end_or_count));
    
	
	//************************ MOVE AGENTS TO NEXT STATE ****************************
    
	//check the working agents wont exceed the buffer size in the new state list
	if (h_xmachine_memory_Agent_Agent_default_count+h_xmachine_memory_Agent_count > xmachine_memory_Agent_MAX){
		printf("Error: Buffer size of movement_transaction agents in state Agent_default will be exceeded moving working agents to next state in function movement_transaction\n");
      exit(EXIT_FAILURE);
      }
      
  //pointer swap the updated data
  Agents_Agent_default_temp = d_Agents;
  d_Agents = d_Agents_Agent_default;
  d_Agents_Agent_default = Agents_Agent_default_temp;
        
	//update new state agent size
	h_xmachine_memory_Agent_Agent_default_count += h_xmachine_memory_Agent_count;
	gpuErrchk( cudaMemcpyToSymbol( d_xmachine_memory_Agent_Agent_default_count, &h_xmachine_memory_Agent_Agent_default_count, sizeof(int)));	
	
	
}


 
extern void reset_Agent_Agent_default_count()
{
    h_xmachine_memory_Agent_Agent_default_count = 0;
}
