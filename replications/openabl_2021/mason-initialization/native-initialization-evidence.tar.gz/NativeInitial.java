public class NativeInitial {
 public static void main(String[] args) throws Exception {
  Sim sim = new Sim(0);
  sim.start();
  Replay.initial = new double[sim.env.getAllObjects().size()][0];
  Replay.snapshot(sim, args[0]);
 }
}
