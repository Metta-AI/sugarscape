from pathlib import Path
import hashlib
import json
import subprocess
import sys
root=Path(__file__).resolve().parent
evidence=root.parent
jar=evidence/'openabl-mason-control-001/mason.19.jar'
java=Path('/opt/homebrew/opt/openjdk@17/bin')
base=evidence/'openabl-mason-published-grid-001/250/native'
command=[str(java/'javac'),'-cp',f'{jar}:{base}',str(root/'NativeInitial.java')]
with (root/'compile.log').open('x') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=60)
with (root/'completed.jsonl').open('x') as ledger:
 for size in [250*2**i for i in range(11)]:
  parent='openabl-mason-published-grid-001' if size<=64000 else 'openabl-mason-published-grid-002'
  classes=evidence/parent/str(size)/'native'
  assert (classes/'Replay.class').is_file()
  out=root/str(size);out.mkdir()
  commands=[[str(java/'java'),'-Xmx4g','-cp',f'{root}:{jar}:{classes}','NativeInitial',str(out/'initial.json')],[sys.executable,str(root/'initialize_mason.py'),str(out/'initial.json'),str(out/'audit.json'),'--requested-cells',str(size),'--seed','0']]
  (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
  for i,command in enumerate(commands):
   with (out/f'stage-{i}.log').open('x') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=600)
   (out/f'stage-{i}-exit.json').write_text(json.dumps({'exit_code':r.returncode})+'\n');r.check_returncode()
  record=json.loads((out/'audit.json').read_text());ledger.write(json.dumps(record)+'\n');ledger.flush();print(f'Validated MASON initialization {size}',flush=True)
