import sim.portrayal.continuous.*;
import sim.portrayal.simple.*;
import sim.portrayal.*;
import sim.portrayal3d.continuous.*;
import sim.portrayal3d.simple.*;
import sim.engine.*;
import sim.display.*;
import sim.display3d.*;
import javax.swing.*;
import java.awt.*;

public class SimWithUI extends GUIState {
    class MyDisplay extends Display2D {
        MyDisplay(double width, double height, GUIState sim) {
            super(width, height, sim);
            updateRule = Display2D.UPDATE_RULE_STEPS;
            stepInterval = 4;
        }
    }
    private static final int SIZE = 500;
    public Display2D display;
    public JFrame displayFrame;
    public static String name = "Visualization";
    ContinuousPortrayal2D envPortrayal = new ContinuousPortrayal2D();

    public static void main(String[] args) {
        SimWithUI vid = new SimWithUI();
        Console c = new Console(vid);
        c.setVisible(true);
    }

    public SimWithUI() {
        super(new Sim(System.currentTimeMillis()));
    }
    public SimWithUI(SimState state) {
        super(state);
    }

    public static String getName() {
        return name;
    }

    public void start() {
        super.start();
        setupPortrayals();
    }
    public void load(SimState state) {
        super.load(state);
        setupPortrayals();
    }

    public void setupPortrayals() {
        Sim sim = (Sim) state;
        final double defaultScale = 4 * sim.env.width / SIZE;

        envPortrayal.setField(sim.env);
        envPortrayal.setPortrayalForClass(Agent.class, new OvalPortrayal2D() {
            public void draw(Object object, Graphics2D graphics, DrawInfo2D info) {
                Agent agent = (Agent) object;
                paint = new Color(sim.getColor(agent));
                scale = defaultScale * sim.getSize(agent);
                super.draw(object, graphics, info);
            }
        });

        display.repaint();
    }

    public void init(Controller c) {
        super.init(c);

        display = new MyDisplay(SIZE, SIZE, this);
        display.setBackdrop(Color.white);
        //display.setClipping(false);

        displayFrame = display.createFrame();
        displayFrame.setTitle("Visualization Display");
        c.registerFrame(displayFrame);
        displayFrame.setVisible(true);
        display.attach(envPortrayal, "Environment");
    }

    public void quit() {
        super.quit();
        if (displayFrame != null) displayFrame.dispose();
        displayFrame = null;
        display = null;
    }
}
