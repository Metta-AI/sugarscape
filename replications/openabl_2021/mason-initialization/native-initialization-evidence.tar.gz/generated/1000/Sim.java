import sim.engine.*;
import sim.util.*;
import sim.field.continuous.*;

public class Sim extends SimState {
    public static double PI = 3.14159;
    public static int AGENT_STATE_UNOCCUPIED = 0;
    public static int AGENT_STATE_OCCUPIED = 1;
    public static int AGENT_STATE_MOVEMENT_REQUESTED = 2;
    public static int AGENT_STATE_MOVEMENT_UNRESOLVED = 3;
    public static int SUGAR_GROWBACK_RATE = 1;
    public static int min_start_sugar_level = 1;
    public static int max_start_sugar_level = 10;
    public static double radius = 1.5;
    public static int num_timesteps = 100;
    public static double occupiedFrac = 0.1;
    public static int num_agents = 1000;
    public static int grid_width = 31;
    public static Double2D sugar_center1 = new Double2D(7.75, 7.75);
    public static Double2D sugar_center2 = new Double2D(23.25, 23.25);
    public static int global_max_env_sugar_level = 50;
    public static double sugar_variance = 24.025;
    public Continuous2D env = new Continuous2D(1.5, 31, 31);
    private double lastExecTime;
    
    public Sim(long seed) {
        super(seed);
    }
    public void start() {
        super.start();
        env.clear();
        
        int id = 0;
        for (int x = 0, _var0 = Sim.grid_width; x < _var0; ++x) {
            for (int y = 0, _var1 = Sim.grid_width; y < _var1; ++y) {
                boolean occupied = (this.random(1.0) < Sim.occupiedFrac);
                int max_env_sugar_level = this.calc_max_env_sugar_level(x, y);
                final Agent _var2 = new Agent(new Double2D(((float) x + 0.5), ((float) y + 0.5)), new Double2D(0, 0), id, (occupied ? Sim.AGENT_STATE_OCCUPIED : Sim.AGENT_STATE_UNOCCUPIED), (occupied ? Util.randomInt(this.random, Sim.min_start_sugar_level, Sim.max_start_sugar_level) : 0), (occupied ? 1 : 0), Util.randomInt(this.random, 0, max_env_sugar_level), max_env_sugar_level);
                this.env.setObjectLocation(_var2, _var2.getInState().pos);
                this.schedule.scheduleRepeating(Schedule.EPOCH, _var2);
                id += 1;
            }
        }
    }
    public void finish() {
        super.finish();
        
    }
    public static void main(String[] args) {
        Sim _sim = new Sim(System.currentTimeMillis());
        _sim.start();
        int _var3 = Sim.num_timesteps * 4;
        long lastTime = System.currentTimeMillis();
        do {
            if (!_sim.schedule.step(_sim)) break;
            if (_sim.schedule.getSteps() % 4 == 0) {
                long curTime = System.currentTimeMillis();
                _sim.lastExecTime = (curTime - lastTime) / 1000.0;
                lastTime = curTime;
            }
        } while (_sim.schedule.getSteps() < _var3);
        _sim.finish();
        System.exit(0);
    }
    public static int getColor(Object obj) {
        return 0;
    }
    public static int getSize(Object obj) {
        return 1;
    }
    
    public Double2D random(Double2D min, Double2D max) {
        return new Double2D(Util.random(this.random, min.x, max.x), Util.random(this.random, min.y, max.y));
    }
    
    public Double3D random(Double3D min, Double3D max) {
        return new Double3D(Util.random(this.random, min.x, max.x), Util.random(this.random, min.y, max.y), Util.random(this.random, min.z, max.z));
    }
    
    public double random(double max) {
        return Util.random(this.random, 0, max);
    }
    
    public Double2D random(Double2D max) {
        return this.random(new Double2D(0, 0), max);
    }
    
    public Double3D random(Double3D max) {
        return this.random(new Double3D(0, 0, 0), max);
    }
    
    public int randomInt(int max) {
        return Util.randomInt(this.random, 0, max);
    }
    
    public double clamp(double pos, double min, double max) {
        return ((pos < min) ? min : ((pos > max) ? max : pos));
    }
    
    public Double2D clamp(Double2D pos, Double2D min, Double2D max) {
        return new Double2D(((pos.x < min.x) ? min.x : ((pos.x > max.x) ? max.x : pos.x)), ((pos.y < min.y) ? min.y : ((pos.y > max.y) ? max.y : pos.y)));
    }
    
    public Double3D clamp(Double3D pos, Double3D min, Double3D max) {
        return new Double3D(((pos.x < min.x) ? min.x : ((pos.x > max.x) ? max.x : pos.x)), ((pos.y < min.y) ? min.y : ((pos.y > max.y) ? max.y : pos.y)), ((pos.z < min.z) ? min.z : ((pos.z > max.z) ? max.z : pos.z)));
    }
    
    public double clamp(double pos, double max) {
        return this.clamp(pos, 0, max);
    }
    
    public Double2D clamp(Double2D pos, Double2D max) {
        return this.clamp(pos, new Double2D(0, 0), max);
    }
    
    public Double3D clamp(Double3D pos, Double3D max) {
        return this.clamp(pos, new Double3D(0, 0, 0), max);
    }
    
    public double wraparound(double pos, double max) {
        return ((pos < 0) ? (max + pos) : ((pos >= max) ? (pos - max) : pos));
    }
    
    public Double2D wraparound(Double2D pos, Double2D max) {
        return new Double2D(((pos.x < 0) ? (max.x + pos.x) : ((pos.x >= max.x) ? (pos.x - max.x) : pos.x)), ((pos.y < 0) ? (max.y + pos.y) : ((pos.y >= max.y) ? (pos.y - max.y) : pos.y)));
    }
    
    public Double3D wraparound(Double3D pos, Double3D max) {
        return new Double3D(((pos.x < 0) ? (max.x + pos.x) : ((pos.x >= max.x) ? (pos.x - max.x) : pos.x)), ((pos.y < 0) ? (max.y + pos.y) : ((pos.y >= max.y) ? (pos.y - max.y) : pos.y)), ((pos.z < 0) ? (max.z + pos.z) : ((pos.z >= max.z) ? (pos.z - max.z) : pos.z)));
    }
    
    public boolean is_inside(Double2D pos, Double2D max) {
        return ((((pos.x >= 0) && (pos.y >= 0)) && (pos.x <= max.x)) && (pos.y <= max.y));
    }
    
    public int getColor(Agent _cell) {
        Agent.State cell = _cell.getInState();
        double frac = java.lang.Math.min(1.0, ((float) cell.env_sugar_level / (float) Sim.global_max_env_sugar_level));
        int c = (int) (255.0 * (1.0 - frac));
        int rgb = (16711935 | (c << 8));
        if ((cell.state == Sim.AGENT_STATE_UNOCCUPIED)) {
            return rgb;
        }
        return ((cell.state == Sim.AGENT_STATE_OCCUPIED) ? 0 : 16711680);
    }
    
    public int calc_max_env_sugar_level(int x, int y) {
        int gmax = Sim.global_max_env_sugar_level;
        Double2D pos = new Double2D(x, y);
        int max = 0;
        double d1 = pos.distance(Sim.sugar_center1);
        max += ((float) gmax * java.lang.Math.exp((((-d1) * d1) / (2.0 * Sim.sugar_variance))));
        double d2 = pos.distance(Sim.sugar_center2);
        max += ((float) gmax * java.lang.Math.exp((((-d2) * d2) / (2.0 * Sim.sugar_variance))));
        return max;
    }
    
}