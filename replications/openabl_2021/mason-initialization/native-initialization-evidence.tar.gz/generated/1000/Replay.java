import java.io.*;
import sim.util.*;
public class Replay {
 static double[][] initial;
 static void snapshot(Sim sim, String path) throws Exception {
  try (PrintWriter w = new PrintWriter(path)) {
   w.print("{\"Agent\":[");
   for(int i=0;i<initial.length;i++) {
    Agent a=(Agent)sim.env.getAllObjects().get(i); Agent.State s=a.getInState();
    if(i>0) w.print(",");
    w.printf(java.util.Locale.ROOT,"{\"pos\":[%f,%f],\"target_pos\":[%f,%f],\"agent_id\":%d,\"state\":%d,\"sugar_level\":%d,\"metabolism\":%d,\"env_sugar_level\":%d,\"max_env_sugar_level\":%d}",s.pos.x,s.pos.y,s.target_pos.x,s.target_pos.y,s.agent_id,s.state,s.sugar_level,s.metabolism,s.env_sugar_level,s.max_env_sugar_level);
   } w.print("]}");
  }
 }
 public static void main(String[] args) throws Exception {
  java.util.List<String> lines=java.nio.file.Files.readAllLines(java.nio.file.Path.of(args[0]));
  initial=new double[lines.size()][10];
  for(int i=0;i<lines.size();i++) {
   String[] fields=lines.get(i).split(",");
   if(fields.length!=10) throw new IllegalArgumentException("Expected ten initialization columns");
   for(int j=0;j<10;j++) initial[i][j]=Double.parseDouble(fields[j]);
  }
  Sim sim=new Sim(0);sim.start();
  if(sim.env.getAllObjects().size()!=initial.length) throw new IllegalStateException("Cell count differs");
  for(int i=0;i<initial.length;i++) {
   Agent a=(Agent)sim.env.getAllObjects().get(i);
   int index=(int)a.getInState().pos.x*((int)Math.sqrt(initial.length))+(int)a.getInState().pos.y;
   double[] r=initial[index];
   for(int b=0;b<2;b++) {
    Agent.State s=a.getState(b);s.pos=new Double2D(r[0],r[1]);s.target_pos=new Double2D(r[2],r[3]);
    s.agent_id=(int)r[4];s.state=(int)r[5];s.sugar_level=(int)r[6];s.metabolism=(int)r[7];s.env_sugar_level=(int)r[8];s.max_env_sugar_level=(int)r[9];
   }
  }
  snapshot(sim,"observer-initial.json");
  for(int i=0;i<400;i++) {if(!sim.schedule.step(sim)) throw new IllegalStateException("Schedule ended");}
  snapshot(sim,"observer-final.json");
 }
}
