import difflib
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
workspace = root.parent.parent
reference = workspace / 'sugarscape-openabl-reference'
compiler = root.parent / 'openabl-build-001/OpenABL'
jar = root.parent / 'openabl-mason-control-001/mason.19.jar'
assert hashlib.sha256(jar.read_bytes()).hexdigest() == '5575345e8800a089f4673ebbfc6929956b0a9e86fb7a65422312748399ede08f'
assert hashlib.sha256(compiler.read_bytes()).hexdigest() == '841bc2ee2faa26afcc14a3bf036119cf4d2444b4436085cf9e95aed9a865e01d'
java = Path('/opt/homebrew/opt/openjdk@17/bin')
protocol = json.loads((root / 'protocol.json').read_text())
with (root / 'commands.jsonl').open('x') as commands, (root / 'completed.jsonl').open('x') as completed:
    for size in protocol['requested_cells']:
        assert shutil.disk_usage(root).free > 2*1024**3
        out = root / str(size)
        out.mkdir()
        if size == 250:
            initial_path = root.parent / 'openabl-native-condition-001/threads-1/initial.json'
        elif size <= 32000:
            initial_path = root.parent / 'openabl-c-published-grid-001' / str(size) / 'initial.json'
        else:
            initial_path = out / 'initial.json'
            tasks = [([str(compiler), '-i', str(root.parent/'openabl-native-condition-001/observed.abl'), '-o', str(out/'c-initializer'), '-b', 'c', '-A', str(reference/'asset'), '-P', f'num_agents={size}', '-P', 'num_timesteps=0'], out), (['/opt/homebrew/bin/gcc-16', '-O2', '-std=c99', 'main.c', 'libabl.c', '-lm', '-fopenmp', '-o', 'main'], out/'c-initializer'), ([str(out/'c-initializer/main')], out)]
            for i, (command, cwd) in enumerate(tasks):
                with (out/f'initialize-{i}.log').open('x') as log:
                    result = subprocess.run(command, cwd=cwd, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=1800)
                commands.write(json.dumps({'command':command,'cwd':str(cwd),'exit_code':result.returncode})+'\n');commands.flush()
        cells = json.loads(initial_path.read_text())['Agent']
        assert len(cells) == math.isqrt(size)**2
        if initial_path != out/'initial.json':
            shutil.copy2(initial_path,out/'initial.json')
        command = [sys.executable,str(root/'initialize.py'),str(out/'initial.json'),str(out/'initialization-audit.json'),'--requested-cells',str(size)]
        with (out/'initialization-audit.log').open('x') as log: subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
        (out/'initial.csv').write_text(''.join(','.join(map(str,[*r['pos'],*r['target_pos'],r['agent_id'],r['state'],r['sugar_level'],r['metabolism'],r['env_sugar_level'],r['max_env_sugar_level']]))+'\n' for r in cells))
        command=[str(compiler),'-i',str(reference/'examples/sugarscape.abl'),'-o',str(out/'native'),'-b','mason','-A',str(reference/'asset'),'-P',f'num_agents={size}','-P','num_timesteps=100']
        with (out/'generate.log').open('x') as log: subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=60)
        commands.write(json.dumps({'command':command,'exit_code':0})+'\n');commands.flush()
        native=(out/'native/Agent.java').read_text()
        line='            Bag _bag = _sim.env.getNeighborsExactlyWithinDistance(in.pos, Sim.radius);'
        assert native.count(line)==3
        sorted_source=native.replace(line,line+'\n            java.util.Arrays.sort(_bag.objs, 0, _bag.numObjs, java.util.Comparator.comparingDouble((Object a) -> ((Agent)a).getInState().pos.x).thenComparingDouble(a -> ((Agent)a).getInState().pos.y));')
        (out/'ordered').mkdir()
        for file in (out/'native').glob('*.java'):shutil.copy2(file,out/'ordered'/file.name)
        (out/'ordered/Agent.java').write_text(sorted_source)
        (out/'neighbor-order.patch').write_text(''.join(difflib.unified_diff(native.splitlines(keepends=True),sorted_source.splitlines(keepends=True),fromfile='native/Agent.java',tofile='ordered/Agent.java')))
        final_states={}
        for mode in ['native','ordered']:
            target=out/mode;shutil.copy2(root/'Replay.java',target/'Replay.java')
            tasks=[[str(java/'javac'),'-cp',f'{jar}:.',*[p.name for p in sorted(target.glob('*.java'))]],[str(java/'java'),'-Xmx4g','-cp',f'{jar}:.','Replay',str(out/'initial.csv')]]
            for i,command in enumerate(tasks):
                start=time.monotonic()
                with (target/f'stage-{i}.log').open('x') as log:result=subprocess.run(command,cwd=target,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
                receipt={'command':command,'cwd':str(target),'exit_code':result.returncode,'seconds':time.monotonic()-start};(target/f'stage-{i}-exit.json').write_text(json.dumps(receipt)+'\n');commands.write(json.dumps(receipt)+'\n');commands.flush();result.check_returncode()
            for endpoint in ['initial','final']:
                values=json.loads((target/f'observer-{endpoint}.json').read_text())['Agent'];values.sort(key=lambda x:tuple(x['pos']));(target/f'{endpoint}-sorted.json').write_text(json.dumps({'Agent':values})+'\n')
                if endpoint=='initial':assert values==cells
                else:final_states[mode]=values
        command=[sys.executable,str(root/'replay.py'),str(out/'initial.json'),str(out/'ordered/final-sorted.json'),str(out/'ordered-replay-audit.json'),'--steps','100','--buffer','copy']
        with (out/'ordered-replay.log').open('x') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1800)
        record={'requested_cells':size,'actual_cells':len(cells),'initial_fields_equal_each_variant':len(cells)*8,'ordered_replay':json.loads((out/'ordered-replay-audit.json').read_text()),'native_vs_ordered_changed_fields':{f:sum(x[f]!=y[f] for x,y in zip(final_states['native'],final_states['ordered'],strict=True)) for f in cells[0]},'completed_study':False}
        completed.write(json.dumps(record)+'\n');completed.flush();print(f'Validated MASON paired condition {size}',flush=True)
