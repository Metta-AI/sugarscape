from pathlib import Path
import csv
import gzip
import hashlib
import json
import math
import statistics
import tarfile

root=Path('/Users/relh/Code/workspace/sugarscape-replication-evidence/oremland-convergence-002')
out=Path('/Users/relh/Code/workspace/sugarscape-oremland/replications/oremland_2014/results/convergence-2026-10-18')
assert json.loads((root/'execution/exit.json').read_text())['exit_codes']==[0]*4
results={}
for path in sorted((root/'execution').glob('results-*.jsonl')):
    for line in path.read_text().splitlines():
        row=json.loads(line)
        results[row['id']]=row
with (out/'policy-summaries.csv').open() as stream:
    summaries=list(csv.DictReader(stream))
assert len(summaries)==600
for row in summaries:
    policy_id=int(row['policy_id'])
    phase_index=[0,4].index(int(row['phase']))
    observations=[results[policy_id*200+phase_index*100+seed] for seed in range(100)]
    if row['metric']=='deaths':
        values=[200-item['population'] for item in observations]
    elif row['metric']=='literal_revenue':
        values=[item['total_tax'] for item in observations]
    else:
        assert row['metric']=='derived_clipped_revenue'
        values=[item['total_tax']+item['debt_refund'] for item in observations]
    for n in [50,100]:
        assert math.isclose(statistics.mean(values[:n]),float(row[f'mean_{n}']),rel_tol=0,abs_tol=1e-10)
        assert math.isclose(statistics.stdev(values[:n]),float(row[f'sample_sd_{n}']),rel_tol=0,abs_tol=1e-10)
with gzip.open(out/'prefix-curves.csv.gz','rt') as stream:
    curves=list(csv.DictReader(stream))
assert len(curves)==59400
keys={(row['policy_id'],row['phase'],row['seeds'],row['metric']) for row in curves}
assert len(keys)==59400
archive=out/'native-evidence.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
    for path in sorted(root.rglob('*')):
        if path.is_file():
            tar.add(path,arcname=str(path.relative_to(root)),recursive=False)
files=0
with tarfile.open(archive,'r:gz') as tar:
    for member in tar.getmembers():
        if member.isfile():
            data=tar.extractfile(member).read()
            assert data==(root/member.name).read_bytes()
            files+=1
failed=root.with_name('oremland-convergence-001')
with tarfile.open(out/'failed-launch-evidence.tar.gz','x:gz') as tar:
    for path in [failed/'protocol.json',*sorted((failed/'execution').glob('*'))]:
        if path.is_file():
            tar.add(path,arcname=str(path.relative_to(failed)),recursive=False)
report={'native_runs':len(results),'summary_rows_independently_checked':len(summaries),'mean_sd_comparisons_against_python_statistics':len(summaries)*4,'absolute_tolerance':1e-10,'prefix_rows_read_back':len(curves),'archive_files_byte_identical':files,'native_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'scope':'Independent arithmetic readback of native observations and lossless archive verification; not independent model validation.'}
(out/'readback.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
