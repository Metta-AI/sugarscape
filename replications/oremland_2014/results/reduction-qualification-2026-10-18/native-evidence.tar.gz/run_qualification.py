from pathlib import Path
import hashlib,json,subprocess,time
root=Path(__file__).parent
repo=Path('/Users/relh/Code/workspace/sugarscape-oremland/replications/oremland_2014')
protocol=json.loads((root/'protocol.json').read_text())
seen=set()
selected=[]
for model in protocol['models']:
 key=(model['model_sha256'],model['landscape_sha256'])
 if key not in seen:
  seen.add(key)
  selected.append(model['name'])
manifest={'selected_models':selected,'seeds':[1,2],'clock_phases':[0,4],'clipped':[False,True],'native_runs':len(selected)*8,'per_model_seconds_limit':120,'policy':'Published heterogeneous control, unchanged','started_unix':time.time(),'protocol_sha256':hashlib.sha256((root/'protocol.json').read_bytes()).hexdigest()}
(root/'qualification-protocol.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in selected:
 subprocess.run(['/Users/relh/Code/workspace/sugarscape-replications/.venv/bin/python',str(repo/'run_ensemble.py'),'/opt/homebrew/opt/openjdk@11','/Users/relh/Code/workspace/sugarscape-replication-tools/netlogo-5.3.1-64/app',str(root/name/'oremland.nlogo'),str(root/name/'qualification'),'--seeds','2','--seconds','120','--timeout','/opt/homebrew/bin/gtimeout','policy',str(repo/'results/policy-indexing-2026-10-18/heterogeneous/policy.txt')],check=True)
 print(name,flush=True)
(root/'qualification-exit.json').write_text(json.dumps({'exit_code':0,'elapsed_seconds':time.time()-manifest['started_unix']},indent=2)+'\n')
