"""Compare original and corrected migration profiles without a fitted wave criterion."""

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("original", type=Path)
parser.add_argument("corrected", type=Path)
parser.add_argument("output", type=Path)
a = parser.parse_args()
old = {r["case"]: r for r in json.loads(a.original.read_text())["results"]}
new = {r["case"]: r for r in json.loads(a.corrected.read_text())["cases"]}
arrays = []
for source, key in [
    (old, "observed_agents_diagonal_counts"),
    (new, "diagonal_agent_counts"),
]:
    for label in ["migration", "migration_vision15"]:
        arrays.append(np.array([p[key] for p in source[label]["profiles"]]))
fig, axes = plt.subplots(
    2, 2, figsize=(11, 7), sharex=True, sharey=True, layout="constrained"
)
maximum = max(int(x.max()) for x in arrays)
for axis, values, title in zip(
    axes.flat,
    arrays,
    [
        "Original: vision1–10",
        "Original: vision1–15",
        "Corrected: vision1–10",
        "Corrected: vision1–15",
    ],
    strict=True,
):
    im = axis.imshow(
        values,
        origin="lower",
        aspect="auto",
        extent=[0, 50, 0, 1000],
        vmin=0,
        vmax=maximum,
        cmap="viridis",
    )
    axis.set_title(title)
    axis.set_xlabel("Diagonal position (x+y)/2")
    axis.set_ylabel("Simulation step")
fig.colorbar(im, ax=axes.ravel().tolist(), label="Observed agents per diagonal bin")
fig.suptitle("Seed602352629: source sensitivity, not a wave-presence test")
fig.savefig(a.output, dpi=140)
