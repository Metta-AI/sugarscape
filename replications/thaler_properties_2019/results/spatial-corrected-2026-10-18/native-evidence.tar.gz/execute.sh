set -eu
cd /work
trap 'rc=$?; printf "%s\n" "$rc" > /work/exit-code.txt' EXIT
mkdir observer-build spatial
cd source
timeout 900 stack build --jobs 1 > /work/build.log 2>&1
stack exec -- ghc --numeric-version > /work/compiler.txt
test "$(cat /work/compiler.txt)" = '8.4.4'
timeout 300 stack ghc -- -O2 -isrc -odir ../observer-build -hidir ../observer-build ../Observe.hs -o ../observe >> /work/build.log 2>&1
cd /work
sha256sum observe > binary-sha256.txt
timeout 240 ./observe mkParamsAnimationII_6 602352629 1000 10 spatial/migration > spatial/migration.stdout.log 2> spatial/migration.stderr.log
timeout 240 ./observe mkParamsAnimationII_8 602352629 1000 10 spatial/pollution > spatial/pollution.stdout.log 2> spatial/pollution.stderr.log
timeout 240 ./observe migrationVision15 602352629 1000 10 spatial/migration_vision15 > spatial/migration_vision15.stdout.log 2> spatial/migration_vision15.stderr.log
printf '{"completed_cases":3}\n' > complete.json
