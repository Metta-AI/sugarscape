"""Audit complete corrected spatial controls, retaining occupancy disagreements."""

import argparse
import csv
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("run", type=Path)
parser.add_argument("original", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()
p = json.loads((args.run / "protocol.json").read_text())
assert (args.run / "exit-code.txt").read_text().strip() == "0"
assert (args.run / "compiler.txt").read_text().strip() == p["expected_compiler"]
assert json.loads((args.run / "complete.json").read_text()) == {"completed_cases": 3}
assert (
    hashlib.sha256((args.original / "protocol.json").read_bytes()).hexdigest()
    == p["baseline_protocol_sha256"]
)
assert (
    hashlib.sha256((args.run / "Observe.hs").read_bytes()).hexdigest()
    == p["observer_sha256"]
)
for name, digest in p["source_sha256"].items():
    assert (
        hashlib.sha256((args.run / "source" / name).read_bytes()).hexdigest() == digest
    )
frames = list(range(0, p["steps"] + 1, p["stride"]))
results = []
for label, constructor in p["cases"]:
    root = args.run / "spatial"
    assert (
        (root / (label + ".scenario.txt"))
        .read_text()
        .startswith(f"Constructor: {constructor}\nSeed: {p['seed']}\n")
    )
    assert not (root / (label + ".stderr.log")).read_bytes()
    assert not (root / (label + ".stdout.log")).read_bytes()
    assert (root / (label + ".scenario.txt")).read_bytes() == (
        args.original / "spatial" / (label + ".scenario.txt")
    ).read_bytes()
    summaries = list(csv.DictReader((root / (label + ".summary.csv")).open()))
    assert [int(r["time"]) for r in summaries] == list(range(1001))
    assert all(math.isfinite(float(v)) for r in summaries for v in r.values())
    agents, cells = defaultdict(dict), defaultdict(dict)
    for row in csv.DictReader((root / (label + ".agents.csv")).open()):
        t, aid = int(row["time"]), int(row["id"])
        assert t in frames and aid not in agents[t]
        assert all(math.isfinite(float(v)) for k, v in row.items() if k != "culture")
        agents[t][aid] = row
    for row in csv.DictReader((root / (label + ".cells.csv")).open()):
        t = int(row["time"])
        coord = int(row["x"]), int(row["y"])
        assert t in frames and coord not in cells[t] and all(0 <= v < 51 for v in coord)
        assert all(math.isfinite(float(v)) for v in row.values())
        cells[t][coord] = row
    assert set(cells) == set(agents) == set(frames)
    assert all(len(x) == 2601 for x in cells.values())
    assert not list(csv.DictReader((root / (label + ".trades.csv")).open()))
    profiles = []
    for t in frames:
        summary = summaries[t]
        assert len(agents[t]) == int(summary["population"])
        for field in ["sugar", "spice"]:
            assert math.isclose(
                sum(float(a[field]) for a in agents[t].values()),
                float(summary["agent_" + field]),
                rel_tol=1e-12,
                abs_tol=1e-8,
            )
            assert math.isclose(
                sum(float(c[field]) for c in cells[t].values()),
                float(summary["environment_" + field]),
                rel_tol=1e-12,
                abs_tol=1e-8,
            )
        assert math.isclose(
            sum(float(c["pollution"]) for c in cells[t].values()),
            float(summary["pollution"]),
            rel_tol=1e-12,
            abs_tol=1e-8,
        )
        positions = {aid: (int(a["x"]), int(a["y"])) for aid, a in agents[t].items()}
        occupied = [
            (int(c["occupier"]), coord)
            for coord, c in cells[t].items()
            if int(c["occupier"]) >= 0
        ]
        ids = [aid for aid, coord in occupied]
        mismatches = [
            {"id": aid, "cell": coord}
            for aid, coord in occupied
            if aid not in positions or positions[aid] != coord
        ]
        diagonal = [0] * 101
        for coord in positions.values():
            diagonal[sum(coord)] += 1
        profiles.append(
            {
                "time": t,
                "population": len(positions),
                "occupied_cells": len(occupied),
                "duplicate_occupier_ids": len(ids) - len(set(ids)),
                "agents_missing_from_occupancy": sorted(set(positions) - set(ids)),
                "occupancy_position_disagreements": mismatches,
                "diagonal_agent_counts": diagonal,
                "pollution_total": float(summary["pollution"]),
                "pollution_max": max(float(c["pollution"]) for c in cells[t].values()),
                "polluted_cells": sum(
                    float(c["pollution"]) > 0 for c in cells[t].values()
                ),
            }
        )
    original = list(
        csv.DictReader((args.original / "spatial" / (label + ".summary.csv")).open())
    )
    results.append(
        {
            "case": label,
            "snapshots": len(frames),
            "summary_rows": len(summaries),
            "agent_observations": sum(len(a) for a in agents.values()),
            "cell_observations": sum(len(c) for c in cells.values()),
            "final_population": int(summaries[-1]["population"]),
            "original_final_population": int(original[-1]["population"]),
            "profiles": profiles,
            "sha256": {
                f.name: hashlib.sha256(f.read_bytes()).hexdigest()
                for f in sorted(root.glob(label + ".*"))
            },
        }
    )
report = {
    "scope": (
        "Three corrected-source first-seed diagnostics; "
        "not a published qualitative criterion or whole-paper verdict."
    ),
    "cases": results,
    "source_hashes_verified": len(p["source_sha256"]),
    "auditor_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
with args.output.open("x") as f:
    json.dump(report, f, indent=2, allow_nan=False)
    f.write("\n")
print(
    json.dumps(
        [
            {k: v for k, v in r.items() if k not in ["profiles", "sha256"]}
            for r in results
        ],
        indent=2,
    )
)
