"""Bounded whole-model migration qualification; preserve all run artifacts."""

import csv
import hashlib
import json
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parent
evidence = root.parent
first = evidence / "weaver-spice-observer-correction-001"
prior = json.loads((evidence / "weaver-spice-isolated-ensemble-001/protocol.json").read_text())
source = Path(prior["reference_source"]) if "reference_source" in prior else evidence.parent / "sugarscape-weaver-candidate/sugarscape.nlogo"
observed = first / "observed.nlogo"
runtime = Path(prior["runtime"])
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(source) == "e61e2a820ea3cde7c3d2855314bf82f7a3121666345644b138be1d1d905f7645"
assert digest(observed) == prior["source_sha256"]
assert digest(runtime / "NetLogo.jar") == prior["jar_sha256"]
cases = [
    ("preset2-plain", source, "", True),
    ("preset2-observed", observed, "", False),
    ("vision15-observed", observed, " set maxVision 15", False),
]
protocol = {
    "purpose": "Qualify recovered 2017 NetLogo migration candidate, not authenticate 2009 model or establish a wave result.",
    "seed": 602352629,
    "steps": 1000,
    "cases": [name for name, _, _, _ in cases],
    "native_preset": "preset2: 400 agents, metabolism 0..4, vision 1..10, corner ceiling(sqrt(500))=23, sugar +1 every 2 ticks",
    "diagnostic": "Third case changes only maximum vision to 15 before setup.",
    "observer": "Existing with-local-randomness reporters; plain versus observed population must match at all 1001 frames.",
    "limits": {"seconds_per_case": 240, "java_heap_mib": 512, "java_active_processors": 1},
    "source_sha256": digest(source),
    "observed_sha256": digest(observed),
    "jar_sha256": digest(runtime / "NetLogo.jar"),
    "runner_sha256": digest(Path(__file__)),
}
with (root / "protocol.json").open("x") as stream:
    json.dump(protocol, stream, indent=2)
populations = {}
for name, model, override, plain in cases:
    folder = root / name
    folder.mkdir()
    xml = (first / "experiment.xml").read_text().replace(
        "preset4 setup false", f"preset2{override} setup false"
    )
    if plain:
        for metric in ["observed-agent-sugar", "observed-agent-spice", "observed-site-sugar", "observed-site-spice", "observed-agent-states"]:
            xml = xml.replace(f"<metric>{metric}</metric>", "")
    (folder / "experiment.xml").write_text(xml)
    command = json.loads((first / "command.json").read_text())
    for flag, value in [("--model", model), ("--setup-file", folder / "experiment.xml"), ("--table", folder / "trajectory.csv")]:
        command[command.index(flag) + 1] = str(value)
    (folder / "command.json").write_text(json.dumps(command, indent=2))
    started = time.monotonic()
    with (folder / "stdout.log").open("wb") as out, (folder / "stderr.log").open("wb") as err:
        result = subprocess.run(command, cwd=runtime, stdout=out, stderr=err, timeout=240)
    (folder / "exit.json").write_text(json.dumps({"exit_code": result.returncode, "elapsed_seconds": time.monotonic() - started}))
    result.check_returncode()
    assert not (folder / "stderr.log").read_bytes()
    with (folder / "trajectory.csv").open() as stream:
        rows = list(csv.reader(stream))
    records = [dict(zip(rows[6], row, strict=True)) for row in rows[7:]]
    assert [int(row["[step]"]) for row in records] == list(range(1001))
    populations[name] = [int(row["count agents"]) for row in records]
    assert populations[name][0] == 400
    print(name, populations[name][-1], flush=True)
assert populations["preset2-plain"] == populations["preset2-observed"]
(root / "qualification.json").write_text(json.dumps({
    "plain_observed_population_equal_all_1001_frames": True,
    "final_populations": {name: values[-1] for name, values in populations.items()},
    "files_sha256": {str(path.relative_to(root)): digest(path) for path in sorted(root.glob("*/*")) if path.is_file()},
}, indent=2))
