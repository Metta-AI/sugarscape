set -eu
cd /work
trap 'rc=$?; printf "%s\n" "$rc" > /work/exit-code.txt' EXIT
mkdir spatial
sha256sum /prior/observe > binary-sha256.txt
timeout 240 /prior/observe mkParamsAnimationII_6 602352629 1000 1 spatial/migration > spatial/migration.stdout.log 2> spatial/migration.stderr.log
timeout 240 /prior/observe migrationVision15 602352629 1000 1 spatial/migration_vision15 > spatial/migration_vision15.stdout.log 2> spatial/migration_vision15.stderr.log
printf '{"completed_cases":2}\n' > complete.json
