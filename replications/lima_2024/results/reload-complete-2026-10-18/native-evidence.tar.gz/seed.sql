INSERT INTO m3 (agent_id,data,path) VALUES (399,'[0 3 6]','1-3');
