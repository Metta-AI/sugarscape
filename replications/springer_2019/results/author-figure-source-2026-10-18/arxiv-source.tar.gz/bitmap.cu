

template<int N, int C = (N + 63) / 64>
class Bitmap {
 public:
  void clear(int pos) {
    assert(pos < N);
    int cid = pos / 64;
    int offset = pos % 64;
    uint64_t mask = 1ULL << offset;
    uint64_t prev;  bool success = false;

    do {
      prev = atomicAnd(&containers_[cid], ~mask);
      success = (prev & mask) != 0;
    } while (!success);

    if (__popcll(prev) == 1) {
      next.clear(cid);
    }
  }

 private:
  uint64_t containers_[C];
  Bitmap<(C + 63) / 64> next;
}

template<int N>
class Bitmap<N, 1> {
 public:
  void clear(int pos) {
    assert(pos < N);
    uint64_t mask = 1ULL << pos;
    uint64_t prev;  bool success = false;

    do {
      prev = atomicAnd(&containers_[0], ~mask);
      success = (prev & mask) != 0;
    } while (!success);
  }

 private:
  uint64_t containers_[1];
}