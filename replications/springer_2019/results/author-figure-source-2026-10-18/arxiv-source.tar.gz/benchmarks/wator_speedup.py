# libraries
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
 
# Data
df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/oopsla2019/benchmarks/benchmark_result_soaalloc.csv")
soa_alloc = df[df.columns[0]].values/1000.0

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/oopsla2019/benchmarks/benchmark_result_soaalloc_no_coal.csv")
soa_alloc_no_coal = df[df.columns[0]].values/1000.0

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/oopsla2019/benchmarks/benchmark_result_soaalloc_no_rotl.csv")
soa_alloc_no_rotl = df[df.columns[0]].values/1000.0

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/oopsla2019/benchmarks/benchmark_result_soaalloc_no_rotl_no_coal.csv")
soa_alloc_no_rotl_no_coal = df[df.columns[0]].values/1000.0


#soa_alloc_num_fish = df[df.columns[4]].values
#soa_alloc_reserved_fish = df[df.columns[5]].values
#soa_alloc_num_sharks = df[df.columns[2]].values
#soa_alloc_reserved_sharks = df[df.columns[3]].values

#soa_alloc_relative_perf = soa_alloc / (soa_alloc_num_fish+soa_alloc_num_sharks)

#soa_alloc_reserved = soa_alloc_reserved_fish+soa_alloc_reserved_sharks
#soa_alloc_used =soa_alloc_num_fish+soa_alloc_num_sharks
#soa_alloc_waste = soa_alloc_reserved-soa_alloc_used
#print(min(soa_alloc))

#num_fish = df[df.columns[2]].values
#num_sharks = df[df.columns[4]].values
#print(len(num_fish))

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/ecoop2019/benchmarks/wator/wator_halloc.csv")
halloc = df[df.columns[0]].values/1000.0

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/ecoop2019/benchmarks/wator/wator_mallocmc.csv")
scatter_alloc = df[df.columns[0]].values/1000.0

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/ecoop2019/benchmarks/wator/wator_baseline_aos.csv")
baseline_aos = df[df.columns[0]].values/1000.0

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/ecoop2019/benchmarks/wator/wator_baseline_soa.csv")
baseline_soa = df[df.columns[0]].values/1000.0

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/oopsla2019/benchmarks/benchmark_result_bitmap.csv")
bitmap_alloc = df[df.columns[0]].values/1000.0

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/splash2018-src/bench_titech/bench_titech_cuda_allocator.csv")
cuda_alloc = df[df.columns[0]].values/1000.0

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/splash2018-src/bench_titech/bench_titech_aosalloc_sorted.csv")
aos_alloc_sorted = df[df.columns[0]].values/1000.0

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/splash2018-src/bench_titech/bench_titech_aosalloc_unsorted.csv")
aos_alloc_unsorted = df[df.columns[0]].values/1000.0

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/splash2018-src/bench_titech/bench_titech_mallocmc_4096_sorted.csv")
mallocmc_sorted = df[df.columns[0]].values/1000.0
 
# multiple line plot
fig, ax1 = plt.subplots(figsize=(6,3.0))
ax1.grid(color='lightgray')
#plt.figure(figsize=(6,3))
ax1.plot(soa_alloc, marker='^', markersize=10, linewidth=1, markevery=(0,100), label="DynaSOAr")
ax1.plot(soa_alloc_no_coal, marker='X', markersize=10, linewidth=1, markevery=(43,100),label="DynaSOAr-NoCoal")
ax1.plot(soa_alloc_no_rotl, marker='p', markersize=10, linewidth=1, markevery=(29,100),label="DynaSOAr-NoShift")
#ax1.plot(scatter_alloc, marker='x', color='red', linewidth=1, markevery=50,label="MallocMC")
#ax1.plot(halloc, marker='o', color='orange', linewidth=1, markevery=50,label="Halloc")
ax1.plot(bitmap_alloc, marker='v', markersize=10, linewidth=1, markevery=(14,100),label="BitmapAlloc")
ax1.plot(soa_alloc_no_rotl_no_coal, marker='P', markersize=10, linewidth=1, markevery=(57,100),label="DynaSOAr-NoCoal-NoShift")

#ax1.plot(baseline_aos, marker='d', color='gray', linewidth=1, markevery=50,label="Baseline (AOS)")
#ax1.plot(baseline_soa, marker='P', color='darkgray', linewidth=1, markevery=50,label="Baseline (SOA)")

#ax1.plot( cuda_alloc, marker='', color='green', linewidth=1, linestyle='dashed', label="CUDA Alloc.")
#ax1.plot( aos_alloc_sorted, marker='v', color='purple', linewidth=1,markevery=50, linestyle='dashed', label="AosAlloc (sorted)")
#ax1.plot( aos_alloc_unsorted, marker='*', color='magenta', linewidth=1,markevery=45, linestyle='dashed', label="AosAlloc")
#ax1.plot( mallocmc_sorted, marker='^', color='green', linewidth=1,markevery=50, linestyle='dashed', label="MallocMC (sorted)")

plt.legend(fancybox=False, loc=1,ncol=2, prop={'size': 9})
ax1.set_yscale('log')   #symlog?
ax1.set_ylabel('Iteration Running Time (ms)', color='black', size=10)
ax1.set_xlim(0, 500)
ax1.set_ylim(0,600)

#ax2.fill_between(range(999), [0]*999, soa_alloc_reserved,facecolor='black', alpha=0.15)
#ax2.fill_between(range(999), [0]*999, soa_alloc_reserved,facecolor='orange', alpha=0.15)
#ax2.fill_between(range(999), [0]*999, soa_alloc_used,facecolor='black', alpha=0.15)
#ax1.set_xlabel('Iterations (time)', color='black')
ax1.tick_params('y', colors='black')
ax1.set_xlim(0, 500)
ax1.set_ylim(0)
ax1.set_facecolor((1, 1, 1))

#plt.ticklabel_format(style='sci', axis='y', scilimits=(0,0))
plt.show()
