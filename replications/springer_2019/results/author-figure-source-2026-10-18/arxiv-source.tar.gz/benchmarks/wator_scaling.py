# libraries
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import itertools

# Data
df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/oopsla2019/benchmarks/wator_soaalloc_scaling.csv")
soa_runtime_all = np.array(df[df.columns[0]].values)
soa_iteration = np.array(df[df.columns[1]].values)
soa_runtime = soa_runtime_all - soa_iteration
soa_alloc_size = [32*(x+1) for x in list(range(len(soa_runtime_all)))]
soa_runtime_2 = soa_runtime/soa_alloc_size
soa_runtime_all_2 = soa_runtime_all/soa_alloc_size

soa_used = np.array(df[df.columns[4]].values) + np.array(df[df.columns[6]].values)
soa_alloc = np.array(df[df.columns[5]].values) + np.array(df[df.columns[7]].values)
soa_frag = (soa_alloc - soa_used) / soa_alloc




df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/oopsla2019/benchmarks/wator_mallocmc_scaling.csv")
mc_runtime_all = np.array(df[df.columns[1]].values)
mc_iteration = np.array(df[df.columns[2]].values)
mc_runtime = mc_runtime_all - mc_iteration
mc_alloc_size = [32*(x+1) for x in list(range(len(mc_runtime_all)))]
mc_runtime_2 = mc_runtime / mc_alloc_size



df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/oopsla2019/benchmarks/wator_halloc_scaling.csv")
halloc_runtime_all = np.array(df[df.columns[1]].values)
halloc_iteration = np.array(df[df.columns[2]].values)
halloc_runtime = halloc_runtime_all - halloc_iteration
halloc_alloc_size = [32*(x+1) for x in list(range(len(halloc_runtime_all)))]
halloc_runtime_2 = halloc_runtime / halloc_alloc_size


df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/oopsla2019/benchmarks/wator_bitmap_scaling.csv")
bitmap_runtime_all = np.array(df[df.columns[1]].values)
bitmap_iteration = np.array(df[df.columns[2]].values)
bitmap_runtime = bitmap_runtime_all - bitmap_iteration
bitmap_alloc_size = [32*(x+1) for x in list(range(len(bitmap_runtime_all)))]
bitmap_runtime_2 = bitmap_runtime / bitmap_alloc_size


df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/oopsla2019/benchmarks/wator_cuda_scaling.csv")
cuda_runtime_all = np.array(df[df.columns[1]].values)
cuda_iteration = np.array(df[df.columns[2]].values)
cuda_runtime = cuda_runtime_all - cuda_iteration
cuda_alloc_size = [32*(x+1) for x in list(range(len(cuda_runtime_all)))]
cuda_runtime_2 = cuda_runtime / cuda_alloc_size

# multiple line plot
fig, ax1 = plt.subplots(figsize=(6,3.0*1.04))
ax1.grid(color='lightgray')
plt.rcParams["axes.edgecolor"] = "black"
plt.rcParams["axes.linewidth"] = 1

ax1.set_facecolor((1, 1, 1))
#plt.figure(figsize=(6,3))

#ax1.plot( cuda_alloc, marker='', color='green', linewidth=1, linestyle='dashed', label="CUDA Alloc.")
#ax1.plot( aos_alloc_sorted, marker='v', color='purple', linewidth=1,markevery=50, linestyle='dashed', label="AosAlloc (sorted)")
#ax1.plot( aos_alloc_unsorted, marker='*', color='magenta', linewidth=1,markevery=45, linestyle='dashed', label="AosAlloc")
#ax1.plot( mallocmc_sorted, marker='^', color='green', linewidth=1,markevery=50, linestyle='dashed', label="MallocMC (sorted)")


ax2 = ax1.twinx()
ax2.grid(color='lightgray')
ax2.grid(None)
ax2.fill_between(soa_alloc_size, [0]*len(soa_frag), soa_frag,facecolor='black',alpha=0.15)
#ax2.fill_between(range(999), [0]*999, num_sharks,facecolor='red',alpha=0.15)
#ax2.fill_between(range(999), [0]*999, soa_alloc_reserved,facecolor='black', alpha=0.15)
#ax2.fill_between(range(999), [0]*999, soa_alloc_reserved,facecolor='orange', alpha=0.15)
#ax2.fill_between(range(999), [0]*999, soa_alloc_used,facecolor='black', alpha=0.15)
#ax2.fill_between(soa_alloc_size, [0]*len(soa_alloc_waste), soa_alloc_waste, facecolor='black', alpha=0.15)
#ax2.legend(fancybox=False, loc=0)

a0 = ax1.plot(soa_alloc_size,soa_runtime, marker='^', markersize=10,  linewidth=1, markevery=(0, 32), label="DynaSOAr")
plt.axvline(x=soa_alloc_size[-1], linestyle='dotted', color=a0[0].get_color(), marker='^', markersize=10)


a1 = ax1.plot(mc_alloc_size, mc_runtime, marker='X', markersize=10, linewidth=1, markevery=(8, 32), label="MallocMC")
plt.axvline(x=mc_alloc_size[-1], linestyle='dotted', color=a1[0].get_color(), marker='X', markersize=10)

a2 = ax1.plot(halloc_alloc_size, halloc_runtime, marker='o', markersize=10, linewidth=1, markevery=(16, 32), label="Halloc")
plt.axvline(x=halloc_alloc_size[-1], linestyle='dotted', color=a2[0].get_color(), marker='o', markersize=10)

a25 = ax1.plot(bitmap_alloc_size, bitmap_runtime, marker='v', markersize=10, linewidth=1, markevery=(24, 32), label="BitmapAlloc")
plt.axvline(x=bitmap_alloc_size[-1], linestyle='dotted', color=a25[0].get_color(), marker='v', markersize=10)

a3 = ax1.plot(cuda_alloc_size, cuda_runtime, marker='*', markersize=10, linewidth=1, markevery=(6, 32), label="CUDA Allocator")
plt.axvline(x=cuda_alloc_size[-1], linestyle='dotted', color=a3[0].get_color(), marker='*', markersize=10)

ax1.plot(soa_alloc_size,soa_runtime_all, linestyle='dashed', marker='P', markersize=10,  linewidth=1, markevery=(12, 32), label="DynaSOAr (+enumeration)")


plt.axvline(x=2560, linestyle='dashed', color='black')
plt.text(2250, 0.985, "Figure 10 problem size", rotation=90, multialignment='left', verticalalignment='top')


#ax1.plot(scatter_alloc_size, scatter_alloc, marker='x', color='red', linewidth=1, markevery=8,label="MallocMC")
#ax1.plot(halloc_size,halloc, marker='o', color='orange', linewidth=1, markevery=250,label="Halloc")
#ax1.plot(aos_alloc, marker='*', color='magenta', linewidth=1, markevery=275,label="AosAlloc")
#ax1.plot(cuda_alloc, linestyle='dashed', color='green', linewidth=1, markevery=250,label="CUDA Alloc.")
ax1.set_ylabel('Total Running Time (ms)', color='black', size=10)
#ax1.set_xlim(0, 20)
#ax1.set_ylim(0,28000)


#plt.axvline(x=len(halloc), color='orange',linewidth=1, marker='o')
#plt.axvline(x=len(cuda_alloc), color='green', linestyle='dashed',linewidth=1)
#plt.axvline(x=len(scatter_alloc), color='red',linewidth=1, marker='x')
#plt.axvline(x=len(aos_alloc), color='magenta',linewidth=1, marker='*')

h1, l1 = ax1.get_legend_handles_labels()
h2, l2 = ax2.get_legend_handles_labels()
ax2.legend(h1+h2, l1+l2, loc=1, fancybox=False, prop={'size': 9}, ncol=2)

ax2.set_ylabel('DynaSOAr frag.: (#alloc.-#used)/#alloc', color='black', size=10)
#ax1.set_xlabel('Problem Size (#cells in y direction)', color='black')
#ax2.tick_params('y', colors='black')
#plt.xticks([0, 7-1, 15-1, 23-1, 31-1], (65536, 524288,1048576,1572864,2097152))
#ax2.set_xlim(0, len(soa_alloc_vw))
#ax2.set_ylim(0,1)
ax1.ticklabel_format(style='sci', axis='y', scilimits=(0,0))
ax2.set_ylim(0,1)
ax1.set_ylim(0,2.5*10000)
ax1.set_xlim(0,10000) #soa_alloc_size[-1])
ax1.set_axisbelow(True)
ax2.set_axisbelow(True)

#ax1.set_yscale('log')

plt.show()
