# -*- coding: utf-8 -*-
# libraries
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
 
# Data
df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/oopsla2019/benchmarks/wator_frag.csv")
#soa_alloc = df[df.columns[0]].values/1000.0
soa_alloc_num_fish = df[df.columns[1]].values
soa_alloc_reserved_fish = df[df.columns[2]].values
soa_alloc_num_sharks = df[df.columns[3]].values
soa_alloc_reserved_sharks = df[df.columns[4]].values

#soa_alloc_relative_perf = soa_alloc / (soa_alloc_num_fish+soa_alloc_num_sharks)

soa_alloc_reserved = soa_alloc_reserved_fish+soa_alloc_reserved_sharks
soa_alloc_used =soa_alloc_num_fish+soa_alloc_num_sharks
soa_alloc_waste_5 = (soa_alloc_reserved-soa_alloc_used)/soa_alloc_reserved




df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/oopsla2019/benchmarks/wator_frag_1.csv")
#soa_alloc = df[df.columns[0]].values/1000.0
soa_alloc_num_fish = df[df.columns[1]].values
soa_alloc_reserved_fish = df[df.columns[2]].values
soa_alloc_num_sharks = df[df.columns[3]].values
soa_alloc_reserved_sharks = df[df.columns[4]].values

#soa_alloc_relative_perf = soa_alloc / (soa_alloc_num_fish+soa_alloc_num_sharks)

soa_alloc_reserved = soa_alloc_reserved_fish+soa_alloc_reserved_sharks
soa_alloc_used =soa_alloc_num_fish+soa_alloc_num_sharks
soa_alloc_waste_1 = (soa_alloc_reserved-soa_alloc_used)/soa_alloc_reserved





df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/oopsla2019/benchmarks/wator_frag_10.csv")
#soa_alloc = df[df.columns[0]].values/1000.0
soa_alloc_num_fish = df[df.columns[1]].values
soa_alloc_reserved_fish = df[df.columns[2]].values
soa_alloc_num_sharks = df[df.columns[3]].values
soa_alloc_reserved_sharks = df[df.columns[4]].values

#soa_alloc_relative_perf = soa_alloc / (soa_alloc_num_fish+soa_alloc_num_sharks)

soa_alloc_reserved = soa_alloc_reserved_fish+soa_alloc_reserved_sharks
soa_alloc_used =soa_alloc_num_fish+soa_alloc_num_sharks
soa_alloc_waste_10 = (soa_alloc_reserved-soa_alloc_used)/soa_alloc_reserved





df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/oopsla2019/benchmarks/wator_frag_2.csv")
#soa_alloc = df[df.columns[0]].values/1000.0
soa_alloc_num_fish = df[df.columns[1]].values
soa_alloc_reserved_fish = df[df.columns[2]].values
soa_alloc_num_sharks = df[df.columns[3]].values
soa_alloc_reserved_sharks = df[df.columns[4]].values

#soa_alloc_relative_perf = soa_alloc / (soa_alloc_num_fish+soa_alloc_num_sharks)

soa_alloc_reserved = soa_alloc_reserved_fish+soa_alloc_reserved_sharks
soa_alloc_used =soa_alloc_num_fish+soa_alloc_num_sharks
soa_alloc_waste_2 = (soa_alloc_reserved-soa_alloc_used)/soa_alloc_reserved

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/ecoop2019/benchmarks/wator/wator_alloc.csv")
num_alloc = df[df.columns[0]].values
num_dealloc = df[df.columns[1]].values

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/splash2018-src/bench_titech/bench_titech_halloc.csv")
halloc = df[df.columns[0]].values/1000.0

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/splash2018-src/bench_titech/bench_titech_mallocmc_4096.csv")
scatter_alloc = df[df.columns[0]].values/1000.0

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/splash2018-src/bench_titech/bench_titech_cuda_allocator.csv")
cuda_alloc = df[df.columns[0]].values/1000.0

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/splash2018-src/bench_titech/bench_titech_aosalloc_sorted.csv")
aos_alloc_sorted = df[df.columns[0]].values/1000.0

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/splash2018-src/bench_titech/bench_titech_aosalloc_unsorted.csv")
aos_alloc_unsorted = df[df.columns[0]].values/1000.0

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/splash2018-src/bench_titech/bench_titech_mallocmc_4096_sorted.csv")
mallocmc_sorted = df[df.columns[0]].values/1000.0
 
# multiple line plot
fig, ax1 = plt.subplots(figsize=(6,3.0))
ax1.grid(color='lightgray')
ax1.grid(color='lightgray')
plt.rcParams["axes.edgecolor"] = "black"
plt.rcParams["axes.linewidth"] = 1

#plt.figure(figsize=(6,3))
p1=ax1.plot(soa_alloc_waste_1, marker='*',  markersize=10, linewidth=1, markevery=(10,100), label="r = 1")
p1=ax1.plot(soa_alloc_waste_2, marker='p',  markersize=10, linewidth=1, markevery=(35,100), label="r = 2")
p1=ax1.plot(soa_alloc_waste_5, marker='P',  markersize=10, linewidth=1, markevery=(60,100), label="r = 5")
p1=ax1.plot(soa_alloc_waste_10, marker='X',  linestyle='dotted', markersize=10, linewidth=1, markevery=(85,100), label="lowest possible")

#p2=ax1.plot(num_sharks, marker='X', markersize=10, linewidth=1, markevery=(16,100), label="#sharks")
#p3=ax1.plot(soa_alloc_reserved, marker='^', markersize=10, linewidth=1, markevery=(33,100), linestyle='dashed',label="#allocated slots")
#p4=ax1.plot( soa_alloc_used, marker='v', markersize=10, linewidth=1, markevery=(50,100), linestyle='dashed', label="#used slots (#objects)")
#ax1.plot( aos_alloc_sorted, marker='v', color='purple', linewidth=1,markevery=50, linestyle='dashed', label="AosAlloc (sorted)")
#ax1.plot( aos_alloc_unsorted, marker='*', color='magenta', linewidth=1,markevery=45, linestyle='dashed', label="AosAlloc")
#ax1.plot( mallocmc_sorted, marker='^', color='green', linewidth=1,markevery=50, linestyle='dashed', label="MallocMC (sorted)")

#ax1.set_yscale('log')
ax1.set_ylabel('fragmentation: (#alloc. – #used) / #alloc', color='black', size=10)
ax1.set_xlim(0, 500)
ax1.set_ylim(0)

#ax1.fill_between(range(500), soa_alloc_used, soa_alloc_reserved,facecolor='black',alpha=0.15)

#ax2 = ax1.twinx()
#ax2.grid(color='lightgray', linestyle='dotted')
#ax2.set_ylabel('#new/deleted objects', color='black', size=10)
#p5=ax2.plot(num_alloc, linestyle='dotted', marker='P', markersize=10, linewidth=1, markevery=(66,100), label='#new objects')
#p6=ax2.plot(num_dealloc,  linestyle='dotted', marker='h',markersize=10, linewidth=1, markevery=(83,100), label='#deleted objects')

h1, l1 = ax1.get_legend_handles_labels()
#h2, l2 = ax2.get_legend_handles_labels()
ax1.legend(h1, l1, loc=1, prop={'size': 9}, ncol=2)
#ax2.fill_between(range(999), [0]*999, num_sharks,facecolor='red',alpha=0.15)
#ax2.fill_between(range(999), [0]*999, soa_alloc_reserved,facecolor='black', alpha=0.15)
#ax2.fill_between(range(999), [0]*999, soa_alloc_reserved,facecolor='orange', alpha=0.15)
#ax2.fill_between(range(999), [0]*999, soa_alloc_used,facecolor='black', alpha=0.15)
#ax1.set_xlabel('Iterations (time)', color='black')
ax1.tick_params('y', colors='black')
ax1.set_xlim(0, 500)
ax1.set_ylim(0)
ax1.ticklabel_format(style='sci', axis='y', scilimits=(0,0))
#ax2.ticklabel_format(style='sci', axis='y', scilimits=(0,0))
ax1.set_facecolor((1, 1, 1))

plt.show()
