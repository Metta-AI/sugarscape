# libraries
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
 
# Data
df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/oopsla2019/benchmarks/linux_scal_soaalloc.csv")
soa_alloc_1 = np.array(df[df.columns[1]].values/1000.0)
soa_alloc = soa_alloc_1 / np.array(list(range(1, len(soa_alloc_1)+1)))

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/oopsla2019/benchmarks/linux_scal_mallocmc.csv")
mallocmc_1 = np.array(df[df.columns[1]].values/1000.0)
mallocmc = mallocmc_1 / np.array(list(range(1, len(mallocmc_1)+1)))


df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/oopsla2019/benchmarks/linux_scal_halloc.csv")
halloc_1 = np.array(df[df.columns[1]].values/1000.0)
halloc = halloc_1 / np.array(list(range(1, len(halloc_1)+1)))

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/oopsla2019/benchmarks/linux_scal_cuda.csv")
cuda_1 = np.array(df[df.columns[1]].values/1000.0)
cuda = cuda_1 / np.array(list(range(1, len(cuda_1)+1)))

df = pd.read_csv("/home/matthias/Documents/uni/ikra-cpp-paper/oopsla2019/benchmarks/linux_scal_bitmap.csv")
bitmap_1 = np.array(df[df.columns[1]].values/1000.0)
bitmap = bitmap_1 / np.array(list(range(1, len(bitmap_1)+1)))

#soa_alloc_num_fish = df[df.columns[4]].values
#soa_alloc_reserved_fish = df[df.columns[5]].values
#soa_alloc_num_sharks = df[df.columns[2]].values
#soa_alloc_reserved_sharks = df[df.columns[3]].values

#soa_alloc_relative_perf = soa_alloc / (soa_alloc_num_fish+soa_alloc_num_sharks)

#soa_alloc_reserved = soa_alloc_reserved_fish+soa_alloc_reserved_sharks
#soa_alloc_used =soa_alloc_num_fish+soa_alloc_num_sharks
#soa_alloc_waste = soa_alloc_reserved-soa_alloc_used
#print(min(soa_alloc))

#num_fish = df[df.columns[2]].values
#num_sharks = df[df.columns[4]].values
#print(len(num_fish))

 
# multiple line plot
fig, ax1 = plt.subplots(figsize=(6,3.0))
ax1.grid(color='lightgray')
#plt.rcParams["axes.edgecolor"] = "black"
#plt.rcParams["axes.linewidth"] = 1
#ax1.spines['bottom'].set_color('0.5')
#ax1.spines['top'].set_color('0.5')
#ax1.spines['right'].set_color('0.5')
#ax1.spines['left'].set_color('0.5')

#plt.figure(figsize=(6,3))
a0=ax1.plot(soa_alloc_1, marker='^', markersize=10, linewidth=1, markevery=(0,200), label="DynaSOAr")
plt.axvline(x=len(soa_alloc_1), linestyle='dotted', color=a0[0].get_color(), marker='^', markersize=10)

a1=ax1.plot(mallocmc_1, marker='X', markersize=10, linewidth=1, markevery=(40,200), label="MallocMC")
plt.axvline(x=len(mallocmc_1)+1, linestyle='dotted', color=a1[0].get_color(), marker='X', markersize=10)

a2=ax1.plot(halloc_1, marker='o', markersize=10, linewidth=1, markevery=(80,200), label="Halloc")
plt.axvline(x=len(halloc_1)+1, linestyle='dotted', color=a2[0].get_color(), marker='o', markersize=10)

a3= ax1.plot(bitmap_1, marker='v',markersize=10, linewidth=1, markevery=(120,200),label="BitmapAlloc")
plt.axvline(x=len(bitmap_1), linestyle='dotted', color=a3[0].get_color(), marker='v', markersize=10)

a4=ax1.plot(cuda_1, marker='*', markersize=10, linewidth=1, markevery=(15,200), label="CUDA Allocator")
plt.axvline(x=len(cuda_1), linestyle='dotted', color=a4[0].get_color(), marker='*', markersize=10)

#ax1.plot(scatter_alloc, marker='X',markersize=10, linewidth=1, markevery=(14,100),label="MallocMC")
#ax1.plot(halloc, marker='o', linewidth=1,markersize=10, markevery=(29,100),label="Halloc")
#ax1.plot(cuda_alloc, marker='*',markersize=10, linewidth=1, markevery=(57,100),label="CUDA Allocator")
#ax1.plot(baseline_soa, marker='P',markersize=10, linewidth=1, markevery=(71,100),label="Baseline (SOA)")
#ax1.plot(baseline_aos, marker='d',markersize=10, linewidth=1, markevery=(86,100),label="Baseline (AOS)")

#ax1.plot( cuda_alloc, marker='', color='green', linewidth=1, linestyle='dashed', label="CUDA Alloc.")
#ax1.plot( aos_alloc_sorted, marker='v', color='purple', linewidth=1,markevery=50, linestyle='dashed', label="AosAlloc (sorted)")
#ax1.plot( aos_alloc_unsorted, marker='*', color='magenta', linewidth=1,markevery=45, linestyle='dashed', label="AosAlloc")
#ax1.plot( mallocmc_sorted, marker='^', color='green', linewidth=1,markevery=50, linestyle='dashed', label="MallocMC (sorted)")

plt.legend(fancybox=False,ncol=1, prop={'size': 9},loc=1)
#ax1.set_yscale('log')   #symlog?
ax1.set_ylabel('Running Time (ms)', color='black', size=10)
ax1.set_xlim(0, 500)
ax1.set_ylim(0,1500)

#ax2.fill_between(range(999), [0]*999, soa_alloc_reserved,facecolor='black', alpha=0.15)
#ax2.fill_between(range(999), [0]*999, soa_alloc_reserved,facecolor='orange', alpha=0.15)
#ax2.fill_between(range(999), [0]*999, soa_alloc_used,facecolor='black', alpha=0.15)
#ax1.set_xlabel('Iterations (time)', color='black')
ax1.tick_params('y', colors='black')
ax1.set_xlim(0, 1024)
ax1.set_ylim(0)
ax1.set_facecolor((1, 1, 1))

#plt.ticklabel_format(style='sci', axis='y', scilimits=(0,0))
plt.show()

