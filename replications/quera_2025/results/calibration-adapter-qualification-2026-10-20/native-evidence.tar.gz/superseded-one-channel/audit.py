"""Audit the complete native Sugarscape MMD and automatic-differentiation workflow."""

from pathlib import Path
import csv
import hashlib
import json
import math
import statistics
import sys

root = Path(sys.argv[1])
output = Path(sys.argv[2])
assert not output.exists()
q = root / "qualification"
reference_pins = json.loads((root / "reference-pins.json").read_bytes())
for name, digest in reference_pins.items():
    assert (
        hashlib.sha256((root / "reference" / name).read_bytes()).hexdigest() == digest
    )
    assert (q / name).read_bytes() == (root / "reference" / name).read_bytes()
with (q / "wealth.csv").open() as f:
    rows = list(csv.DictReader(f))
assert [int(r["time"]) for r in rows] == list(range(50))
y = [float(r["observed"]) for r in rows]
xs = [[float(r[f"simulation_{i}"]) for r in rows] for i in [1, 2]]
assert all(math.isfinite(x) for vector in [y, *xs] for x in vector)
sigma = (
    statistics.median(
        [
            math.sqrt(math.fsum((a - b) ** 2 for a, b in zip(left, right, strict=True)))
            for left, right in [(xs[0], xs[1]), (xs[0], y), (xs[1], y)]
        ]
    )
    + sys.float_info.epsilon
)
kernel = [
    math.exp(
        -math.fsum((a - b) ** 2 for a, b in zip(left, right, strict=True))
        / (2 * sigma * sigma)
    )
    for left, right in [(xs[0], xs[1]), (xs[0], y), (xs[1], y)]
]
loss = -(kernel[0] - kernel[1] - kernel[2]) / (0.0001 * 50)
with (q / "loss-and-gradient.csv").open() as f:
    (result,) = list(csv.DictReader(f))
assert math.isclose(loss, float(result["native_loss"]), rel_tol=1e-10, abs_tol=1e-10)
assert math.isclose(loss, float(result["ad_loss"]), rel_tol=1e-10, abs_tol=1e-10)
with (q / "native-jacobians.csv").open() as f:
    jacobian_rows = list(csv.DictReader(f))
assert [(int(r["simulation"]), int(r["time"])) for r in jacobian_rows] == [
    (s, t) for s in [1, 2] for t in range(50)
]
assert all(
    math.isclose(
        float(r["value"]),
        xs[int(r["simulation"]) - 1][int(r["time"])],
        rel_tol=1e-12,
        abs_tol=1e-12,
    )
    for r in jacobian_rows
)
gradients = {}
for parameter in ["p1", "p6", "m_alpha", "m_beta", "w_alpha", "w_beta"]:
    j = [
        [float(r[parameter]) for r in jacobian_rows if int(r["simulation"]) == s]
        for s in [1, 2]
    ]
    derivatives = [
        -kernel[0]
        * math.fsum(
            (a - b) * (da - db)
            for a, b, da, db in zip(xs[0], xs[1], j[0], j[1], strict=True)
        )
        / sigma**2,
        -kernel[1]
        * math.fsum((a - b) * da for a, b, da in zip(xs[0], y, j[0], strict=True))
        / sigma**2,
        -kernel[2]
        * math.fsum((a - b) * da for a, b, da in zip(xs[1], y, j[1], strict=True))
        / sigma**2,
    ]
    gradient = -(derivatives[0] - derivatives[1] - derivatives[2]) / (0.0001 * 50)
    native = float(result[parameter])
    assert math.isfinite(native) and math.isclose(
        gradient, native, rel_tol=1e-9, abs_tol=1e-9
    )
    gradients[parameter] = {
        "independent": gradient,
        "native": native,
        "absolute_difference": abs(gradient - native),
    }
with (q / "flow-samples.csv").open() as f:
    samples = list(csv.DictReader(f))
assert len(samples) == 20 and all(
    len(r) == 7 and all(math.isfinite(float(x)) for x in r.values()) for r in samples
)
assert "No optimization" in (q / "scope.txt").read_text()
pins = json.loads((root / "provenance.json").read_bytes())["prior_runtime_pins"]
for name, digest in pins.items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest
hashes = {
    str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
    for p in sorted(q.rglob("*"))
    if p.is_file()
}
report = {
    "observed_states": 50,
    "simulated_states": 100,
    "native_jacobian_values": 600,
    "flow_samples": 20,
    "independent_loss": loss,
    "native_loss": float(result["native_loss"]),
    "ad_loss": float(result["ad_loss"]),
    "bandwidth": sigma,
    "gradients": gradients,
    "prior_runtime_pins_unchanged": True,
    "prior_seed0_agent_and_cell_csvs_byte_identical": True,
    "sha256": hashes,
    "scope": "End-to-end native model/loss/AD chain and flow sampling only. Bandwidth is held fixed in derivatives, matching the author ignore_derivatives rule. This is not a finite-difference unbiasedness test, posterior calibration or paper replication.",
}
output.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({k: v for k, v in report.items() if k not in ["sha256", "gradients"]}))
