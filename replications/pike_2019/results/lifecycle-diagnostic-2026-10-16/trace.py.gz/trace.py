import json
from pathlib import Path
import runpy
import sys

workspace = Path('/Users/relh/Code/workspace')
engine = workspace / 'sugarscape-pike-reference'
library = workspace / 'sugarscape-pike-library-reference'
runner = workspace / 'sugarscape-pike/replications/pike_2019/run_corrected.py'
base = Path(__file__).parent
sys.path[:0] = [str(engine / 'Common Resource- multi-level'), str(library), str(runner.parent)]
import NetAgent
from multilevel_mesa.multilevel_mesa import GroupAgent, MultiLevel_Mesa

stream = (base / 'events.jsonl').open('x')
native_die = NetAgent.NetAgent.die
native_buffer = GroupAgent.agent_buffer

def snapshot(agent):
    ml = agent.model.ml
    return {'agent': agent.unique_id, 'status': agent.status, 'position': agent.pos,
            'alive_registry': agent.unique_id in ml._agents,
            'scheduled': agent.unique_id in ml.schedule,
            'containing_groups': [key for key, group in ml.groups.items() if agent.unique_id in group.sub_agents],
            'reverse': {key: sorted(value) for key, value in ml.reverse_groups[agent.unique_id].items()} if agent.unique_id in ml.reverse_groups else {}}

def traced_die(self):
    before = snapshot(self)
    native_die(self)
    if self.status == 'dead':
        stream.write(json.dumps({'event': 'death', 'before': before, 'after': snapshot(self)}) + '\n')
        stream.flush()

def traced_buffer(self, shuffled=True):
    for agent in native_buffer(self, shuffled):
        if agent.type == 'agent' and agent.pos is None:
            stream.write(json.dumps({'event': 'dead_activation', 'group': self.unique_id,
                                    'group_registered': self.unique_id in self.model.ml.groups,
                                    'group_members': list(self.sub_agents), 'agent': snapshot(agent)}) + '\n')
            stream.flush()
        yield agent

native_remove_group = MultiLevel_Mesa._remove_groups_recursion
native_group_step = GroupAgent.group_step

def group_snapshot(ml, key):
    return {'group': key, 'scheduled': key in ml.schedule,
            'network_nodes': [{'id': node.unique_id, 'neighbors': [neighbor.unique_id for neighbor in ml.net.neighbors(node)]} for node in ml.net if node.unique_id == key],
            'parents': [gid for gid, group in ml.groups.items() if key in group.sub_agents],
            'reverse': {kind: sorted(ids) for kind, ids in ml.reverse_groups[key].items()} if key in ml.reverse_groups else {},
            'members': list(ml.groups[key].sub_agents) if key in ml.groups else []}

def traced_remove_group(self, key, kind):
    before = group_snapshot(self, key)
    native_remove_group(self, key, kind)
    stream.write(json.dumps({'event': 'remove_group', 'before': before, 'after': group_snapshot(self, key)}) + '\n')
    stream.flush()

def traced_group_step(self, *args, **kwargs):
    if self.unique_id not in self.model.ml.groups:
        stream.write(json.dumps({'event': 'deleted_group_activation', 'group': self.unique_id, 'members': list(self.sub_agents), 'snapshot': group_snapshot(self.model.ml, self.unique_id)}) + '\n')
        stream.flush()
    return native_group_step(self, *args, **kwargs)

MultiLevel_Mesa._remove_groups_recursion = traced_remove_group
GroupAgent.group_step = traced_group_step
NetAgent.NetAgent.die = traced_die
GroupAgent.agent_buffer = traced_buffer
sys.argv = [str(runner), str(engine), str(library), 'common-multi', '0', str(base / 'run')]
runpy.run_path(str(runner), run_name='__main__')
