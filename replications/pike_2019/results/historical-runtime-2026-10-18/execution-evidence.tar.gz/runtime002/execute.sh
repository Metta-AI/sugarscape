set -eu
cd /evidence
trap 'rc=$?; printf "%s\n" "$rc" > workflow-exit-code.txt' EXIT
python --version > python.txt
python -m pip --version > pip.txt
git --version > git.txt
python -m pip freeze > installed.txt
python -c 'import platform,mesa,numpy,scipy,pandas,networkx; assert platform.python_version()=="3.6.8"; assert (mesa.__version__,numpy.__version__,scipy.__version__,pandas.__version__,networkx.__version__)==("0.8.5","1.16.0","1.2.0","0.24.0","2.2")'
for variant in common-one common-multi; do
 set +e
 timeout 600 python /evidence/run.py /Users/relh/Code/workspace/sugarscape-pike-reference /Users/relh/Code/workspace/sugarscape-pike-library-reference "$variant" 0 "/evidence/$variant" > "$variant.stdout" 2> "$variant.stderr"
 rc=$?
 set -e
 printf '%s\n' "$rc" > "$variant-exit-code.txt"
 test "$rc" -eq 0
done
