"""Audit complete historical-runtime controls without treating overflow as success."""
import csv
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path

root = Path(__file__).resolve().parent
assert (root / 'workflow-exit-code.txt').read_text().strip() == '0'
protocol = json.loads((root / 'protocol.json').read_text())
assert hashlib.sha256((root / 'run.py').read_bytes()).hexdigest() == protocol['adapter_sha256']
assert hashlib.sha256((root / 'source-proof.json').read_bytes()).hexdigest() == protocol['source_proof_sha256']
results = []
for variant in ['common-one', 'common-multi']:
    run = root / variant
    assert (root / (variant + '-exit-code.txt')).read_text().strip() == '0'
    assert json.loads((run / 'exit.json').read_text()) == {'exit_code': 0}
    manifest = json.loads((run / 'manifest.json').read_text())
    assert [manifest[k] for k in ['python','numpy','mesa','networkx']] == ['3.6.8','1.16.0','0.8.5','2.2']
    assert [manifest[k] for k in ['numpy_seed','policy_random_seed','mesa_seed','steps']] == [0,0,42,1000]
    assert manifest['runner_sha256'] == protocol['adapter_sha256']
    initial = json.loads((run / 'initial-agents.json').read_text())
    previous = {r['id'] for r in initial}
    assert len(initial) == len(previous) == 200
    observed = json.loads((run / 'observations.json').read_text())
    assert [r['step'] for r in observed] == list(range(1,1001))
    health = defaultdict(set)
    nonfinite = []
    count = 0
    with (run / 'health.csv').open() as stream:
        for row in csv.DictReader(stream):
            step, agent = int(row['Step']), int(row['Agent'])
            assert 1 <= step <= 1000 and agent not in health[step]
            health[step].add(agent)
            count += 1
            if not all(math.isfinite(float(row[key])) for key in ['Sugar_Level','Spice_Level']):
                nonfinite.append(step)
    for row in observed:
        ids = set(row['agent_ids'])
        assert len(ids) == len(row['agent_ids']) == row['individual_agents']
        assert ids <= previous and ids == health[row['step']]
        previous = ids
    complete = json.loads((run / 'complete.json').read_text())
    assert complete['steps'] == 1000
    assert complete['individual_agents'] == len(previous)
    assert complete['native_reporter'] == observed[-1]['native_reporter']
    prices = json.loads((run / 'prices.json').read_text())
    assert all(str(int(k)) == k and 1 <= int(k) <= 1000 for k in prices)
    assert all(math.isfinite(p) and p > 0 for values in prices.values() for p in values)
    results.append({'variant':variant,'health_records':count,'nonfinite_health_records':len(nonfinite),'first_nonfinite_step':min(nonfinite) if nonfinite else None,'final_individual_agents':len(previous),'native_reporter':complete['native_reporter'],'finite_positive_prices':sum(len(v) for v in prices.values()),'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(run.iterdir()) if p.is_file()}})
output = {'scope':'Two seed-zero runtime sensitivity controls; reconstructed dependencies, not authenticated author runtime. No whole-paper verdict.','runs':results,'auditor_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
with (root / 'audit.json').open('x') as stream:
    json.dump(output,stream,indent=2,allow_nan=False)
    stream.write('\n')
print(json.dumps([{k:v for k,v in r.items() if k != 'sha256'} for r in results],indent=2))
