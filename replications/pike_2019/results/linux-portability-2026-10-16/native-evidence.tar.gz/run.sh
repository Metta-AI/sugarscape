#!/bin/sh
set -u
cd /root/sugarscape/pike-portability-001
start=$(date +%s)
timeout --signal=TERM --kill-after=30s 3600 sh setup_and_pilot.sh > launcher.log 2>&1
code=$?
printf '{"exit_code":%s,"started_unix":%s,"finished_unix":%s,"limit_seconds":3600}\n' "$code" "$start" "$(date +%s)" > terminal.json
tar --exclude='./engine' --exclude='./library' -czf /root/sugarscape/pike-portability-evidence-001.tar.gz -C /root/sugarscape/pike-portability-001 .
# Leave the platform's 15-minute idle window for evidence retrieval.
exit "$code"
