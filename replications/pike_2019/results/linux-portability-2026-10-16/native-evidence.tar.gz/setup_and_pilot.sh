#!/bin/sh
set -eu
cd /root/sugarscape/pike-portability-001
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq git curl ca-certificates python3 python3-pip
python3 -m pip install uv==0.9.6
uv python install 3.11.14
uv venv --python 3.11.14 /root/sugarscape/pike-venv
uv pip install --python /root/sugarscape/pike-venv/bin/python Mesa==0.8.5 numpy==1.26.4 networkx==3.6.1 scipy==1.16.3
uv pip freeze --python /root/sugarscape/pike-venv/bin/python > requirements.txt
git -c alias.clone-lean='clone --filter=blob:none' clone-lean --no-checkout https://github.com/tpike3/SugarScape.git engine
git -C engine checkout --detach 585e53398f4f58e89ec184c83bb20819f0e4c96a
git -c alias.clone-lean='clone --filter=blob:none' clone-lean --no-checkout https://github.com/tpike3/multilevel_mesa.git library
git -C library checkout --detach 99d2091721076df9fff32e8b49a0e33e98c34a6f
/root/sugarscape/pike-venv/bin/python pilot.py
