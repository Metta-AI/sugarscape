import concurrent.futures
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
for name, digest in json.loads((root / "checksums.json").read_text()).items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest
plan = json.loads((root / "plan.json").read_text())


def run(condition):
    phase, start, stop = (condition[k] for k in ("phase", "start", "stop"))
    output = root / f"phase{phase}"
    command = [
        sys.executable,
        str(root / "run_segment.py"),
        str(root / f"frozen-phase{phase}"),
        str(root / "engine"),
        str(root / "library"),
        str(phase),
        str(start),
        str(stop),
        str(output),
    ]
    with (root / f"phase{phase}.log").open("x") as log:
        subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
        auditor = {1: "audit_phase1.py", 2: "audit_phase2.py", 3: "audit_phase3_movement.py"}[phase]
        subprocess.run(
            [
                sys.executable,
                str(root / auditor),
                str(output),
                "prefix",
                str(root / f"audit-phase{phase}"),
                "--start-index",
                str(start),
            ],
            stdout=log,
            stderr=subprocess.STDOUT,
            check=True,
        )
    return condition


with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    completed = list(pool.map(run, plan["conditions"]))
(root / "pilot-complete.json").write_text(json.dumps({"completed": completed}) + "\n")
