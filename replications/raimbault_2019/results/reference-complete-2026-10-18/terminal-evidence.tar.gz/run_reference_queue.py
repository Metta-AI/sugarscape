"""Replay explicit disjoint intervals with pinned assets and native output audits."""

import concurrent.futures
import hashlib
import json
import subprocess
import sys
import threading
import time
from pathlib import Path

root = Path(sys.argv[1]).resolve()
plan_path = Path(sys.argv[2]).resolve()
plan = json.loads(plan_path.read_text())
output = Path(sys.argv[3]).resolve()
assert plan["kind"] in ["validation", "production"]
assert 1 <= plan["workers"] <= 8
ranges = plan["ranges"]
assert ranges and ranges == sorted(ranges)
for index, (start, stop) in enumerate(ranges):
    assert 0 <= start < stop <= 55000
    if index:
        assert ranges[index - 1][1] <= start
expected = json.loads((root / "files.json").read_text())
for name, checksum in expected.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == checksum, name
assert expected["reference.csv"] == "2fc276934c6c50994a2c24196b7da4231383ef3d13f86804b5c38cb0d1d93add"
java = subprocess.check_output(["java", "-version"], stderr=subprocess.STDOUT, text=True)
assert 'version "11.' in java
output.mkdir(parents=True, exist_ok=False)
(output / "plan.json").write_bytes(plan_path.read_bytes())
(output / "start.json").write_text(
    json.dumps(
        {
            "unix": time.time(),
            "plan_sha256": hashlib.sha256(plan_path.read_bytes()).hexdigest(),
            "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "java": java,
        },
        indent=2,
    )
    + "\n"
)
failed = threading.Event()


def replay(interval):
    start, stop = interval
    if failed.is_set():
        return {"interval": interval, "status": "not_started_after_failure"}
    out = output / f"rows-{start}-{stop}"
    out.mkdir()
    command = [
        "java",
        "-Djava.awt.headless=true",
        "-Xmx768m",
        "-cp",
        f"{root}/app/NetLogo.jar:{root}/app/*",
        str(root / "BatchReplay.java"),
        str(root / "model/HEADLESS_Sugarscape.nlogo"),
        str(root / "reference.csv"),
        str(start),
        str(stop),
        str(out / "results.csv"),
    ]
    manifest = {
        "command": command,
        "source_sha256": {
            str(root / name): value
            for name, value in expected.items()
            if name.startswith("model/") or name == "BatchReplay.java"
        },
        "dependencies_sha256": {str(root / name): value for name, value in expected.items() if name.startswith("app/")},
        "reference_sha256": expected["reference.csv"],
        "rows": 55000,
        "steps_each": 10000,
        "java": java,
        "scope": plan["kind"],
        "plan_sha256": hashlib.sha256(plan_path.read_bytes()).hexdigest(),
    }
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    began = time.monotonic()
    with (out / "native.log").open("x") as log:
        result = subprocess.run(command, cwd=root / "model", stdout=log, stderr=subprocess.STDOUT)
    (out / "exit.json").write_text(
        json.dumps({"exit_code": result.returncode, "elapsed_seconds": time.monotonic() - began}) + "\n"
    )
    if result.returncode != 0:
        failed.set()
        return {"interval": interval, "status": "native_failed", "exit_code": result.returncode}
    with (out / "audit.log").open("x") as log:
        audit = subprocess.run(
            [
                "python3",
                str(root / "audit_reference.py"),
                str(root / "reference.csv"),
                str(out),
                "complete",
                str(out / "audit"),
            ],
            stdout=log,
            stderr=subprocess.STDOUT,
        )
    if audit.returncode != 0:
        failed.set()
        return {"interval": interval, "status": "audit_failed", "exit_code": audit.returncode}
    return {"interval": interval, "status": "complete", "rows": stop - start}


with concurrent.futures.ThreadPoolExecutor(max_workers=plan["workers"]) as executor:
    statuses = list(executor.map(replay, ranges))
(output / "summary.json").write_text(
    json.dumps(
        {
            "finished_unix": time.time(),
            "kind": plan["kind"],
            "statuses": statuses,
            "complete": all(s["status"] == "complete" for s in statuses),
        },
        indent=2,
    )
    + "\n"
)
assert all(s["status"] == "complete" for s in statuses), "Queue incomplete; inspect preserved records"
