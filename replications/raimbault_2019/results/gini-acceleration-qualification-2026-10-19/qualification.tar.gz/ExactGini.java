import java.util.Arrays;
import org.nlogo.api.*;

/** The original sorted-wealth loop, with identical double-operation order. */
public strictfp class ExactGini extends DefaultClassManager {
    public void load(PrimitiveManager manager) {
        manager.addPrimitive("compute", new Compute());
    }
    public static strictfp class Compute extends DefaultReporter {
        public Syntax getSyntax() {
            return Syntax.reporterSyntax(new int[]{Syntax.ListType()}, Syntax.ListType());
        }
        public Object report(Argument[] arguments, Context context) throws ExtensionException, LogoException {
            LogoList input = arguments[0].getList();
            double[] wealth = new double[input.size()];
            for (int i = 0; i < wealth.length; i++) wealth[i] = (Double) input.get(i);
            Arrays.sort(wealth);
            double total = 0;
            for (double value : wealth) total += value;
            double cumulative = 0;
            double reserve = 0;
            LogoListBuilder lorenz = new LogoListBuilder();
            for (int i = 0; i < wealth.length; i++) {
                cumulative += wealth[i];
                lorenz.add((cumulative / total) * 100);
                reserve = reserve + ((i + 1.0) / wealth.length) - (cumulative / total);
            }
            LogoListBuilder result = new LogoListBuilder();
            result.add(reserve);
            result.add(lorenz.toLogoList());
            return result.toLogoList();
        }
    }
}
