import csv,hashlib,json,re,statistics
from pathlib import Path
p=Path(__file__).resolve().parent
execution=p/'attempt-002'
assert json.loads((execution/'complete.json').read_text())=={'runs':4,'inputs_per_run':2,'exit_code':0}
csv.field_size_limit(10*1024*1024)
variants=['0-baseline','1-optimized','2-optimized','3-baseline']
rows=[];hashes={};state_rows=0;history_values=0
for index,variant in enumerate(variants):
 d=execution/variant
 assert json.loads((d/'exit.json').read_text())['exit_code']==0
 timings=re.findall(r'^simulation_seconds=(\d+),([0-9.]+)$',(d/'run.log').read_text(),re.M)
 assert [int(i) for i,t in timings]==[0,1]
 for row,seconds in timings:rows.append({'execution':index,'variant':variant.split('-',1)[1],'row':int(row),'population':[10,510][int(row)],'simulation_seconds':float(seconds)})
 assert (d/'results.csv').read_bytes()==(execution/'0-baseline/results.csv').read_bytes()
 for row in range(2):
  hist=d/f'results.csv.{row}.gini';reference=execution/'0-baseline'/hist.name
  assert hist.read_bytes()==reference.read_bytes()
  values=re.findall(r'[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?',hist.read_text())
  assert len(values)==10000
  world=d/f'results.csv.{row}.world'
  actual=list(csv.reader(world.open()));expected=list(csv.reader((execution/'0-baseline'/world.name).open()))
  assert len(actual)==len(expected)
  assert len(actual[2])==1 and re.fullmatch(r'\d+/\d+/\d+ \d+:\d+:\d+:\d+ [-+]\d+',actual[2][0])
  # Only the export timestamp is metadata. Retain RNG state, globals, every
  # turtle/patch/link, plots and extension sections in the equality check.
  assert actual[:2]==expected[:2] and actual[3:]==expected[3:]
  if index:state_rows+=len(actual)-1;history_values+=len(values)
 for f in d.iterdir():hashes[str(f.relative_to(p))]=hashlib.sha256(f.read_bytes()).hexdigest()
summary=[]
for population in [10,510]:
 a=[r['simulation_seconds'] for r in rows if r['population']==population and r['variant']=='baseline']
 b=[r['simulation_seconds'] for r in rows if r['population']==population and r['variant']=='optimized']
 summary.append({'population':population,'baseline_seconds':a,'optimized_seconds':b,'mean_baseline_over_optimized':statistics.mean(a)/statistics.mean(b)})
out=p/'audit';out.mkdir()
(out/'audit.json').write_text(json.dumps({'full_horizon_runs':8,'history_values_compared_to_first_baseline':history_values,'exported_world_rows_compared_excluding_timestamps':state_rows,'all12_metrics_exact':True,'random_generator_state_exact':True,'performance':summary,'file_sha256':hashes,'scope':'Two selected archived generated inputs, two repetitions per variant, local shared machine. Qualification only; no full-ensemble fidelity or statistically established speedup. Production remains unmodified.'},indent=2)+'\n')
with (out/'timings.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(json.dumps(summary))
