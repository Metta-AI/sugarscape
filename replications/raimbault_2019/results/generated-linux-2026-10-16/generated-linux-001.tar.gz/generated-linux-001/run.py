import concurrent.futures,csv,gzip,hashlib,json,subprocess,time
from pathlib import Path
p=Path(__file__).resolve().parent
w=Path("/root/sugarscape/proof-002")
selection=json.loads((p/"selection.json").read_text())
criteria=json.loads((p/"criteria.json").read_text())
assert hashlib.sha256((p/"selected.csv.gz").read_bytes()).hexdigest()==selection["selected_gzip_sha256"]
with gzip.open(p/"selected.csv.gz","rt") as f: expected=list(csv.DictReader(f))
assert len(expected)==6
model=w/"model/HEADLESS_Sugarscape.nlogo"
adapter=p/"GeneratedReplay.java"
app=w/"app"
java="java"
files=[model,adapter,*sorted(model.parent.rglob("*.nls")),*sorted((model.parent/"morphology").glob("*.jar")),*sorted(app.glob("*.jar")),p/"criteria.json",p/"selection.json",p/"run.py"]
checksums={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}

for name, checksum in json.loads((p/"expected-runtime.json").read_text()).items():
    assert hashlib.sha256((w/name).read_bytes()).hexdigest()==checksum, name
assert hashlib.sha256(adapter.read_bytes()).hexdigest()=="c52a4dfaec12a5db99d19ba9a49f38e20cb6e40bac97ec667b49904d577182fd"

def replay(interval):
    start,stop=interval; out=p/f"run-{start}-{stop}";out.mkdir()
    command=[java,"-Djava.awt.headless=true","-Xmx768m","-cp",f"{app}/NetLogo.jar:{app}/*",str(adapter),str(model),str(p/"selected.csv.gz"),str(start),str(stop),str(out/"results.csv")]
    (out/"manifest.json").write_text(json.dumps({"command":command,"source_sha256":checksums,"java":subprocess.check_output([java,"-version"],stderr=subprocess.STDOUT,text=True),"scope":"Input-selected validation probes, not production ensemble coverage"},indent=2)+"\n")
    began=time.monotonic()
    with (out/"native.log").open("x") as log: result=subprocess.run(command,cwd=model.parent,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
    (out/"exit.json").write_text(json.dumps({"exit_code":result.returncode,"seconds":time.monotonic()-began})+"\n")
    assert result.returncode==0
    actual=list(csv.DictReader((out/"results.csv").open())); assert len(actual)==stop-start
    comparisons=[]
    for index,row in enumerate(actual,start=start):
        reference=expected[index];assert int(row["row"])==index and row["id"]==reference["id"] and row["seed"]==reference["replication"] and float(row["population"])==float(reference["population"]) and float(row["ticks"])==10000
        for metric in ["gini","mwgini","moran","distance","entropy","slope","rsquared","moranRessource","distanceRessource","entropyRessource","slopeRessource","rsquaredRessource"]:
            actual_value=float(row[metric]);expected_value=float(reference[metric]);error=abs(actual_value-expected_value); tolerance=0.0 if metric in ["gini","mwgini"] else criteria["morphology_absolute_tolerance"]
            comparisons.append({"original_row":selection["original_indices"][index],"metric":metric,"actual":actual_value,"expected":expected_value,"absolute_error":error,"tolerance":tolerance,"exact":error==0,"within_tolerance":error<=tolerance})
    (out/"comparisons.json").write_text(json.dumps(comparisons,indent=2)+"\n")
    assert all(c["within_tolerance"] for c in comparisons),out
    return comparisons

with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor: reports=list(executor.map(replay,[(0,2),(2,4),(4,6)]))
flat=[c for report in reports for c in report]
summary={"rows":6,"new_validation_rows":0,"repeated_control_original_row":0,"comparisons":len(flat),"exact_comparisons":sum(c["exact"] for c in flat),"within_declared_tolerance":all(c["within_tolerance"] for c in flat),"nonexact":[c for c in flat if not c["exact"]],"maximum_absolute_error":max(c["absolute_error"] for c in flat),"scope":"Generated-landscape fidelity probes only; no production coverage counted"}
(p/"summary.json").write_text(json.dumps(summary,indent=2)+"\n");print(json.dumps(summary))
