#!/bin/bash
set -u
cd /root/sugarscape/generated-linux-001
nice -n 19 timeout --kill-after=30s 1800s python3 run.py > runner.log 2>&1
status=$?
printf '{"exit_code":%s}\n' "$status" > terminal.json
tar -czf /root/sugarscape/generated-linux-001.tar.gz -C /root/sugarscape generated-linux-001
exit "$status"
