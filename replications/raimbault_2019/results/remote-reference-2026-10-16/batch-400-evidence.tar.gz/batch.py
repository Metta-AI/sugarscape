"""Run disjoint original-model reference intervals after a recorded checkpoint handoff."""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parent
expected = json.loads((root / "files.json").read_text())
for name, checksum in expected.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == checksum, name
java = subprocess.check_output(["java", "-version"], stderr=subprocess.STDOUT, text=True)
assert 'version "11.' in java
assert not (root / "batch-start.json").exists()
(root / "batch-start.json").write_text(json.dumps({"started_unix": time.time(), "java": java, "intervals": json.loads((root / "ranges.json").read_text()), "purpose": "Unique ensemble rows transferred after local termination; see handoff-confirmed.json"}, indent=2) + "\n")

def replay(interval):
    start, stop = interval
    out = root / f"batch-{start}-{stop}"
    out.mkdir()
    command = ["java", "-Djava.awt.headless=true", "-Xmx768m", "-cp", f"{root}/app/NetLogo.jar:{root}/app/*", str(root / "BatchReplay.java"), str(root / "model/HEADLESS_Sugarscape.nlogo"), str(root / "reference.csv"), str(start), str(stop), str(out / "results.csv")]
    manifest = {"command": command, "source_sha256": {str(root / name): value for name, value in expected.items() if name.startswith("model/") or name == "BatchReplay.java"}, "dependencies_sha256": {str(root / name): value for name, value in expected.items() if name.startswith("app/")}, "reference_sha256": expected["reference.csv"], "rows": 55000, "steps_each": 10000, "java": java}
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    began = time.monotonic()
    with (out / "native.log").open("x") as log:
        result = subprocess.run(command, cwd=root / "model", stdout=log, stderr=subprocess.STDOUT)
    (out / "exit.json").write_text(json.dumps({"exit_code": result.returncode, "elapsed_seconds": time.monotonic() - began}) + "\n")
    assert result.returncode == 0, out
    subprocess.run(["python3", str(root / "audit_reference.py"), str(root / "reference.csv"), str(out), "complete", str(out / "audit")], check=True)
    return str(out)

with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
    results = list(executor.map(replay, json.loads((root / "ranges.json").read_text())))
(root / "batch-complete.json").write_text(json.dumps({"completed_unix": time.time(), "runs": results, "rows": 400, "exact_comparisons": 800}) + "\n")
