#!/bin/sh
set -u
cd /root/sugarscape
start=$(date +%s)
timeout --signal=TERM --kill-after=30s 86400 python3 run_reference_queue.py proof-002 production-plan.json reference-queue-001 > reference-queue-launcher.log 2>&1
code=$?
printf '{"exit_code":%s,"started_unix":%s,"finished_unix":%s,"limit_seconds":86400}\n' "$code" "$start" "$(date +%s)" > reference-queue-terminal.json
tar -czf reference-queue-evidence.tar.gz reference-queue-001 reference-queue-launcher.log reference-queue-terminal.json run_reference_queue.py production-plan.json handoff-confirmed.json
sha256sum reference-queue-evidence.tar.gz
curl --max-time 20 --noproxy '*' -fsS -X POST -H 'Metadata-Flavor: givemeanode' http://169.254.42.1/v1/stop
exit "$code"
