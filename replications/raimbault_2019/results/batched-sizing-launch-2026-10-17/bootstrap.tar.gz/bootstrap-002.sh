#!/bin/sh
set -eu
cd /root/sugarscape/batched-sizing-001
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq openjdk-11-jdk-headless python3 time curl ca-certificates
mkdir /root/sugarscape/proof-002
cp -R runtime/model /root/sugarscape/proof-002/model
curl -fsSL --max-time 180 https://downloads.netlogo.org/5.3.1/NetLogo-5.3.1-64.tgz -o NetLogo-5.3.1-64.tgz
curl -fsSL --max-time 60 https://repo.maven.apache.org/maven2/org/apache/commons/commons-math3/3.3/commons-math3-3.3.jar -o /root/sugarscape/proof-002/model/morphology/commons-math3-3.3.jar
python3 extract_runtime.py
sh run.sh
