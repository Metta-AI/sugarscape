#!/bin/sh
set -u
cd /root/sugarscape/batched-sizing-001
started=$(date +%s)
timeout --signal=TERM --kill-after=30s 4200 sh bootstrap-002.sh > setup.log 2>&1
code=$?
printf '{"exit_code":%s,"started_unix":%s,"finished_unix":%s,"limit_seconds":4200}\n' "$code" "$started" "$(date +%s)" > bootstrap-terminal.json
tar --exclude=batched-sizing-001/NetLogo-5.3.1-64.tgz -czf /root/sugarscape/batched-sizing-evidence-002.tar.gz -C /root/sugarscape batched-sizing-001
exit "$code"
