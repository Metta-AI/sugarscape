import hashlib,json,tarfile
from pathlib import Path
root=Path(__file__).resolve().parent
expected=json.loads((root/'expected-runtime.json').read_text())
archive=root/'NetLogo-5.3.1-64.tgz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='07a626e486606f3d92fd39f7986641fb3f6bb8a00828f583b3b1804446a1c87c'
with tarfile.open(archive) as bundle:
    for name,digest in expected.items():
        path=Path('/root/sugarscape/proof-002')/name
        if name.startswith('app/'):
            content=bundle.extractfile('netlogo-5.3.1-64/'+name).read()
            assert hashlib.sha256(content).hexdigest()==digest,name
            path.parent.mkdir(parents=True,exist_ok=True)
            path.write_bytes(content)
        assert hashlib.sha256(path.read_bytes()).hexdigest()==digest,name
print('Verified all',len(expected),'frozen runtime files')
