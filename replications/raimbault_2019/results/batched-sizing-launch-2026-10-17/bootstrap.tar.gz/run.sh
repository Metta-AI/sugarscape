#!/bin/sh
set -u
cd /root/sugarscape/batched-sizing-001
start=$(date +%s)
timeout --signal=TERM --kill-after=30s 3600 python3 run.py > launcher.log 2>&1
code=$?
printf '{"exit_code":%s,"started_unix":%s,"finished_unix":%s,"limit_seconds":3600}\n' "$code" "$start" "$(date +%s)" > terminal.json
tar -czf /root/sugarscape/batched-sizing-evidence-001.tar.gz -C /root/sugarscape batched-sizing-001
exit "$code"
