#include <algorithm>
#include <array>
#include <cmath>
#include <iostream>
#include <random>
#include <vector>
#define AGENT_STATUS_UNOCCUPIED 0
#define AGENT_STATUS_OCCUPIED 1
#define AGENT_STATUS_MOVEMENT_REQUESTED 2
#define AGENT_STATUS_MOVEMENT_UNRESOLVED 3
#define ENV_SUGAR_MAX_CAPACITY 4
#define MIN_HOTSPOT_DISTANCE 20
#define MIN_INIT_AGENT_SUAGR_WEALTH 5
#define MAX_INIT_AGENT_SUAGR_WEALTH 25
#define MIN_INIT_METABOLISM 1
#define MAX_INIT_METABOLISM 4
bool hotspot_distance_check(const std::vector<std::array<unsigned int, 2>>& sugar_hotspots, const std::array<unsigned int, 2>& hs, const unsigned int gridWidth) {
    bool pass = true;
    for (auto& h : sugar_hotspots) {
        // calculate the distance between spots
        unsigned int dx = std::abs(static_cast<int>(std::get<0>(hs)) - static_cast<int>(std::get<0>(h)));
        unsigned int dy = std::abs(static_cast<int>(std::get<1>(hs)) - static_cast<int>(std::get<1>(h)));
        // if distance in a dimension is greater than half grid width then points are closer via wrapping
        if (dx > (gridWidth >>1))
            dx = gridWidth - dx;
        if (dy > (gridWidth >> 1))
            dy = gridWidth - dy;

        if (std::sqrt((pow(dx, 2.0f) + pow(dy, 2.0f))) < static_cast<float>(MIN_HOTSPOT_DISTANCE) )
            pass = false;
    }
    return pass;
}



int main() {
    const unsigned int gridWidth = 256;
    const unsigned long long seed = 0;
    const float pOccupation = 0.17f;
    std::cout << "step,id,x,y,status,sugar,metabolism,cell_sugar,cell_capacity\n";
std::mt19937_64 rng(seed);
                        // Pre init, decide the sugar hotspots
                        std::vector<std::array<unsigned int, 2>> sugar_hotspots;
                        {
                            std::uniform_int_distribution<unsigned int> width_dist(0, gridWidth - 1);
                            std::uniform_int_distribution<unsigned int> height_dist(0, gridWidth - 1);
                            // There are a number of hotspots which create an average denisty based on that of the original model
                            unsigned int num_hotspots = (2 * gridWidth * gridWidth) / (49 * 49);
                            for (unsigned int h = 0; h < num_hotspots; h++) {
                                // create random position for new hotspot
                                std::array<unsigned int, 2> hs = { width_dist(rng), height_dist(rng) };
                                // recursively ensure that the a random position is not within an euclidean distance of 10
                                unsigned int attempts = 0;
                                while (!hotspot_distance_check(sugar_hotspots, hs, gridWidth)) {
                                    hs = { width_dist(rng), height_dist(rng) };
                                    attempts++;
                                    // give up if no position found after 100 attempts
                                    if (attempts == 100) {
                                        std::cerr << "Warning: Maximum attempts reached creating unique location for sugar hotspot." << std::endl;
                                        break;
                                    }
                                }
                                // add hostpot after it has passed the distance checks
                                sugar_hotspots.push_back(hs);
                            }
                        }


                        for (const auto& hotspot : sugar_hotspots) { std::cerr << "HOTSPOT," << hotspot[0] << "," << hotspot[1] << "\n"; }
// Currently population has not been init, so generate an agent population on the fly
                        
                        std::uniform_real_distribution<float> normal(0, 1);
                        std::uniform_int_distribution<int> agent_sugar_dist(MIN_INIT_AGENT_SUAGR_WEALTH, MAX_INIT_AGENT_SUAGR_WEALTH);
                        std::uniform_int_distribution<int> agent_metabolism_dist(MIN_INIT_METABOLISM, MAX_INIT_METABOLISM);
                        
                        unsigned int agent_id = 0;
                        
                        for (unsigned int x = 0; x < gridWidth; ++x) {
                            for (unsigned int y = 0; y < gridWidth; ++y) {
                                int id = -1, status = 0, sugar = 0, metabolism = 0, cell_sugar = 0, cell_capacity = 0;
                                
                                // 10% chance of cell holding an agent
                                if (normal(rng) < pOccupation) {
                                    id = agent_id++;
                                    status = AGENT_STATUS_OCCUPIED;
                                    sugar = agent_sugar_dist(rng);
                                    metabolism = agent_metabolism_dist(rng);
                                } else {
                                    id = -1;
                                    status = AGENT_STATUS_UNOCCUPIED;
                                    sugar = 0;
                                    metabolism = 0;
                                }
                                // environment specific var
                                unsigned int env_sugar_lvl = 0;
                                const int hotspot_core_size = 5;
                                for (auto& hs : sugar_hotspots) {
                                    // Workout the highest sugar lvl from a nearby hotspot
                                    int hs_x = static_cast<int>(std::get<0>(hs));
                                    int hs_y = static_cast<int>(std::get<1>(hs));
                                    // distance to hotspot
                                    float hs_dist = static_cast<float>(sqrt(pow(hs_x - static_cast<int>(x), 2.0f) + pow(hs_y - static_cast<int>(y), 2.0f)));

                                    // four bands of sugar with increasing radius of 5
                                    env_sugar_lvl += 4 - std::min<int>(4, static_cast<int>(floor(hs_dist / hotspot_core_size)));
                                }
                                env_sugar_lvl = env_sugar_lvl > ENV_SUGAR_MAX_CAPACITY ? ENV_SUGAR_MAX_CAPACITY : env_sugar_lvl;
                                cell_capacity = env_sugar_lvl;  // All cells begin at their local max sugar
                                cell_sugar = env_sugar_lvl;

    std::cout << -1 << ',' << id << ',' << x << ',' << y << ',' << status << ',' << sugar << ',' << metabolism << ',' << cell_sugar << ',' << cell_capacity << '\n';
    }
    }
}
